import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';

import MainLayout from '@/components/layout/MainLayout';
import ClientLayout from '@/components/layout/ClientLayout';

import AdminDashboard from '@/pages/AdminDashboard';
import ProposalView from '@/pages/ProposalView';
import CreateProposal from '@/pages/CreateProposal';
import PipelinePage from '@/pages/pipeline/PipelinePage';
import Companies from '@/pages/crm/Companies';
import Contacts from '@/pages/crm/Contacts';
import Services from '@/pages/crm/Services';
import LeadsPage from '@/pages/crm/LeadsPage';
import LoginPage from '@/pages/auth/LoginPage';
import SignUpPage from '@/pages/auth/SignUpPage';
import AcceptInvitationPage from '@/pages/auth/AcceptInvitationPage';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import SettingsPage from '@/pages/SettingsPage';
import ApprovedJobsPage from '@/pages/ApprovedJobsPage';
import AnnualServicesPage from '@/pages/AnnualServicesPage';
import CalendarPage from '@/pages/CalendarPage';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import ProposalsPage from '@/pages/ProposalsPage';
import BookingPage from '@/pages/BookingPage';
import PublicBookingPage from '@/pages/PublicBookingPage';
import EventTypeDetails from '@/pages/EventTypeDetails';
import BookingPreviewPage from '@/pages/BookingPreviewPage';
import ClientAuthPage from '@/pages/auth/ClientAuthPage';
import ProjectsPage from '@/pages/ProjectsPage';
import BookingConfirmationPage from '@/pages/BookingConfirmationPage';

import ClientDashboard from '@/pages/client/ClientDashboard';
import ClientAppointments from '@/pages/client/ClientAppointments';
import ClientPayments from '@/pages/client/ClientPayments';

function App() {
  const { session, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="loader"></div>
      </div>
    );
  }

  const getHomeRoute = () => {
    if (!session) return "/login";
    if (profile?.role === 'client') return "/client/dashboard";
    return "/dashboard";
  }

  const isLeadModuleActive = profile?.module_settings?.lead_capture === true;
  const isAppointmentModuleActive = profile?.module_settings?.appointment_scheduling === true;
  const isProjectsModuleActive = profile?.module_settings?.projects_module === true;

  const adminRoles = ['admin', 'supervisor', 'coordinador'];

  return (
    <>
      <Helmet>
        <title>CRM & Propuestas</title>
        <meta name="description" content="Plataforma profesional para crear, gestionar y aprobar propuestas de servicios, y administrar tu CRM de manera eficiente." />
        <meta property="og:title" content="CRM & Propuestas" />
        <meta property="og:description" content="Plataforma profesional para crear, gestionar y aprobar propuestas de servicios, y administrar tu CRM de manera eficiente." />
      </Helmet>
      
      <Router>
        <Routes>
          {/* Public & Auth Routes with special handling */}
          <Route path="/accept-invitation" element={<AcceptInvitationPage />} />
          <Route path="/login" element={session ? <Navigate to={getHomeRoute()} /> : <LoginPage />} />
          <Route path="/signup" element={session ? <Navigate to={getHomeRoute()} /> : <SignUpPage />} />
          
          {/* Other Public Routes */}
          <Route path="/proposal/:id" element={<ProposalView />} />
          <Route path="/book/:userId" element={<PublicBookingPage />} />
          <Route path="/book/:userId/:eventTypeId" element={<EventTypeDetails />} />
          <Route path="/booking-preview" element={<BookingPreviewPage />} />
          <Route path="/client-auth" element={<ClientAuthPage />} />
          <Route path="/booking-confirmation/:eventId" element={<BookingConfirmationPage />} />

          {/* Admin & Staff Protected Routes */}
          <Route element={<ProtectedRoute allowedRoles={adminRoles} />}>
            <Route element={<MainLayout />}>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<AdminDashboard />} />
              <Route path="/create" element={<CreateProposal />} />
              <Route path="/proposals" element={<ProposalsPage />} />
              <Route path="/pipeline" element={<PipelinePage />} />
              <Route path="/jobs" element={<ApprovedJobsPage />} />
              <Route path="/annual-services" element={<AnnualServicesPage />} />
              <Route path="/calendar" element={<CalendarPage />} />
              <Route path="/companies" element={<Companies />} />
              <Route path="/contacts" element={<Contacts />} />
              <Route path="/services" element={<Services />} />
              
              {isProjectsModuleActive ? (
                <Route path="/projects" element={<ProjectsPage />} />
              ) : (
                <Route path="/projects" element={<Navigate to="/dashboard" replace />} />
              )}

              {isLeadModuleActive ? (
                <Route path="/leads" element={<LeadsPage />} />
              ) : (
                <Route path="/leads" element={<Navigate to="/dashboard" replace />} />
              )}

              {isAppointmentModuleActive ? (
                <Route path="/booking" element={<BookingPage />} />
              ) : (
                <Route path="/booking" element={<Navigate to="/dashboard" replace />} />
              )}

              <Route path="/settings/*" element={<SettingsPage />} />
            </Route>
          </Route>
          
          {/* Client Protected Routes */}
          <Route element={<ProtectedRoute allowedRoles={['client']} />}>
            <Route path="/client" element={<ClientLayout />}>
                <Route path="dashboard" element={<ClientDashboard />} />
                <Route path="appointments" element={<ClientAppointments />} />
                <Route path="payments" element={<ClientPayments />} />
            </Route>
          </Route>
        </Routes>
      </Router>
    </>
  );
}

export default App;