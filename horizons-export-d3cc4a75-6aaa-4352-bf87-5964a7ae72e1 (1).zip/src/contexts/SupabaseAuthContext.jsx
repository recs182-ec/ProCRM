
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const { toast } = useToast();
    const [session, setSession] = useState(null);
    const [user, setUser] = useState(null);
    const [profile, setProfile] = useState(null);
    const [loading, setLoading] = useState(true);

    const fetchProfile = useCallback(async (userId) => {
        if (!userId) {
            setProfile(null);
            return null;
        }
        try {
            const { data, error } = await supabase
                .from('profiles')
                .select('*, raw_user_meta_data')
                .eq('id', userId)
                .single();
            
            if (error && error.code !== 'PGRST116') { // PGRST116 means no rows found
                throw error;
            }
            
            const finalProfile = data ? { ...data, ...data.raw_user_meta_data } : null;
            setProfile(finalProfile);
            return finalProfile;
        } catch (error) {
            console.error("Error fetching profile:", error);
            setProfile(null);
            return null;
        }
    }, []);

    const handleAuthChange = useCallback(async (session) => {
        setSession(session);
        const currentUser = session?.user;
        setUser(currentUser ?? null);
        
        if (currentUser) {
            await fetchProfile(currentUser.id);
        } else {
            setProfile(null);
        }
        setLoading(false);
    }, [fetchProfile]);
    
    useEffect(() => {
        const getSession = async () => {
            const { data: { session } } = await supabase.auth.getSession();
            await handleAuthChange(session);
            setLoading(false);
        };
        
        getSession();

        const { data: authListener } = supabase.auth.onAuthStateChange(
            async (_event, session) => {
                if (_event === 'SIGNED_IN' && session) {
                    const { data: { user } } = await supabase.auth.getUser();
                    const { data: profileData, error: profileError } = await supabase
                        .from('profiles')
                        .select('id')
                        .eq('id', user.id)
                        .single();

                    if (profileError && profileError.code === 'PGRST116') {
                        // Profile doesn't exist, could be a new user from an invite link
                        // The trigger `handle_new_user_signup` should handle profile creation.
                        // We just need to wait a bit and refetch.
                        setTimeout(async () => {
                            await handleAuthChange(session);
                        }, 1500);
                    } else {
                        await handleAuthChange(session);
                    }
                } else {
                    await handleAuthChange(session);
                }
            }
        );

        return () => {
            authListener?.subscription.unsubscribe();
        };
    }, [handleAuthChange]);
    
    const signIn = useCallback(async (email, password) => {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });

        if (error) {
            toast({
                variant: "destructive",
                title: "Error al iniciar sesión",
                description: "La contraseña o el correo electrónico son incorrectos.",
            });
            return { session: null, profile: null, error };
        }
        
        if (data.session) {
            const userProfile = await fetchProfile(data.session.user.id);
            return { session: data.session, profile: userProfile, error: null };
        }

        return { session: null, profile: null, error: new Error('Inicio de sesión fallido.') };
    }, [toast, fetchProfile]);

    const signUp = useCallback(async (email, password, options = {}) => {
        const { data, error } = await supabase.auth.signUp({
            email,
            password,
            options
        });
        
        if (error) {
            toast({
                variant: "destructive",
                title: "Error en el registro",
                description: error.message,
            });
        }
        
        return { user: data.user, error };
    }, [toast]);

    const signInWithGoogle = useCallback(async (options = {}) => {
        let redirectTo = options.redirectTo || window.location.origin; // Redirect to origin to let App.jsx decide
        
        let roleData = { role: 'admin' }; // Default role for new signups
        
        const pendingBooking = localStorage.getItem('pendingBooking');
        if (pendingBooking) {
            const { userId, eventTypeId } = JSON.parse(pendingBooking);
            redirectTo = `${window.location.origin}/book/${userId}/${eventTypeId}?from_auth=true`;
            roleData = { role: 'client' };
        }

        const { data, error } = await supabase.auth.signInWithOAuth({
            provider: 'google',
            options: {
                redirectTo: redirectTo,
                queryParams: { prompt: 'consent' },
                data: roleData,
            },
        });

        if (error) {
            toast({
                variant: "destructive",
                title: "Error al iniciar sesión con Google",
                description: error.message,
            });
        }
        return { data, error };
    }, [toast]);

    const value = {
        session,
        user,
        profile,
        loading,
        signIn,
        signUp,
        signInWithGoogle,
        signOut: () => supabase.auth.signOut(),
        fetchProfile: (userId) => user ? fetchProfile(userId || user.id) : Promise.resolve(null),
    };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
