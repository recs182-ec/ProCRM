import React, { useState, useEffect, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Building, Mail, Briefcase, Phone, Lock } from 'lucide-react';

const AcceptInvitationPage = () => {
  const { signOut, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    position: '',
    password: '',
  });
  const [email, setEmail] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [pageLoading, setPageLoading] = useState(true);
  const [formProcessing, setFormProcessing] = useState(false);
  const [error, setError] = useState(null);
  const [step, setStep] = useState('verifying'); // verifying, form, done

  const fetchInviteDetails = useCallback(async (userEmail) => {
    try {
      const { data, error: funcError } = await supabase.functions.invoke('get-invite-details-by-email', {
        body: { invited_email: userEmail },
      });

      if (funcError) throw funcError;
      if (data.error) throw new Error(data.error);
      
      setCompanyName(data.companyName);
      setStep('form');
    } catch (err) {
      setError('No se pudo encontrar una invitación pendiente para tu correo. Por favor, solicita una nueva invitación.');
      toast({
        title: 'Error de Invitación',
        description: err.message || 'No se encontró una invitación pendiente.',
        variant: 'destructive',
      });
      setStep('error');
    }
  }, [toast]);
  
  useEffect(() => {
    const handleInvitationFlow = async () => {
      const params = new URLSearchParams(window.location.hash.substring(1));
      const accessToken = params.get('access_token');
      const tokenType = params.get('type');
      
      if (tokenType === 'recovery') {
        // This is a recovery link, not an invite. Redirect to avoid confusion.
        navigate('/login', { state: { message: "Por favor, inicia sesión para continuar." } });
        return;
      }

      if (accessToken) {
        // We have a token from a magic link. Let's verify it.
        const { data: { session }, error: sessionError } = await supabase.auth.setSession({ access_token: accessToken, refresh_token: '' });
        
        if (sessionError || !session || !session.user) {
          setError('El enlace de invitación es inválido o ha expirado. Por favor, solicita uno nuevo.');
          setStep('error');
          setPageLoading(false);
          return;
        }

        const user = session.user;
        setEmail(user.email);
        
        // Now that we have the user email, fetch company details
        await fetchInviteDetails(user.email);

      } else if (!authLoading) {
        // No token, and auth is not loading. This page shouldn't be accessed directly.
        setError('Acceso no autorizado. Esta página es solo para aceptar invitaciones.');
        setStep('error');
      }
      setPageLoading(false);
    };
    
    handleInvitationFlow();
    
    // Clean up the URL
    window.history.replaceState({}, document.title, window.location.pathname);

  }, [authLoading, navigate, fetchInviteDetails]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormProcessing(true);

    const { firstName, lastName, phone, position, password } = formData;
    if (!firstName || !lastName || !password) {
      toast({ title: 'Campos requeridos', description: 'Nombre, apellido y contraseña son obligatorios.', variant: 'destructive' });
      setFormProcessing(false);
      return;
    }

    try {
        const { error: userError } = await supabase.auth.updateUser({
            password: password,
            data: {
                full_name: `${firstName} ${lastName}`,
                first_name: firstName,
                last_name: lastName,
                phone: phone,
                position: position,
                status: 'active'
            }
        });

        if (userError) throw userError;

        // DB trigger `handle_new_user_signup` will handle profile creation/linking.
        // Wait a moment for it to complete.
        await new Promise(resolve => setTimeout(resolve, 1500));

        toast({
            title: '¡Bienvenido/a al equipo!',
            description: `Tu cuenta ha sido configurada y vinculada a ${companyName}.`,
        });
        
        await signOut();
        navigate('/login', { state: { message: '¡Cuenta activada! Por favor, inicia sesión con tu nueva contraseña.' }});

    } catch (err) {
        toast({
            title: 'Error al actualizar el perfil',
            description: err.message,
            variant: 'destructive',
        });
        setFormProcessing(false);
    }
  };
  
  if (pageLoading || step === 'verifying') {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="loader"></div>
        <p className="ml-4">Verificando invitación...</p>
      </div>
    );
  }

  if (step === 'error' || error) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background p-4">
        <Card className="w-full max-w-md text-center shadow-lg">
          <CardHeader>
            <CardTitle className="text-destructive">Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p>{error}</p>
            <Button onClick={() => navigate('/login')} className="mt-4">Ir a Iniciar Sesión</Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  if (step === 'form') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900 p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-lg"
        >
          <Card className="shadow-2xl">
            <CardHeader className="text-center p-8 bg-gray-50 dark:bg-gray-800 rounded-t-lg">
              <div className="flex justify-center mb-4">
                <Building className="h-12 w-12 text-primary" />
              </div>
              <CardTitle className="text-3xl font-bold">¡Te damos la bienvenida!</CardTitle>
              <CardDescription className="text-lg">Completa tu perfil para unirte a <span className="font-semibold text-primary">{companyName}</span>.</CardDescription>
            </CardHeader>
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Nombre</Label>
                    <Input id="firstName" name="firstName" value={formData.firstName} onChange={handleChange} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Apellido</Label>
                    <Input id="lastName" name="lastName" value={formData.lastName} onChange={handleChange} required />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="email" type="email" value={email} disabled className="pl-10 bg-muted/50" />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Teléfono (Opcional)</Label>
                    <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} placeholder="+1 234 567 890" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="position">Cargo (Opcional)</Label>
                    <Input id="position" name="position" value={formData.position} onChange={handleChange} placeholder="Ej. Coordinador" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Crea tu Contraseña</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="password" name="password" type="password" value={formData.password} onChange={handleChange} required className="pl-10" />
                  </div>
                </div>
                <Button type="submit" className="w-full text-lg py-6" disabled={formProcessing}>
                  {formProcessing ? 'Procesando...' : 'Unirme al Equipo'}
                </Button>
              </form>
              <p className="mt-6 text-center text-xs text-muted-foreground px-4">
                Al hacer clic en "Unirme al Equipo", tu cuenta se vinculará como miembro del equipo a <span className="font-semibold">{companyName}</span>.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }
  
  return null; // Should not be reached
};

export default AcceptInvitationPage;