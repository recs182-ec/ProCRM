
import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';

const ClientAuthPage = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const { toast } = useToast();

    useEffect(() => {
        const params = new URLSearchParams(location.hash.substring(1));
        const type = params.get('type');
        
        if (type === 'recovery') {
            toast({
                title: 'Contraseña Restablecida',
                description: 'Has restablecido tu contraseña exitosamente. Ahora puedes iniciar sesión.',
            });
        } else if (type === 'signup') {
             toast({
                title: '¡Correo Confirmado!',
                description: 'Tu cuenta ha sido verificada. Ahora puedes iniciar sesión para agendar tu cita.',
            });
        }
        
        const pendingBooking = localStorage.getItem('pendingBooking');
        if (pendingBooking) {
            const { userId, eventTypeId } = JSON.parse(pendingBooking);
            navigate(`/book/${userId}/${eventTypeId}`);
        } else {
            navigate('/');
        }

    }, [location, navigate, toast]);

    return (
        <div className="flex items-center justify-center min-h-screen bg-background">
            <div className="text-center">
                <div className="loader"></div>
                <p className="mt-4 text-muted-foreground">Redirigiendo...</p>
            </div>
        </div>
    );
};

export default ClientAuthPage;
