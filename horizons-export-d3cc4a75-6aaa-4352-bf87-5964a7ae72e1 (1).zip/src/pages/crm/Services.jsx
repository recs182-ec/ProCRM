import React, { useState, useEffect, useCallback, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { Plus, Edit, Trash2, ShoppingBag, Search, Upload, X, ChevronRight, LayoutGrid, MoreHorizontal } from 'lucide-react';
    import { Button, buttonVariants } from '@/components/ui/button';
    import { Card, CardContent } from '@/components/ui/card';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { useToast } from '@/components/ui/use-toast';
    import { Textarea } from '@/components/ui/textarea';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import CsvImportDialog from '@/components/common/CsvImportDialog';
    import { Checkbox } from '@/components/ui/checkbox';
    import { cn } from '@/lib/utils';
    import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
    import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
    import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';


    const CategoryManager = ({ open, onOpenChange, onCategoriesUpdate, allServices, currentCategoryToEdit }) => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [categoryName, setCategoryName] = useState('');
      const [selectedServices, setSelectedServices] = useState([]);
      const [serviceSearchTerm, setServiceSearchTerm] = useState('');
      const [loadingAction, setLoadingAction] = useState(false);

      useEffect(() => {
        if (open) {
          if (currentCategoryToEdit) {
            setCategoryName(currentCategoryToEdit.name);
            const servicesInThisCategory = allServices
              .filter(service => service.category_id === currentCategoryToEdit.id)
              .map(service => service.id);
            setSelectedServices(servicesInThisCategory);
          } else {
            setCategoryName('');
            setSelectedServices([]);
          }
          setServiceSearchTerm('');
        }
      }, [open, currentCategoryToEdit, allServices]);

      const filteredServices = useMemo(() => {
        return allServices.filter(service =>
          service.name.toLowerCase().includes(serviceSearchTerm.toLowerCase())
        );
      }, [allServices, serviceSearchTerm]);

      const handleServiceSelect = (serviceId, checked) => {
        setSelectedServices(prev =>
          checked ? [...prev, serviceId] : prev.filter(id => id !== serviceId)
        );
      };

      const handleSelectAllServices = (checked) => {
        if (checked) {
          setSelectedServices(filteredServices.map(service => service.id));
        } else {
          setSelectedServices([]);
        }
      };

      const handleSaveCategory = async () => {
        if (!categoryName.trim()) {
          toast({ title: 'Error', description: 'El nombre de la categoría es obligatorio.', variant: 'destructive' });
          return;
        }
        setLoadingAction(true);

        let categoryId = currentCategoryToEdit?.id;
        let error;

        if (currentCategoryToEdit) {
          const { error: updateError } = await supabase
            .from('service_categories')
            .update({ name: categoryName })
            .eq('id', categoryId);
          error = updateError;
        } else {
          const { data, error: insertError } = await supabase
            .from('service_categories')
            .insert({ name: categoryName, user_id: user.id })
            .select()
            .single();
          if (data) categoryId = data.id;
          error = insertError;
        }

        if (error) {
          toast({ title: 'Error', description: `No se pudo ${currentCategoryToEdit ? 'actualizar' : 'crear'} la categoría.`, variant: 'destructive' });
          setLoadingAction(false);
          return;
        }

        const servicesToUpdate = allServices.map(service => {
          const shouldBeInThisCategory = selectedServices.includes(service.id);
          const isCurrentlyInThisCategory = service.category_id === categoryId;
          const { service_categories, ...restOfService } = service;

          if (shouldBeInThisCategory && !isCurrentlyInThisCategory) {
            return { ...restOfService, category_id: categoryId };
          } else if (!shouldBeInThisCategory && isCurrentlyInThisCategory) {
            return { ...restOfService, category_id: null };
          }
          return null;
        }).filter(Boolean);

        if (servicesToUpdate.length > 0) {
          const { error: servicesUpdateError } = await supabase
            .from('services')
            .upsert(servicesToUpdate, { onConflict: 'id' });

          if (servicesUpdateError) {
            toast({ title: 'Error', description: `No se pudieron actualizar los servicios asociados. ${servicesUpdateError.message}`, variant: 'destructive' });
            setLoadingAction(false);
            return;
          }
        }

        toast({ title: 'Éxito', description: `Categoría ${currentCategoryToEdit ? 'actualizada' : 'creada'} y servicios asociados.` });
        onCategoriesUpdate();
        onOpenChange(false);
        setLoadingAction(false);
      };

      return (
        <Dialog open={open} onOpenChange={onOpenChange}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>{currentCategoryToEdit ? 'Editar categoría' : 'Nueva categoría'}</DialogTitle>
            </DialogHeader>
            <div className="py-4 space-y-4">
              <div>
                <Label htmlFor="category-name">Título *</Label>
                <Input id="category-name" placeholder="Introduce el título" value={categoryName} onChange={(e) => setCategoryName(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Servicios</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Buscar servicios..." value={serviceSearchTerm} onChange={(e) => setServiceSearchTerm(e.target.value)} className="pl-10" />
                </div>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="select-all-services" checked={selectedServices.length === filteredServices.length && filteredServices.length > 0} onCheckedChange={handleSelectAllServices} disabled={filteredServices.length === 0} />
                    <Label htmlFor="select-all-services" className="cursor-pointer">Seleccionar todo</Label>
                  </div>
                  <span>{selectedServices.length}/{filteredServices.length}</span>
                </div>
                <div className="max-h-48 overflow-y-auto space-y-1 pr-2 border rounded-md p-2">
                  {filteredServices.length > 0 ? filteredServices.map(service => (
                    <div key={service.id} className="flex items-center gap-2 p-1.5 rounded-md hover:bg-muted">
                      <Checkbox id={`service-${service.id}`} checked={selectedServices.includes(service.id)} onCheckedChange={(checked) => handleServiceSelect(service.id, checked)} />
                      <Label htmlFor={`service-${service.id}`} className="font-normal cursor-pointer flex-grow">{service.name}</Label>
                    </div>
                  )) : <p className="text-center text-sm text-muted-foreground py-4">No hay servicios.</p>}
                </div>
              </div>
            </div>
            <DialogFooter className="flex justify-between w-full">
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loadingAction}>Cancelar</Button>
                <Button onClick={handleSaveCategory} disabled={loadingAction || !categoryName.trim()}>{loadingAction ? 'Guardando...' : 'Guardar'}</Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      );
    };

    const Services = () => {
      const { toast } = useToast();
      const { user } = useAuth();
      const [services, setServices] = useState([]);
      const [categories, setCategories] = useState([]);
      const [isDialogOpen, setIsDialogOpen] = useState(false);
      const [isImportOpen, setIsImportOpen] = useState(false);
      const [isCategoryManagerOpen, setIsCategoryManagerOpen] = useState(false);
      const [currentService, setCurrentService] = useState(null);
      const [currentCategoryToEdit, setCurrentCategoryToEdit] = useState(null);
      const [formData, setFormData] = useState({ name: '', description: '', price: 0, frequency: 'Una vez', category_id: null });
      const [loading, setLoading] = useState(true);
      const [searchTerm, setSearchTerm] = useState('');
      const [selectedCategoryId, setSelectedCategoryId] = useState(null);
      const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);
      const [categoryToDelete, setCategoryToDelete] = useState(null);

      const fetchData = useCallback(async () => {
        if (!user) return;
        setLoading(true);
        const [servicesRes, categoriesRes] = await Promise.all([
          supabase.from('services').select('*, service_categories(name)').eq('user_id', user.id).order('created_at', { ascending: false }),
          supabase.from('service_categories').select('*').eq('user_id', user.id).order('name', { ascending: true })
        ]);

        if (servicesRes.error) toast({ title: 'Error', description: 'No se pudieron cargar los servicios.', variant: 'destructive' });
        else setServices(servicesRes.data);

        if (categoriesRes.error) toast({ title: 'Error', description: 'No se pudieron cargar las categorías.', variant: 'destructive' });
        else setCategories(categoriesRes.data);

        setLoading(false);
      }, [user, toast]);

      useEffect(() => {
        fetchData();
      }, [fetchData]);

      const handleSave = async () => {
        if (!formData.name || formData.price < 0) {
          toast({ title: 'Error', description: 'Nombre y precio válido son obligatorios.', variant: 'destructive' });
          return;
        }

        let dataToSave = { ...formData };
        if (dataToSave.category_id === '__none__') dataToSave.category_id = null;
        if (!dataToSave.category_id && selectedCategoryId) {
            dataToSave.category_id = selectedCategoryId;
        }

        if (currentService) {
          const { error } = await supabase.from('services').update(dataToSave).eq('id', currentService.id);
          if (error) toast({ title: 'Error', description: 'No se pudo actualizar el servicio.', variant: 'destructive' });
          else toast({ title: 'Éxito', description: 'Servicio actualizado.' });
        } else {
          const { error } = await supabase.from('services').insert({ ...dataToSave, user_id: user.id });
          if (error) toast({ title: 'Error', description: 'No se pudo crear el servicio.', variant: 'destructive' });
          else toast({ title: 'Éxito', description: 'Servicio creado.' });
        }
        fetchData();
        setIsDialogOpen(false);
        setCurrentService(null);
      };
      
      const handleOpenDialog = (service = null) => {
        setCurrentService(service);
        if (service) {
          setFormData({ name: service.name, description: service.description || '', price: service.price, frequency: service.frequency, category_id: service.category_id });
        } else {
          setFormData({ name: '', description: '', price: 0, frequency: 'Una vez', category_id: selectedCategoryId });
        }
        setIsDialogOpen(true);
      };

      const handleDeleteService = async (id) => {
        const { error } = await supabase.from('services').delete().eq('id', id);
        if (error) toast({ title: 'Error', description: 'No se pudo eliminar el servicio.', variant: 'destructive' });
        else {
          toast({ title: 'Servicio eliminado' });
          fetchData();
        }
      };

      const handleOpenCategoryManager = (category = null) => {
        setCurrentCategoryToEdit(category);
        setIsCategoryManagerOpen(true);
      };

      const handleConfirmDeleteCategory = (category) => {
        setCategoryToDelete(category);
        setIsDeleteAlertOpen(true);
      };

      const handleDeleteCategory = async () => {
        if (!categoryToDelete) return;
    
        const servicesToUpdate = services
          .filter(service => service.category_id === categoryToDelete.id)
          .map(service => {
            const { service_categories, ...rest } = service;
            return { ...rest, category_id: null };
          });
    
        if (servicesToUpdate.length > 0) {
          const { error: updateError } = await supabase.from('services').upsert(servicesToUpdate, { onConflict: 'id' });
          if (updateError) {
            toast({ title: 'Error', description: 'No se pudo desvincular los servicios.', variant: 'destructive' });
            return;
          }
        }
    
        const { error: deleteError } = await supabase.from('service_categories').delete().eq('id', categoryToDelete.id);
        if (deleteError) {
          toast({ title: 'Error', description: 'No se pudo eliminar la categoría.', variant: 'destructive' });
        } else {
          toast({ title: 'Categoría eliminada' });
          if (selectedCategoryId === categoryToDelete.id) {
            setSelectedCategoryId(null);
          }
          fetchData();
        }
        setIsDeleteAlertOpen(false);
        setCategoryToDelete(null);
      };
      
      const handleCategoryChange = (value) => {
        setFormData({ ...formData, category_id: value === '__none__' ? null : value });
      };

      const servicesColumnMapping = { name: { name: 'name', type: 'string' }, description: { name: 'description', type: 'string' }, price: { name: 'price', type: 'number' }, frequency: { name: 'frequency', type: 'string' }, category: { name: 'category', type: 'string' } };

      const categoryCounts = useMemo(() => {
        const counts = {};
        categories.forEach(cat => { counts[cat.id] = 0; });
        services.forEach(service => {
          if (service.category_id && counts.hasOwnProperty(service.category_id)) {
            counts[service.category_id]++;
          }
        });
        return counts;
      }, [services, categories]);
      
      const filteredAndSearchedServices = useMemo(() => {
        let filtered = services;
        if (selectedCategoryId) {
          filtered = services.filter(s => s.category_id === selectedCategoryId);
        }
        if (searchTerm) {
          return filtered.filter(s => s.name.toLowerCase().includes(searchTerm.toLowerCase()));
        }
        return filtered;
      }, [services, selectedCategoryId, searchTerm]);
      
      const selectedCategory = useMemo(() => categories.find(c => c.id === selectedCategoryId), [categories, selectedCategoryId]);

      return (
        <div className="flex h-full w-full bg-white">
          <aside className="w-1/4 max-w-xs border-r p-4 flex flex-col space-y-4 bg-gray-50/50">
            <h2 className="text-xl font-bold">Servicios y Clases</h2>
             <Accordion type="single" collapsible defaultValue="item-1" className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger className="font-semibold text-base">Servicios ({services.length})</AccordionTrigger>
                <AccordionContent className="pt-2">
                  <div className="flex flex-col space-y-1">
                    <Button variant={!selectedCategoryId ? 'secondary' : 'ghost'} className="justify-start px-2" onClick={() => setSelectedCategoryId(null)}>Todos los servicios</Button>
                    {categories.map(cat => (
                      <div key={cat.id} className={cn('flex items-center group', selectedCategoryId === cat.id && 'bg-secondary rounded-md')}>
                        <Button variant='ghost' className="justify-start flex-grow px-2" onClick={() => setSelectedCategoryId(cat.id)}>
                          {cat.name} ({categoryCounts[cat.id] || 0})
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="start">
                            <DropdownMenuItem onSelect={() => handleOpenCategoryManager(cat)}>
                              <Edit className="mr-2 h-4 w-4" /> Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem onSelect={() => handleConfirmDeleteCategory(cat)} className="text-destructive">
                              <Trash2 className="mr-2 h-4 w-4" /> Eliminar
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    ))}
                  </div>
                  <Button variant="outline" className="w-full mt-3" onClick={() => handleOpenCategoryManager()}>
                    <Plus className="mr-2 h-4 w-4" /> Nueva categoría
                  </Button>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </aside>

          <main className="flex-1 p-6 lg:p-8">
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex justify-between items-center mb-6">
              <div className="flex items-center text-sm text-muted-foreground">
                <h1 className="text-lg font-semibold text-foreground">Servicios</h1>
                {selectedCategory && (
                  <>
                    <ChevronRight className="h-4 w-4 mx-1" />
                    <span className="font-semibold text-foreground">{selectedCategory.name}</span>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setIsImportOpen(true)}><Upload className="mr-2 h-4 w-4" /> Importar</Button>
                <Button size="sm" onClick={() => handleOpenDialog()}><Plus className="mr-2 h-4 w-4" /> Añadir Servicio</Button>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <Card>
                <CardContent className="p-0">
                  {loading ? (
                    <div className="text-center p-20"><div className="loader"></div></div>
                  ) : filteredAndSearchedServices.length === 0 ? (
                    <div className="text-center p-12">
                      <LayoutGrid className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-xl font-semibold mb-2">
                        {selectedCategoryId ? 'No hay servicios en esta categoría' : 'No tienes servicios'}
                      </h3>
                      <p className="text-muted-foreground mb-4">
                        {selectedCategoryId ? 'Añade un servicio a esta categoría para empezar.' : 'Crea tu primer servicio.'}
                      </p>
                      <Button onClick={() => handleOpenDialog()}>
                        <Plus className="mr-2 h-4 w-4" /> Añadir Servicio
                      </Button>
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Nombre</TableHead>
                          <TableHead>Categoría</TableHead>
                          <TableHead>Frecuencia</TableHead>
                          <TableHead>Precio</TableHead>
                          <TableHead className="text-right">Acciones</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredAndSearchedServices.map((service) => (
                          <TableRow key={service.id}>
                            <TableCell className="font-medium">{service.name}</TableCell>
                            <TableCell>
                              {service.service_categories?.name ? (
                                <div className="flex items-center gap-2">
                                  <span>{service.service_categories.name}</span>
                                </div>
                              ) : <span className="text-muted-foreground/60">N/A</span>}
                            </TableCell>
                            <TableCell>{service.frequency}</TableCell>
                            <TableCell className="font-semibold text-primary">${parseFloat(service.price).toLocaleString()}</TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(service)}><Edit className="h-4 w-4" /></Button>
                              <Button variant="ghost" size="icon" onClick={() => handleDeleteService(service.id)} className="text-destructive"><Trash2 className="h-4 w-4" /></Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </main>
          
          <CsvImportDialog open={isImportOpen} onOpenChange={setIsImportOpen} tableName="services" columnMapping={servicesColumnMapping} templateFile="/templates/services_template.csv" onSuccess={fetchData} />
          
          <CategoryManager open={isCategoryManagerOpen} onOpenChange={setIsCategoryManagerOpen} onCategoriesUpdate={fetchData} allServices={services} currentCategoryToEdit={currentCategoryToEdit} />

          <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>¿Eliminar '{categoryToDelete?.name}'?</AlertDialogTitle>
                <AlertDialogDescription>
                  La categoría se eliminará permanentemente, pero los servicios asociados permanecerán en tu cuenta sin categoría.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteCategory} className={buttonVariants({ variant: "destructive" })}>
                  Sí, eliminar
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-md">
              <DialogHeader><DialogTitle>{currentService ? 'Editar Servicio' : 'Añadir Nuevo Servicio'}</DialogTitle></DialogHeader>
              <div className="grid gap-4 py-4">
                <div><Label htmlFor="name">Nombre</Label><Input id="name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} /></div>
                <div><Label htmlFor="description">Descripción</Label><Textarea id="description" value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} /></div>
                <div><Label htmlFor="price">Precio ($)</Label><Input id="price" type="number" value={formData.price} onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })} /></div>
                <div>
                  <Label htmlFor="frequency">Frecuencia</Label>
                  <Select onValueChange={(value) => setFormData({...formData, frequency: value})} value={formData.frequency}>
                    <SelectTrigger><SelectValue placeholder="Seleccionar frecuencia" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Una vez">Una vez</SelectItem>
                      <SelectItem value="Mensual">Mensual</SelectItem>
                      <SelectItem value="Anual">Anual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="category">Categoría</Label>
                  <Select onValueChange={handleCategoryChange} value={formData.category_id || '__none__'}>
                    <SelectTrigger><SelectValue placeholder="Seleccionar categoría" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none__">Sin categoría</SelectItem>
                      {categories.map(cat => <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter><Button onClick={handleSave}>Guardar Cambios</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      );
    };

    export default Services;