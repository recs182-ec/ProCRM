import React, { useState, useEffect, useCallback } from 'react';
    import { motion } from 'framer-motion';
    import { Helmet } from 'react-helmet';
    import { Plus, UserCheck, Trash2, Target, Edit } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent } from '@/components/ui/card';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useNavigate } from 'react-router-dom';
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
      AlertDialogTrigger,
    } from "@/components/ui/alert-dialog";
    import {
      Select,
      SelectContent,
      SelectItem,
      SelectTrigger,
      SelectValue,
    } from "@/components/ui/select"


    const LeadsPage = () => {
      const { toast } = useToast();
      const { user } = useAuth();
      const navigate = useNavigate();
      const [leads, setLeads] = useState([]);
      const [isDialogOpen, setIsDialogOpen] = useState(false);
      const [formData, setFormData] = useState({ id: null, name: '', email: '', phone: '', website: '', source: '', status: 'Nuevo' });
      const [loading, setLoading] = useState(true);

      const fetchLeads = useCallback(async () => {
        if (!user) return;
        setLoading(true);
        const { data, error } = await supabase.from('leads').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar los leads.', variant: 'destructive' });
        } else {
          setLeads(data || []);
        }
        setLoading(false);
      }, [user, toast]);

      useEffect(() => {
        fetchLeads();

        if (user) {
          const channel = supabase.channel('realtime-leads')
            .on('postgres_changes', { event: '*', schema: 'public', table: 'leads', filter: `user_id=eq.${user.id}` }, 
              () => {
                fetchLeads();
              }
            )
            .subscribe();

          return () => {
            supabase.removeChannel(channel);
          };
        }
      }, [user, fetchLeads]);

      const handleSave = async () => {
        if (!formData.name || !formData.email) {
          toast({ title: 'Error', description: 'Nombre y email son obligatorios.', variant: 'destructive' });
          return;
        }

        const leadData = {
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          website: formData.website,
          source: formData.source,
          status: formData.status,
          user_id: user.id
        };
        
        let error;
        if(formData.id) {
          ({ error } = await supabase.from('leads').update(leadData).eq('id', formData.id));
        } else {
          ({ error } = await supabase.from('leads').insert(leadData));
        }
        
        if (error) {
          toast({ title: 'Error', description: formData.id ? 'No se pudo actualizar el lead.' : 'No se pudo añadir el lead.', variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: formData.id ? 'Lead actualizado exitosamente.' : 'Lead añadido exitosamente.' });
        }
        setIsDialogOpen(false);
      };
      
      const handleOpenDialog = (lead = null) => {
        if (lead) {
          setFormData({ id: lead.id, name: lead.name, email: lead.email, phone: lead.phone || '', website: lead.website || '', source: lead.source || '', status: lead.status || 'Nuevo' });
        } else {
          setFormData({ id: null, name: '', email: '', phone: '', website: '', source: '', status: 'Nuevo' });
        }
        setIsDialogOpen(true);
      }

      const handleDelete = async (id) => {
        const { error } = await supabase.from('leads').delete().eq('id', id);
        if (error) {
          toast({ title: 'Error', description: 'No se pudo eliminar el lead.', variant: 'destructive' });
        } else {
          toast({ title: 'Lead eliminado', description: 'El lead ha sido eliminado.' });
        }
      };
      
      const convertToContact = async (lead) => {
        const { data: companyData, error: companyError } = await supabase
          .from('companies')
          .insert({ commercial_name: lead.name, website: lead.website, phone: lead.phone, user_id: user.id })
          .select()
          .single();
        
        if (companyError) {
          toast({ title: 'Error', description: 'No se pudo crear la compañía para el lead.', variant: 'destructive' });
          return;
        }

        const { error: contactError } = await supabase.from('contacts').insert({ name: lead.name, email: lead.email, phone: lead.phone, company_id: companyData.id, user_id: user.id });
        if (contactError) {
          toast({ title: 'Error', description: 'No se pudo convertir el lead a contacto.', variant: 'destructive' });
           await supabase.from('companies').delete().eq('id', companyData.id);
          return;
        }

        await supabase.from('leads').delete().eq('id', lead.id);
        toast({ title: '¡Convertido!', description: `${lead.name} ahora es una compañía y un contacto.` });
      };
      
      return (
        <div className="w-full">
          <Helmet>
            <title>Leads | CRM & Propuestas</title>
            <meta name="description" content="Captura, gestiona y convierte tus clientes potenciales en clientes reales." />
          </Helmet>
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-4xl font-bold">Leads</h1>
              <p className="text-muted-foreground text-lg">Captura y gestiona tus clientes potenciales.</p>
            </div>
            <div className="flex gap-2">
                <Button variant="outline" onClick={() => navigate('/settings')}>Configurar Webhook</Button>
                <Button onClick={() => handleOpenDialog()}>
                    <Plus className="mr-2 h-4 w-4" /> Añadir Lead
                </Button>
            </div>
          </motion.div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>{formData.id ? 'Editar Lead' : 'Añadir Nuevo Lead'}</DialogTitle>
                <DialogDescription>
                  Completa la información del cliente potencial.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div><Label htmlFor="name">Nombre</Label><Input id="name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} /></div>
                <div><Label htmlFor="email">Email</Label><Input id="email" type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} /></div>
                <div><Label htmlFor="phone">Teléfono</Label><Input id="phone" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} /></div>
                <div><Label htmlFor="website">Sitio Web</Label><Input id="website" value={formData.website} onChange={(e) => setFormData({ ...formData, website: e.target.value })} /></div>
                <div><Label htmlFor="source">Fuente</Label><Input id="source" value={formData.source} onChange={(e) => setFormData({ ...formData, source: e.target.value })} /></div>
                <div><Label htmlFor="status">Estado</Label>
                  <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Nuevo">Nuevo</SelectItem>
                      <SelectItem value="Contactado">Contactado</SelectItem>
                      <SelectItem value="Calificado">Calificado</SelectItem>
                      <SelectItem value="No Calificado">No Calificado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter><Button onClick={handleSave}>Guardar Lead</Button></DialogFooter>
            </DialogContent>
          </Dialog>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Card>
              <CardContent className="p-0">
                 {loading ? (
                  <div className="flex justify-center items-center h-64"><div className="loader"></div></div>
                ) : leads.length === 0 ? (
                  <div className="text-center py-20 px-6">
                    <Target className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">Aún no tienes leads</h3>
                    <p className="text-muted-foreground mb-6">Tus nuevos leads aparecerán aquí. Configura la integración en la pestaña de Ajustes o añade uno manualmente.</p>
                    <Button onClick={() => handleOpenDialog()}>Añadir tu Primer Lead</Button>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Nombre</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Fuente</TableHead>
                          <TableHead>Estado</TableHead>
                          <TableHead className="text-right">Acciones</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {leads.map((lead) => (
                          <TableRow key={lead.id}>
                            <TableCell className="font-medium">{lead.name}</TableCell>
                            <TableCell>{lead.email}</TableCell>
                            <TableCell>{lead.source}</TableCell>
                            <TableCell><span className={`px-2 py-1 text-xs font-semibold rounded-full ${lead.status === 'Nuevo' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}`}>{lead.status}</span></TableCell>
                            <TableCell className="text-right space-x-1">
                              <Button variant="ghost" size="icon" onClick={() => convertToContact(lead)} title="Convertir a Contacto y Compañía" className="text-green-600 hover:text-green-700"><UserCheck className="h-4 w-4" /></Button>
                              <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(lead)} title="Editar Lead"><Edit className="h-4 w-4" /></Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive/80"><Trash2 className="h-4 w-4" /></Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                                    <AlertDialogDescription>Esta acción no se puede deshacer. Esto eliminará permanentemente el lead.</AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => handleDelete(lead.id)} className="bg-destructive hover:bg-destructive/90">Eliminar</AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      );
    };

    export default LeadsPage;