import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Clock, DollarSign, ArrowRight } from 'lucide-react';
import { Helmet } from 'react-helmet';

const PublicBookingPage = ({ previewSettings }) => {
    const { userId } = useParams();
    const navigate = useNavigate();

    const [settings, setSettings] = useState(null);
    const [loading, setLoading] = useState(!previewSettings);
    const [error, setError] = useState(null);

    useEffect(() => {
        if (previewSettings) {
            setSettings(previewSettings);
            return;
        }

        const fetchBookingSettings = async () => {
            if (!userId) {
                setError('User ID not provided.');
                setLoading(false);
                return;
            }

            try {
                const { data, error } = await supabase
                    .from('profiles')
                    .select('booking_settings, company_info')
                    .eq('id', userId)
                    .single();

                if (error || !data) {
                    throw new Error('Could not find booking page.');
                }
                
                setSettings({
                  ...data.booking_settings,
                  business_name: data.company_info?.business_name || data.booking_settings?.business_name || 'My Business'
                });
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        fetchBookingSettings();
    }, [userId, previewSettings]);

    const theme = settings?.theme;
    const brandColor = settings?.brand_color;

    const handleEventClick = (eventId) => {
        if (previewSettings) return; // Disable navigation in preview
        navigate(`/book/${userId}/${eventId}`);
    };

    if (loading) {
        return <div className="flex items-center justify-center min-h-screen"><div className="loader"></div></div>;
    }

    if (error) {
        return <div className="flex items-center justify-center min-h-screen text-destructive">{error}</div>;
    }
    
    const pageTheme = theme === 'Dark' ? 'dark' : '';

    return (
        <>
            <Helmet>
                <title>Book a meeting with {settings?.business_name}</title>
            </Helmet>
            <main className={`${pageTheme} min-h-screen bg-background text-foreground transition-colors duration-300 p-4 sm:p-6 md:p-8 flex items-center justify-center`}>
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="w-full max-w-2xl mx-auto"
                >
                    <Card className="overflow-hidden">
                        <CardHeader className="text-center p-8">
                            {settings?.logo && <img-replace src={settings.logo} alt="Business Logo" className="w-20 h-20 mx-auto rounded-full mb-4" />}
                            <CardTitle className="text-3xl font-bold">{settings?.business_name}</CardTitle>
                            <p className="text-muted-foreground">{settings?.about}</p>
                        </CardHeader>
                        <CardContent className="p-4 sm:p-6 space-y-4">
                            {settings?.event_types?.map((event) => (
                                <button
                                    key={event.id}
                                    onClick={() => handleEventClick(event.id)}
                                    disabled={!!previewSettings}
                                    className="w-full text-left p-4 border rounded-lg hover:bg-muted/50 transition-colors flex items-center justify-between disabled:cursor-default disabled:hover:bg-transparent"
                                >
                                    <div>
                                        <p className="font-semibold text-lg">{event.name}</p>
                                        <div className="flex items-center gap-4 text-muted-foreground mt-1">
                                            <span className="flex items-center gap-1.5"><Clock size={14} /> {event.duration} min</span>
                                            <span className="flex items-center gap-1.5"><DollarSign size={14} /> {event.price > 0 ? `${event.price}` : 'Free'}</span>
                                        </div>
                                    </div>
                                    <ArrowRight className="text-muted-foreground" />
                                </button>
                            ))}
                            {(!settings?.event_types || settings.event_types.length === 0) && (
                                <p className="text-center text-muted-foreground py-8">No services available for booking at this time.</p>
                            )}
                        </CardContent>
                    </Card>
                </motion.div>
                <style>{`
                    body { background-color: transparent !important; }
                    ${pageTheme === 'dark' ? `
                      :root { --background: #09090B; --foreground: #FAFAFA; --card: #09090B; --card-foreground: #FAFAFA; --popover: #09090B; --popover-foreground: #FAFAFA; --primary: #FAFAFA; --primary-foreground: #18181B; --secondary: #27272A; --secondary-foreground: #FAFAFA; --muted: #27272A; --muted-foreground: #A1A1AA; --accent: #27272A; --accent-foreground: #FAFAFA; --destructive: #7F1D1D; --destructive-foreground: #FAFAFA; --border: #27272A; --input: #27272A; --ring: #FAFAFA; }
                    ` : `
                      :root { --background: #FFFFFF; --foreground: #09090B; --card: #FFFFFF; --card-foreground: #09090B; --popover: #FFFFFF; --popover-foreground: #09090B; --primary: #18181B; --primary-foreground: #FAFAFA; --secondary: #F4F4F5; --secondary-foreground: #18181B; --muted: #F4F4F5; --muted-foreground: #71717A; --accent: #F4F4F5; --accent-foreground: #18181B; --destructive: #DC2626; --destructive-foreground: #FAFAFA; --border: #E4E4E7; --input: #E4E4E7; --ring: #09090B; }
                    `}
                    ${brandColor ? `
                      .dark { --primary: ${brandColor}; --primary-foreground: #FFFFFF; }
                      :not(.dark) { --primary: ${brandColor}; --primary-foreground: #FFFFFF; }
                    ` : ''}
                `}</style>
            </main>
        </>
    );
};

export default PublicBookingPage;