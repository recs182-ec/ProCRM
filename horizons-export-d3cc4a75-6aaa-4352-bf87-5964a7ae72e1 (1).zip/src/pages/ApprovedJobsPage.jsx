import React, { useState, useEffect, useCallback, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useToast } from '@/components/ui/use-toast';
    import { Input } from '@/components/ui/input';
    import { Button } from '@/components/ui/button';
    import { Briefcase, Plus, Search } from 'lucide-react';
    import { add, formatISO } from 'date-fns';
    import { JobsList } from '@/components/jobs/JobsList';
    import { TaskDialog } from '@/components/jobs/TaskDialog';
    import { ManualJobDialog } from '@/components/jobs/ManualJobDialog';

    const ApprovedJobsPage = () => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [jobs, setJobs] = useState([]);
      const [loading, setLoading] = useState(true);
      const [expandedJob, setExpandedJob] = useState(null);
      const [tasks, setTasks] = useState({});
      const [isTaskDialogOpen, setIsTaskDialogOpen] = useState(false);
      const [currentJob, setCurrentJob] = useState(null);
      const [taskFormData, setTaskFormData] = useState({ service_name: '', service_id: null, due_date: '', value: 0, frequency: 'Única' });
      const [searchTerm, setSearchTerm] = useState('');
      const [isEditingTask, setIsEditingTask] = useState(false);
      const [isManualJobDialogOpen, setIsManualJobDialogOpen] = useState(false);
      const [companies, setCompanies] = useState([]);
      const [savedServices, setSavedServices] = useState([]);

      const fetchCompanies = useCallback(async () => {
        if (!user) return;
        const { data } = await supabase.from('companies').select('id, commercial_name').eq('user_id', user.id);
        setCompanies(data || []);
      }, [user]);

      const fetchSavedServices = useCallback(async () => {
        if (!user) return;
        const { data } = await supabase.from('services').select('id, name, price').eq('user_id', user.id);
        setSavedServices(data || []);
      }, [user]);

      const fetchApprovedJobsAndTasks = useCallback(async () => {
        if (!user) return;
        setLoading(true);

        const { data: taskData, error: taskError } = await supabase
          .from('tasks')
          .select('*, proposals(*, companies(commercial_name))')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });

        if (taskError) {
          toast({ title: 'Error', description: 'No se pudieron cargar las tareas.', variant: 'destructive' });
          setLoading(false);
          return;
        }

        const jobsMap = new Map();
        const tasksByJob = {};

        taskData.forEach(task => {
            let jobKey;
            let jobData;

            if (task.proposal_id && task.proposals) {
                jobKey = task.proposal_id;
                if (!jobsMap.has(jobKey)) {
                    jobData = {
                        ...task.proposals,
                        isManual: false,
                        company_id: task.proposals.company_id,
                    };
                    jobsMap.set(jobKey, jobData);
                }
            } else if (task.company_id && task.company_name) {
                jobKey = `manual-${task.company_id}`;
                 if (!jobsMap.has(jobKey)) {
                    jobData = {
                        id: jobKey,
                        isManual: true,
                        client_name: 'Manual',
                        client_company: task.company_name,
                        companies: { commercial_name: task.company_name },
                        company_id: task.company_id,
                    };
                    jobsMap.set(jobKey, jobData);
                }
            } else {
               return;
            }
            
            if (!tasksByJob[jobKey]) {
                tasksByJob[jobKey] = [];
            }
            tasksByJob[jobKey].push(task);
        });
        
        setJobs(Array.from(jobsMap.values()));
        setTasks(tasksByJob);
        setLoading(false);
      }, [user, toast]);

      useEffect(() => {
        fetchApprovedJobsAndTasks();
        fetchCompanies();
        fetchSavedServices();
      }, [fetchApprovedJobsAndTasks, fetchCompanies, fetchSavedServices]);

      const toggleJobExpansion = (jobId) => {
        setExpandedJob(expandedJob === jobId ? null : jobId);
      };

      const handleOpenTaskDialog = (job, task = null) => {
        setCurrentJob(job);
        if (task) {
          setIsEditingTask(true);
          setTaskFormData({ id: task.id, service_name: task.service_name, service_id: task.service_id, due_date: task.due_date, value: task.value, frequency: task.frequency || 'Única' });
        } else {
          setIsEditingTask(false);
          const defaultDueDate = job?.approved_at ? formatISO(add(new Date(job.approved_at), { days: 30 }), { representation: 'date' }) : '';
          setTaskFormData({ service_name: '', service_id: null, due_date: defaultDueDate, value: 0, frequency: 'Única' });
        }
        setIsTaskDialogOpen(true);
      };

      const handleSaveTask = async (formData, isManualJob = false) => {
        const isEditing = !!formData.id;

        if (!formData.service_name) {
          toast({ title: 'Error', description: 'El nombre del servicio es requerido.', variant: 'destructive' });
          return;
        }
        if (!formData.due_date) {
          toast({ title: 'Error', description: 'La fecha de vencimiento es requerida.', variant: 'destructive' });
          return;
        }
        
        let payload;
        if (isManualJob) {
            if (!formData.company_id) {
                toast({ title: 'Error', description: 'Debe seleccionar una compañía.', variant: 'destructive' });
                return;
            }
            payload = {
                service_name: formData.service_name,
                service_id: formData.service_id,
                due_date: formData.due_date,
                value: formData.value,
                company_id: formData.company_id,
                company_name: formData.company_name,
                user_id: user.id,
                status: 'Pendiente',
                frequency: formData.frequency,
            };
        } else {
            payload = {
                service_name: formData.service_name,
                service_id: formData.service_id,
                due_date: formData.due_date,
                frequency: formData.frequency,
            };
        }
        
        let error;
        if (isEditing) {
          ({ error } = await supabase.from('tasks').update(payload).eq('id', formData.id));
        } else {
            if (!isManualJob) {
                payload = {
                    ...payload,
                    proposal_id: currentJob.isManual ? null : currentJob.id,
                    company_id: currentJob.company_id,
                    company_name: currentJob.companies.commercial_name,
                    user_id: user.id,
                    status: 'Pendiente',
                };
            }
           ({ error } = await supabase.from('tasks').insert(payload).select());
        }

        if (error) {
          toast({ title: 'Error', description: `No se pudo guardar la tarea. ${error.message}`, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: `Tarea guardada.` });
          fetchApprovedJobsAndTasks();
          setIsTaskDialogOpen(false);
          setIsManualJobDialogOpen(false);
        }
      };

      const handleDeleteJob = async (jobId) => {
        const job = jobs.find(j => j.id === jobId);
        if (!job) return;

        const taskIdsToDelete = (tasks[jobId] || []).map(t => t.id);

        if (taskIdsToDelete.length > 0) {
          const { error: tasksError } = await supabase.from('tasks').delete().in('id', taskIdsToDelete);
          if (tasksError) {
            toast({ title: 'Error', description: `No se pudieron eliminar las tareas del trabajo. ${tasksError.message}`, variant: 'destructive' });
            return;
          }
        }
        
        // After deleting tasks, if it's not a manual job (i.e., it comes from a proposal)
        // we can proceed to delete the proposal itself if needed.
        // For now, we only clean up tasks as requested. A proposal might be useful to keep for records.

        toast({ title: 'Éxito', description: 'Trabajo y sus tareas han sido eliminados.' });
        fetchApprovedJobsAndTasks();
      };

      const filteredJobs = useMemo(() => {
        if (!searchTerm) return jobs;
        return jobs.filter(job => 
          (job.companies?.commercial_name || job.client_company).toLowerCase().includes(searchTerm.toLowerCase())
        );
      }, [searchTerm, jobs]);

      return (
        <div className="w-full">
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-4xl font-bold text-gray-800">Trabajos</h1>
                    <p className="text-muted-foreground text-lg">Gestiona tus proyectos y tareas en curso.</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input 
                        placeholder="Buscar por empresa..." 
                        className="pl-10 w-64"
                        value={searchTerm} 
                        onChange={e => setSearchTerm(e.target.value)} 
                    />
                  </div>
                  <Button onClick={() => setIsManualJobDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />Añadir Trabajo Manual
                  </Button>
                </div>
            </div>
          </motion.div>

          {loading ? (
            <div className="text-center py-20"><div className="loader"></div></div>
          ) : filteredJobs.length === 0 ? (
            <div className="text-center py-20">
              <Briefcase className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No hay trabajos</h3>
              <p className="text-muted-foreground">{searchTerm ? 'No se encontraron trabajos.' : 'Cuando una propuesta sea aprobada, aparecerá aquí.'}</p>
            </div>
          ) : (
            <JobsList
              jobs={filteredJobs}
              tasks={tasks}
              expandedJob={expandedJob}
              toggleJobExpansion={toggleJobExpansion}
              onOpenTaskDialog={handleOpenTaskDialog}
              onDeleteJob={handleDeleteJob}
              onTaskUpdate={fetchApprovedJobsAndTasks}
            />
          )}

          <TaskDialog
            isOpen={isTaskDialogOpen}
            onOpenChange={setIsTaskDialogOpen}
            onSave={handleSaveTask}
            taskFormData={taskFormData}
            setTaskFormData={setTaskFormData}
            isEditing={isEditingTask}
            currentJob={currentJob}
            savedServices={savedServices}
          />
          
          <ManualJobDialog 
            isOpen={isManualJobDialogOpen}
            onOpenChange={setIsManualJobDialogOpen}
            onSave={handleSaveTask}
            companies={companies}
            savedServices={savedServices}
          />
        </div>
      );
    };

    export default ApprovedJobsPage;