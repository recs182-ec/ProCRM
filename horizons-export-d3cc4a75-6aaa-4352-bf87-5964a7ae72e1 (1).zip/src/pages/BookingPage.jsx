import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Copy, Link, Plus, Trash, Edit, Clock, DollarSign, Settings, Palette, Image as ImageIcon } from 'lucide-react';
import { Helmet } from 'react-helmet';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
const colors = ['#000000', '#EF4444', '#F97316', '#EAB308', '#84CC16', '#22C55E', '#14B8A6', '#06B6D4', '#3B82F6', '#8B5CF6', '#EC4899'];
const buttonShapes = ['Pill', 'Rounded', 'Rectangle'];
const themes = ['System', 'Light', 'Dark'];
const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const EventTypeDialog = ({
  open,
  setOpen,
  eventType,
  onSave
}) => {
  const [name, setName] = useState('');
  const [duration, setDuration] = useState(30);
  const [price, setPrice] = useState(0);
  useEffect(() => {
    if (eventType) {
      setName(eventType.name || '');
      setDuration(eventType.duration || 30);
      setPrice(eventType.price || 0);
    } else {
      setName('');
      setDuration(30);
      setPrice(0);
    }
  }, [eventType]);
  const handleSave = () => {
    onSave({
      ...eventType,
      name,
      duration,
      price
    });
    setOpen(false);
  };
  return <Dialog open={open} onOpenChange={setOpen}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{eventType ? 'Edit Event Type' : 'Create New Event Type'}</DialogTitle>
                    <DialogDescription>
                        Define a service or meeting that clients can book.
                    </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="event-name">Event Name</Label>
                        <Input id="event-name" value={name} onChange={e => setName(e.target.value)} placeholder="e.g., 30 Minute Meeting" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="event-duration">Duration (minutes)</Label>
                        <Input id="event-duration" type="number" value={duration} onChange={e => setDuration(parseInt(e.target.value, 10))} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="event-price">Price ($)</Label>
                        <Input id="event-price" type="number" value={price} onChange={e => setPrice(parseFloat(e.target.value))} />
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                    <Button onClick={handleSave}>Save</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>;
};
const BookingPage = () => {
  const {
    user
  } = useAuth();
  const {
    toast
  } = useToast();
  const previewChannel = useRef(null);
  const [bookingSettings, setBookingSettings] = useState({
    banner_image: '',
    logo: '',
    business_name: '',
    booking_url_slug: '',
    industry: '',
    about: '',
    brand_color: '#000000',
    button_shape: 'Pill',
    theme: 'System',
    business_hours: daysOfWeek.reduce((acc, day) => ({
      ...acc,
      [day.toLowerCase()]: {
        enabled: day !== 'Saturday' && day !== 'Sunday',
        start: '09:00',
        end: '17:00'
      }
    }), {}),
    event_types: []
  });
  const [isSaving, setIsSaving] = useState(false);
  const [isDialogOpen, setDialogOpen] = useState(false);
  const [currentEventType, setCurrentEventType] = useState(null);
  useEffect(() => {
    previewChannel.current = new BroadcastChannel('booking_preview_channel');
    const fetchSettings = async () => {
      if (user) {
        const {
          data,
          error
        } = await supabase.from('profiles').select('booking_settings').eq('id', user.id).single();
        if (data && data.booking_settings) {
          setBookingSettings(prev => ({
            ...prev,
            ...data.booking_settings
          }));
        } else if (error) {
          console.error("Error fetching booking settings", error);
        }
      }
    };
    fetchSettings();
    return () => {
      previewChannel.current.close();
    };
  }, [user]);
  useEffect(() => {
    if (previewChannel.current) {
      const payload = {
        settings: {
          ...bookingSettings,
          // Pass the user ID so the preview can fetch the correct data
          userId: user?.id
        }
      };
      previewChannel.current.postMessage(payload);
    }
  }, [bookingSettings, user]);
  const handleSettingsChange = (key, value) => {
    setBookingSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };
  const handleHoursChange = (day, field, value) => {
    setBookingSettings(prev => ({
      ...prev,
      business_hours: {
        ...prev.business_hours,
        [day]: {
          ...prev.business_hours[day],
          [field]: value
        }
      }
    }));
  };
  const handleSaveEventType = eventData => {
    let updatedEventTypes;
    if (eventData.id) {
      updatedEventTypes = bookingSettings.event_types.map(et => et.id === eventData.id ? eventData : et);
    } else {
      updatedEventTypes = [...bookingSettings.event_types, {
        ...eventData,
        id: Date.now().toString()
      }];
    }
    handleSettingsChange('event_types', updatedEventTypes);
  };
  const handleDeleteEventType = id => {
    const updatedEventTypes = bookingSettings.event_types.filter(et => et.id !== id);
    handleSettingsChange('event_types', updatedEventTypes);
  };
  const handleSaveSettings = async () => {
    setIsSaving(true);
    const {
      error
    } = await supabase.from('profiles').update({
      booking_settings: bookingSettings
    }).eq('id', user.id);
    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to save settings.',
        variant: 'destructive'
      });
    } else {
      toast({
        title: 'Success',
        description: 'Booking page settings saved.'
      });
    }
    setIsSaving(false);
  };
  const bookingLink = `${window.location.origin}/book/${user?.id}`;
  const previewLink = `${window.location.origin}/booking-preview`;
  return <>
            <Helmet>
                <title>Booking Page Setup | CRM & Propuestas</title>
                <meta name="description" content="Configure your public booking page." />
            </Helmet>
            <motion.div initial={{
      opacity: 0,
      y: 20
    }} animate={{
      opacity: 1,
      y: 0
    }} transition={{
      duration: 0.5
    }} className="space-y-6">
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight">Configuración de Página de Booking</h1>
                        <p className="text-muted-foreground">Customiza tu página de Booking pública para tus clientes.</p>
                    </div>
                    <Button onClick={handleSaveSettings} disabled={isSaving}>
                        {isSaving ? 'Saving...' : 'Save Changes'}
                    </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2 space-y-6">

                        {/* Event Types */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Event Types</CardTitle>
                                <CardDescription>Services or meetings that clients can book.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                {bookingSettings.event_types.map(et => <div key={et.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                                        <div>
                                            <p className="font-semibold">{et.name}</p>
                                            <p className="text-sm text-muted-foreground">
                                                <Clock className="inline h-4 w-4 mr-1" />{et.duration} mins
                                                <DollarSign className="inline h-4 w-4 ml-3 mr-1" />{et.price > 0 ? et.price : 'Free'}
                                            </p>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Button variant="ghost" size="icon" onClick={() => {
                    setCurrentEventType(et);
                    setDialogOpen(true);
                  }}>
                                                <Edit className="h-4 w-4" />
                                            </Button>
                                            <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDeleteEventType(et.id)}>
                                                <Trash className="h-4 w-4" />
                                            </Button>
                                        </div>
                                    </div>)}
                                <Button variant="outline" onClick={() => {
                setCurrentEventType(null);
                setDialogOpen(true);
              }}>
                                    <Plus className="mr-2 h-4 w-4" /> Add Event Type
                                </Button>
                            </CardContent>
                        </Card>
                        
                         {/* Brand Details */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2"><ImageIcon className="h-5 w-5 text-primary" />Brand Details</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="business_name">Nombre de tu Negocio o Marca</Label>
                                    <Input id="business_name" value={bookingSettings.business_name} onChange={e => handleSettingsChange('business_name', e.target.value)} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="about">Sobre tu negocio o marca</Label>
                                    <Textarea id="about" value={bookingSettings.about} onChange={e => handleSettingsChange('about', e.target.value)} />
                                </div>
                            </CardContent>
                        </Card>
                        
                        {/* Appearance */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2"><Palette className="h-5 w-5 text-primary" />Appearance</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="space-y-2">
                                    <Label>Brand Color</Label>
                                    <div className="flex gap-2">
                                        {colors.map(color => <Button key={color} variant="outline" size="icon" style={{
                    backgroundColor: color
                  }} className={`rounded-full h-8 w-8 ${bookingSettings.brand_color === color ? 'ring-2 ring-offset-2 ring-primary' : ''}`} onClick={() => handleSettingsChange('brand_color', color)} />)}
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <Label>Button Shape</Label>
                                    <Select value={bookingSettings.button_shape} onValueChange={v => handleSettingsChange('button_shape', v)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            {buttonShapes.map(shape => <SelectItem key={shape} value={shape}>{shape}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                </div>
                                 <div className="space-y-2">
                                    <Label>Theme</Label>
                                    <Select value={bookingSettings.theme} onValueChange={v => handleSettingsChange('theme', v)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            {themes.map(theme => <SelectItem key={theme} value={theme}>{theme}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Business Hours */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2"><Settings className="h-5 w-5 text-primary" />Business Hours</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                {daysOfWeek.map(day => <div key={day} className="flex items-center justify-between gap-4">
                                        <div className="flex items-center gap-2 w-32">
                                            <Switch checked={bookingSettings.business_hours[day.toLowerCase()]?.enabled} onCheckedChange={checked => handleHoursChange(day.toLowerCase(), 'enabled', checked)} />
                                            <Label>{day}</Label>
                                        </div>
                                        {bookingSettings.business_hours[day.toLowerCase()]?.enabled ? <div className="flex items-center gap-2">
                                                <Input type="time" value={bookingSettings.business_hours[day.toLowerCase()].start} onChange={e => handleHoursChange(day.toLowerCase(), 'start', e.target.value)} />
                                                <span>-</span>
                                                <Input type="time" value={bookingSettings.business_hours[day.toLowerCase()].end} onChange={e => handleHoursChange(day.toLowerCase(), 'end', e.target.value)} />
                                            </div> : <p className="text-muted-foreground">Cerrado</p>}
                                    </div>)}
                            </CardContent>
                        </Card>
                    </div>

                    <div className="space-y-6">
                        <Card>
                             <CardHeader>
                                <CardTitle className="flex items-center gap-2"><Link className="h-5 w-5 text-primary" />Your Booking Link</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex items-center gap-2">
                                    <Input type="text" readOnly value={bookingLink} className="bg-muted" />
                                    <Button variant="outline" size="icon" onClick={() => {
                  navigator.clipboard.writeText(bookingLink);
                  toast({
                    title: 'Copied!'
                  });
                }}>
                                        <Copy className="h-4 w-4" />
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                        <Card className="sticky top-6">
                            <CardHeader>
                                <CardTitle>Live Preview</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="aspect-[9/16] bg-muted border rounded-lg p-2">
                                     <iframe src={previewLink} className="w-full h-full rounded-md" title="Booking Page Preview" />
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </motion.div>
            <EventTypeDialog open={isDialogOpen} setOpen={setDialogOpen} eventType={currentEventType} onSave={handleSaveEventType} />
        </>;
};
export default BookingPage;