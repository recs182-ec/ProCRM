
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Calendar, Clock, DollarSign, CreditCard, Home } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const BookingConfirmationPage = () => {
    const { eventId } = useParams();
    const { toast } = useToast();
    const [event, setEvent] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchEvent = async () => {
            setLoading(true);
            const { data, error } = await supabase
                .from('calendar_events')
                .select('*')
                .eq('id', eventId)
                .single();

            if (error || !data) {
                toast({ title: 'Error', description: 'No se pudo encontrar la cita.', variant: 'destructive' });
                setLoading(false);
                return;
            }
            setEvent(data);
            setLoading(false);
        };

        fetchEvent();
    }, [eventId, toast]);

    const handlePayment = () => {
        toast({
            title: '🚧 Función en desarrollo',
            description: 'La pasarela de pago aún no está conectada. ¡El equipo está trabajando en ello! 🚀',
        });
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-background">
                <div className="loader"></div>
            </div>
        );
    }

    if (!event) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-background">
                <p>Cita no encontrada.</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-lg text-center shadow-xl">
                <CardHeader className="bg-green-500 text-white p-6 rounded-t-lg">
                    <CheckCircle className="mx-auto h-12 w-12" />
                    <CardTitle className="text-2xl mt-4">¡Cita Confirmada!</CardTitle>
                    <CardDescription className="text-green-100">Recibirás un correo electrónico con la confirmación.</CardDescription>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                    <h3 className="font-semibold text-lg">{event.title}</h3>
                    <div className="text-muted-foreground space-y-2">
                        <p className="flex items-center justify-center gap-2">
                            <Calendar className="h-4 w-4" />
                            <span>{format(new Date(event.start_time), "EEEE, d 'de' MMMM, yyyy", { locale: es })}</span>
                        </p>
                        <p className="flex items-center justify-center gap-2">
                            <Clock className="h-4 w-4" />
                            <span>{format(new Date(event.start_time), 'p', { locale: es })} - {format(new Date(event.end_time), 'p', { locale: es })}</span>
                        </p>
                        {event.price > 0 && (
                            <p className="flex items-center justify-center gap-2">
                                <DollarSign className="h-4 w-4" />
                                <span>Costo: ${event.price.toFixed(2)}</span>
                            </p>
                        )}
                    </div>
                    
                    {event.price > 0 && !event.paid && (
                        <div className="pt-4">
                            <Button size="lg" className="w-full" onClick={handlePayment}>
                                <CreditCard className="mr-2 h-5 w-5" />
                                Pagar Ahora (${event.price.toFixed(2)})
                            </Button>
                        </div>
                    )}

                    <div className="pt-4">
                        <Button variant="outline" asChild>
                            <Link to="/">
                                <Home className="mr-2 h-4 w-4" />
                                Volver al Inicio
                            </Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

export default BookingConfirmationPage;
