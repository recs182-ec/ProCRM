import React, { useState, useRef, useEffect } from 'react';
    import { useDroppable } from '@dnd-kit/core';
    import { useSortable, SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
    import { CSS } from '@dnd-kit/utilities';
    import PipelineCard from '@/pages/pipeline/PipelineCard';
    import { CardContent, CardHeader } from '@/components/ui/card';
    import { Badge } from '@/components/ui/badge';
    import { Input } from '@/components/ui/input';
    import { GripVertical, Pencil, Trash2 } from 'lucide-react';
    import { Button } from '@/components/ui/button';

    const PipelineColumn = ({ stage, tasks, onRename, onDelete }) => {
        const { setNodeRef: setDroppableNodeRef, isOver } = useDroppable({ 
          id: stage.id,
          data: {
            type: 'column',
            stage: stage,
          }
        });
        
        const {
            attributes,
            listeners,
            setNodeRef: setSortableNodeRef,
            transform,
            transition,
            isDragging,
        } = useSortable({ 
            id: stage.id,
            data: {
                type: 'column',
                stage: stage
            }
        });

        const style = {
            transform: CSS.Transform.toString(transform),
            transition,
            opacity: isDragging ? 0.5 : 1,
        };
        
        const setCombinedNodeRef = (node) => {
            setDroppableNodeRef(node);
            setSortableNodeRef(node);
        };

        const [isEditing, setIsEditing] = useState(false);
        const [title, setTitle] = useState(stage.name);
        const [isHovered, setIsHovered] = useState(false);
        const inputRef = useRef(null);

        useEffect(() => {
            if (isEditing) {
                inputRef.current?.focus();
                inputRef.current?.select();
            }
        }, [isEditing]);
        
        useEffect(() => {
            setTitle(stage.name);
        }, [stage.name]);

        const handleTitleClick = () => {
            setIsEditing(true);
        };

        const handleBlur = () => {
            setIsEditing(false);
            if (title.trim() && title !== stage.name) {
                onRename(stage.id, title);
            } else {
                setTitle(stage.name);
            }
        };

        const handleKeyDown = (e) => {
            if (e.key === 'Enter') {
                inputRef.current?.blur();
            } else if (e.key === 'Escape') {
                setTitle(stage.name);
                setIsEditing(false);
            }
        };

        return (
            <div
                ref={setCombinedNodeRef}
                style={style}
                className="w-72 flex-shrink-0 h-full flex flex-col"
            >
              <div className={`flex flex-col h-full bg-gray-100 rounded-lg ${isOver ? 'bg-primary/10' : ''}`}>
                <CardHeader
                    onMouseEnter={() => setIsHovered(true)}
                    onMouseLeave={() => setIsHovered(false)}
                    className="p-3 border-b sticky top-0 bg-gray-100 z-10 rounded-t-lg"
                >
                    <div className="flex justify-between items-center gap-2">
                        <div {...attributes} {...listeners} className="flex items-center gap-2 flex-grow min-w-0 cursor-grab active:cursor-grabbing">
                            <GripVertical className="h-5 w-5 text-gray-400 flex-shrink-0" />
                            {isEditing ? (
                                <Input
                                    ref={inputRef}
                                    value={title}
                                    onChange={(e) => setTitle(e.target.value)}
                                    onBlur={handleBlur}
                                    onKeyDown={handleKeyDown}
                                    className="h-8 text-base font-semibold"
                                />
                            ) : (
                                <div className="flex items-center gap-2 flex-grow min-w-0" onClick={handleTitleClick}>
                                    <h3 className="text-base font-semibold text-gray-700 cursor-pointer hover:text-primary transition-colors truncate">
                                        {stage.name}
                                    </h3>
                                    {isHovered && <Pencil className="h-3 w-3 text-gray-500" />}
                                </div>
                            )}
                        </div>
                        <div className="flex items-center flex-shrink-0">
                            <Badge variant="secondary" className="mr-2">{tasks.length}</Badge>
                            {isHovered && (
                                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onDelete(stage.id)}>
                                    <Trash2 className="h-4 w-4 text-gray-500 hover:text-destructive" />
                                </Button>
                            )}
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="p-2 h-full min-h-[calc(100vh-250px)] overflow-y-auto flex-grow">
                    <SortableContext items={tasks.map(t => t.id)} strategy={verticalListSortingStrategy}>
                        <div className="space-y-2">
                          {tasks.map(task => (
                              <PipelineCard key={task.id} task={task} stage={stage.name} />
                          ))}
                        </div>
                    </SortableContext>
                </CardContent>
              </div>
            </div>
        );
    };

    export default PipelineColumn;