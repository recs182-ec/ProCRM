
    import React, { useState, useEffect, useCallback, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
    import { LayoutGrid, List, Plus } from 'lucide-react';
    import PipelineBoardView from './PipelineBoardView';
    import PipelineListView from './PipelineListView';
    import { useToast } from '@/components/ui/use-toast';
    import { Button } from '@/components/ui/button';
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
    } from "@/components/ui/alert-dialog";

    const defaultStages = ["Propuesta Enviada", "Negociación", "Aprobado", "Rechazado"];

    const PipelinePage = () => {
      const { user } = useAuth();
      const [proposals, setProposals] = useState([]);
      const [loading, setLoading] = useState(true);
      const [pipelineStages, setPipelineStages] = useState([]);
      const { toast } = useToast();
      const [dialogState, setDialogState] = useState({ isOpen: false, stageId: null, isDelete: false });

      const fetchPipelineStages = useCallback(async () => {
        if (!user) return;
        setLoading(true);
        const { data, error } = await supabase
          .from('pipeline_stages')
          .select('*')
          .eq('user_id', user.id)
          .order('position', { ascending: true });

        if (error) {
          console.error("Error fetching pipeline stages:", error);
          toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar las etapas del pipeline.' });
          setLoading(false);
          return;
        }

        if (data && data.length > 0) {
          setPipelineStages(data);
        } else {
          const initialStages = defaultStages.map((name, index) => ({
            user_id: user.id,
            name,
            position: index,
          }));
          const { data: newStages, error: insertError } = await supabase
            .from('pipeline_stages')
            .insert(initialStages)
            .select();
          
          if (insertError) {
              if (insertError.code !== '23505') { // 23505 is unique_violation
                 console.error("Error creating initial stages:", insertError);
                 toast({ variant: 'destructive', title: 'Error', description: `No se pudieron crear las etapas iniciales: ${insertError.message}` });
              } else {
                const { data: existingStages, error: refetchError } = await supabase
                    .from('pipeline_stages')
                    .select('*')
                    .eq('user_id', user.id)
                    .order('position', { ascending: true });
                if (refetchError) console.error("Error refetching stages after unique violation:", refetchError);
                else setPipelineStages(existingStages || []);
              }
          } else {
            setPipelineStages(newStages || []);
          }
        }
        setLoading(false);
      }, [user, toast]);

      const fetchProposals = useCallback(async () => {
        if (!user) return;
        const { data, error } = await supabase
          .from('proposals')
          .select('*, companies(commercial_name)')
          .eq('user_id', user.id)
          .in('status', ['sent', 'approved', 'rejected']);

        if (error) {
          console.error('Error fetching proposals:', error);
          toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar las propuestas.' });
        } else {
          const proposalsWithType = data.map(p => ({ ...p, type: 'proposal' }));
          setProposals(proposalsWithType);
        }
      }, [user, toast]);

      useEffect(() => {
        if (user?.id) {
          fetchPipelineStages();
          fetchProposals();
          const channel = supabase.channel('realtime:proposals')
            .on('postgres_changes', { event: '*', schema: 'public', table: 'proposals', filter: `user_id=eq.${user.id}` }, 
              () => fetchProposals()
            )
            .subscribe();

          return () => {
            supabase.removeChannel(channel);
          };
        }
      }, [fetchProposals, fetchPipelineStages, user]);

      const proposalsByStage = useMemo(() => {
        const stageNames = pipelineStages.map(s => s.name);
        const initial = stageNames.reduce((acc, stage) => ({ ...acc, [stage]: [] }), {});
        
        if (!proposals || !Array.isArray(proposals)) return initial;
        
        return proposals.reduce((acc, proposal) => {
          let stage = proposal.pipeline_stage || 'Propuesta Enviada';
          if (!stageNames.includes(stage)) {
              stage = 'Propuesta Enviada';
          }
          if (acc[stage]) {
            acc[stage].push(proposal);
          }
          return acc;
        }, initial);
      }, [proposals, pipelineStages]);

      const handleUpdateProposalStage = async (proposalId, newStageName) => {
        const originalProposals = [...proposals];
        const updatedProposals = proposals.map(p => p.id === proposalId ? { ...p, pipeline_stage: newStageName } : p);
        setProposals(updatedProposals);
        
        const { error } = await supabase
          .from('proposals')
          .update({ pipeline_stage: newStageName })
          .eq('id', proposalId);

        if (error) {
          console.error('Error updating proposal stage:', error);
          setProposals(originalProposals);
          toast({ variant: 'destructive', title: 'Error', description: 'No se pudo mover la propuesta.' });
        }
      };

      const handleAddStage = async () => {
        let newStageName = `Nueva Etapa`;
        let suffix = 1;
        while(pipelineStages.some(s => s.name === newStageName)) {
            newStageName = `Nueva Etapa ${suffix++}`;
        }
        
        const updatedStages = await Promise.all(pipelineStages.map(async (stage) => {
          const { error } = await supabase
            .from('pipeline_stages')
            .update({ position: stage.position + 1 })
            .eq('id', stage.id);
          if (error) console.error("Error updating stage position:", error);
          return { ...stage, position: stage.position + 1 };
        }));

        const { data, error } = await supabase
            .from('pipeline_stages')
            .insert({ user_id: user.id, name: newStageName, position: 0 })
            .select()
            .single();

        if (error) {
            console.error('Error adding new stage:', error);
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo crear la nueva etapa. ${error.message}` });
        } else {
            setPipelineStages([data, ...updatedStages]);
            toast({ title: '¡Éxito!', description: `Etapa "${newStageName}" creada.` });
        }
      };

      const handleRenameStage = async (stageId, newName) => {
        if (!newName.trim()) {
            toast({ variant: 'destructive', title: 'Error', description: 'El nombre no puede estar vacío.' });
            return;
        }

        if (pipelineStages.some(s => s.id !== stageId && s.name === newName)) {
            toast({ variant: 'destructive', title: 'Error', description: 'Ya existe una etapa con este nombre.' });
            fetchPipelineStages();
            return;
        }

        const oldStage = pipelineStages.find(s => s.id === stageId);
        const oldName = oldStage.name;

        const updatedStages = pipelineStages.map(s => s.id === stageId ? { ...s, name: newName } : s);
        setPipelineStages(updatedStages);

        const updatedProposals = proposals.map(p => p.pipeline_stage === oldName ? { ...p, pipeline_stage: newName } : p);
        setProposals(updatedProposals);

        const { error } = await supabase
            .from('pipeline_stages')
            .update({ name: newName })
            .eq('id', stageId);

        if (error) {
            console.error('Error renaming stage:', error);
            setPipelineStages(pipelineStages); 
            setProposals(proposals); 
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo renombrar la etapa. ${error.message}` });
        } else {
            await supabase
                .from('proposals')
                .update({ pipeline_stage: newName })
                .eq('user_id', user.id)
                .eq('pipeline_stage', oldName);
            
            toast({ title: '¡Éxito!', description: `Etapa renombrada a "${newName}".` });
        }
      };
      
      const handleReorderStages = async (reorderedStages) => {
        setPipelineStages(reorderedStages);
        const updates = reorderedStages.map((stage, index) =>
          supabase
            .from('pipeline_stages')
            .update({ position: index })
            .eq('id', stage.id)
        );
        const results = await Promise.all(updates);
        if (results.some(res => res.error)) {
          toast({ variant: 'destructive', title: 'Error', description: 'No se pudo guardar el nuevo orden.' });
          fetchPipelineStages();
        } else {
          toast({ title: '¡Éxito!', description: 'Orden de etapas guardado.' });
        }
      };

      const handleDeleteStageRequest = (stageId) => {
        const stageToDelete = pipelineStages.find(s => s.id === stageId);
        if (!stageToDelete) return;

        const proposalsInStage = proposalsByStage[stageToDelete.name] || [];
        if (proposalsInStage.length > 0) {
          setDialogState({ isOpen: true, stageId: null, isDelete: false });
        } else {
          setDialogState({ isOpen: true, stageId, isDelete: true });
        }
      };

      const confirmDeleteStage = async () => {
        if (!dialogState.stageId) return;

        const { error } = await supabase
          .from('pipeline_stages')
          .delete()
          .eq('id', dialogState.stageId);

        if (error) {
          toast({ variant: 'destructive', title: 'Error', description: 'No se pudo eliminar la etapa.' });
        } else {
          setPipelineStages(prev => prev.filter(s => s.id !== dialogState.stageId));
          toast({ title: '¡Éxito!', description: 'Etapa eliminada.' });
        }
        setDialogState({ isOpen: false, stageId: null, isDelete: false });
      };

      return (
        <div className="w-full">
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
             <div className="flex justify-between items-center">
              <div>
                <h1 className="text-4xl font-bold text-gray-800">Pipeline de Ventas</h1>
                <p className="text-muted-foreground text-lg">Visualiza y gestiona el flujo de tus propuestas.</p>
              </div>
              <Button onClick={handleAddStage}>
                <Plus className="h-4 w-4 mr-2" />
                Añadir Etapa
              </Button>
            </div>
          </motion.div>

          <Tabs defaultValue="board" className="w-full">
            <div className="flex justify-end mb-4">
                <TabsList>
                    <TabsTrigger value="board"><LayoutGrid className="h-4 w-4 mr-2" /> Tablero</TabsTrigger>
                    <TabsTrigger value="list"><List className="h-4 w-4 mr-2" /> Lista</TabsTrigger>
                </TabsList>
            </div>
            <TabsContent value="board">
                <PipelineBoardView 
                    loading={loading}
                    pipelineStages={pipelineStages}
                    proposalsByStage={proposalsByStage}
                    onUpdateProposalStage={handleUpdateProposalStage}
                    onRenameStage={handleRenameStage}
                    onReorderStages={handleReorderStages}
                    onDeleteStage={handleDeleteStageRequest}
                />
            </TabsContent>
            <TabsContent value="list">
                 <PipelineListView 
                    loading={loading}
                    tasks={proposals}
                />
            </TabsContent>
          </Tabs>
          
          <AlertDialog open={dialogState.isOpen} onOpenChange={(isOpen) => setDialogState({ ...dialogState, isOpen })}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>
                  {dialogState.isDelete ? '¿Estás seguro?' : 'Acción no permitida'}
                </AlertDialogTitle>
                <AlertDialogDescription>
                  {dialogState.isDelete
                    ? 'Esta acción no se puede deshacer. La etapa se eliminará permanentemente.'
                    : 'No se puede eliminar una etapa que contiene propuestas. Por favor, mueva todas las propuestas a otra etapa antes de eliminarla.'}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setDialogState({ isOpen: false, stageId: null, isDelete: false })}>
                  {dialogState.isDelete ? 'Cancelar' : 'Entendido'}
                </AlertDialogCancel>
                {dialogState.isDelete && (
                  <AlertDialogAction onClick={confirmDeleteStage}>
                    Eliminar
                  </AlertDialogAction>
                )}
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      );
    };

    export default PipelinePage;
  