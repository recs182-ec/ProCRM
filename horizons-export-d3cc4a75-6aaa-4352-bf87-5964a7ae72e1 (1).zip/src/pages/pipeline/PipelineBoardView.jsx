import React from 'react';
    import {
        DndContext,
        closestCenter,
        PointerSensor,
        useSensor,
        useSensors,
        DragOverlay,
    } from '@dnd-kit/core';
    import {
        SortableContext,
        horizontalListSortingStrategy,
        arrayMove
    } from '@dnd-kit/sortable';
    import PipelineColumn from './PipelineColumn';
    import PipelineCard from './PipelineCard';

    const PipelineBoardView = ({ loading, pipelineStages, proposalsByStage, onUpdateProposalStage, onRenameStage, onReorderStages, onDeleteStage }) => {
        const [activeId, setActiveId] = React.useState(null);

        const sensors = useSensors(
            useSensor(PointerSensor, {
              activationConstraint: {
                distance: 10,
              },
            })
        );
        
        const activeItem = React.useMemo(() => {
            if (!activeId) return null;
            
            const activeStage = pipelineStages.find(s => s.id === activeId);
            if (activeStage) return { ...activeStage, type: 'column' };

            for (const stage of pipelineStages) {
                const card = proposalsByStage[stage.name]?.find(c => c.id === activeId);
                if (card) return { ...card, type: 'proposal' };
            }
            return null;
        }, [activeId, pipelineStages, proposalsByStage]);

        const handleDragStart = (event) => {
            setActiveId(event.active.id);
        };
        
        const handleDragEnd = (event) => {
            const { active, over } = event;
            setActiveId(null);
            if (!over) return;
            
            const activeId = active.id;
            const overId = over.id;
            const activeIsColumn = active.data.current?.type === 'column';
            
            if (activeIsColumn) {
                if (activeId !== overId) {
                    const oldIndex = pipelineStages.findIndex(s => s.id === activeId);
                    
                    let newIndex;
                    const overIsColumn = pipelineStages.some(s => s.id === overId);

                    if (overIsColumn) {
                        newIndex = pipelineStages.findIndex(s => s.id === overId);
                    } else {
                        const overCardStageName = over.data.current?.stage;
                        if(overCardStageName){
                            newIndex = pipelineStages.findIndex(s => s.name === overCardStageName);
                        } else {
                            newIndex = oldIndex; 
                        }
                    }

                    if (oldIndex !== newIndex) {
                        const newOrder = arrayMove(pipelineStages, oldIndex, newIndex);
                        onReorderStages(newOrder);
                    }
                }
                return;
            }


            const activeContainerId = active.data.current?.stage;
            const overContainerId = over.data.current?.type === 'column' ? over.data.current.stage.name : over.data.current?.stage;
            
            if (!activeContainerId || !overContainerId || activeContainerId === overContainerId) {
              return;
            }

            onUpdateProposalStage(activeId, overContainerId);
        };

        const handleDragCancel = () => {
            setActiveId(null);
        };
        
        if (loading) {
            return <div className="flex justify-center items-center h-96"><div className="loader"></div></div>
        }
      
        return (
            <div className="flex flex-col">
                <DndContext 
                    sensors={sensors} 
                    collisionDetection={closestCenter} 
                    onDragStart={handleDragStart}
                    onDragEnd={handleDragEnd}
                    onDragCancel={handleDragCancel}
                >
                    <SortableContext items={pipelineStages.map(s => s.id)} strategy={horizontalListSortingStrategy}>
                        <div className="flex gap-4 overflow-x-auto pb-4">
                            {pipelineStages.map((stage) => (
                              <PipelineColumn 
                                  key={stage.id} 
                                  stage={stage} 
                                  tasks={proposalsByStage[stage.name] || []}
                                  onRename={onRenameStage}
                                  onDelete={onDeleteStage}
                              />
                            ))}
                        </div>
                    </SortableContext>
                    <DragOverlay>
                        {activeItem?.type === 'proposal' ? <PipelineCard task={activeItem} isOverlay /> : null}
                        {activeItem?.type === 'column' ? <div className="bg-gray-200 p-4 rounded-lg shadow-lg opacity-90 h-full w-72 flex items-center justify-center font-bold">{activeItem.name}</div> : null}
                    </DragOverlay>
                </DndContext>
            </div>
        );
    };

    export default PipelineBoardView;