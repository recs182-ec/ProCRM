
    import React, { useState, useEffect, useCallback, useMemo } from 'react';
    import FullCalendar from '@fullcalendar/react';
    import dayGridPlugin from '@fullcalendar/daygrid';
    import timeGridPlugin from '@fullcalendar/timegrid';
    import interactionPlugin from '@fullcalendar/interaction';
    import esLocale from '@fullcalendar/core/locales/es';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import {
      Dialog,
      DialogContent,
      DialogHeader,
      DialogTitle,
      DialogFooter,
    } from '@/components/ui/dialog';
    import { Input } from '@/components/ui/input';
    import { Textarea } from '@/components/ui/textarea';
    import { Button } from '@/components/ui/button';
    import { useToast } from '@/components/ui/use-toast';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
    import { Label } from "@/components/ui/label";
    import { CalendarPlus as CalendarIcon } from 'lucide-react';
    
    const eventTypeColors = {
      reminder: '#8b5cf6', // purple
      meeting: '#3b82f6', // blue
      appointment: '#22c55e', // green
      deadline: '#6b7280', // gray
    };
    
    export default function CalendarPage() {
      const [events, setEvents] = useState([]);
      const [isDialogOpen, setIsDialogOpen] = useState(false);
      const [selectedEvent, setSelectedEvent] = useState(null);
      const [newEventInfo, setNewEventInfo] = useState(null);
      const [isEditMode, setIsEditMode] = useState(false);
      const { user, profile } = useAuth();
      const { toast } = useToast();
    
      const isAppointmentModuleActive = useMemo(() => profile?.module_settings?.appointment_scheduling === true, [profile]);
    
      const fetchEvents = useCallback(async () => {
        if (!user) return;
    
        const { data: calendarData, error: calendarError } = await supabase
          .from('calendar_events')
          .select('*')
          .eq('user_id', user.id);
    
        if (calendarError) {
          console.error('Error fetching calendar events:', calendarError);
          toast({ title: 'Error', description: 'No se pudieron cargar los eventos del calendario.', variant: 'destructive' });
          return;
        }
    
        const { data: tasksData, error: tasksError } = await supabase
          .from('tasks')
          .select('id, service_name, due_date, company_name, status, proposal:proposals(appointment_datetime)')
          .eq('user_id', user.id)
          .eq('status', 'Pendiente')
          .eq('show_in_calendar', true);
    
        if (tasksError) {
          console.error('Error fetching tasks:', tasksError);
          toast({ title: 'Error', description: 'No se pudieron cargar las fechas límite de los trabajos.', variant: 'destructive' });
          return;
        }
    
        const calendarEvents = calendarData.map(event => {
          // Map 'booking' type from old system to 'appointment' for display
          const type = event.event_type === 'booking' ? 'appointment' : event.event_type;
          const color = eventTypeColors[type] || eventTypeColors.reminder;
          
          return {
            id: event.id,
            title: event.title,
            start: event.start_time,
            end: event.end_time,
            allDay: !event.start_time.includes('T'),
            extendedProps: {
              description: event.description,
              type: type,
              isTask: false,
            },
            backgroundColor: color,
            borderColor: color,
          };
        });
    
        const taskEvents = tasksData.map(task => {
          const appointmentTime = task.proposal?.appointment_datetime;
          const hasTime = isAppointmentModuleActive && appointmentTime;
          const type = hasTime ? 'appointment' : 'deadline';
          const color = eventTypeColors[type];
          
          return {
            id: `task-${task.id}`,
            title: `${task.company_name || 'Sin Empresa'}: ${task.service_name}`,
            start: hasTime ? appointmentTime : task.due_date,
            allDay: !hasTime,
            extendedProps: {
              description: `Fecha límite para la tarea: ${task.service_name}`,
              type: type,
              isTask: true,
              taskId: task.id,
              companyName: task.company_name,
              serviceName: task.service_name,
              appointmentTime: appointmentTime,
            },
            backgroundColor: color,
            borderColor: color,
          };
        });
    
        const sortedEvents = [...calendarEvents, ...taskEvents].sort((a, b) => {
          if (a.allDay && !b.allDay) return -1;
          if (!a.allDay && b.allDay) return 1;
          return new Date(a.start) - new Date(b.start);
        });
    
        setEvents(sortedEvents);
      }, [user, toast, isAppointmentModuleActive]);
    
      useEffect(() => {
        fetchEvents();
      }, [fetchEvents]);
    
      const handleDateClick = (arg) => {
        setNewEventInfo({
          start_time: arg.date,
          end_time: new Date(arg.date.getTime() + 60 * 60 * 1000),
          title: '',
          description: '',
          event_type: 'reminder'
        });
        setSelectedEvent(null);
        setIsEditMode(true);
        setIsDialogOpen(true);
      };
    
      const handleEventClick = (clickInfo) => {
        const eventData = {
          id: clickInfo.event.id,
          title: clickInfo.event.title,
          start_time: clickInfo.event.start,
          end_time: clickInfo.event.end,
          description: clickInfo.event.extendedProps.description,
          event_type: clickInfo.event.extendedProps.type,
          isTask: clickInfo.event.extendedProps.isTask,
          taskId: clickInfo.event.extendedProps.taskId,
          companyName: clickInfo.event.extendedProps.companyName,
          serviceName: clickInfo.event.extendedProps.serviceName,
          appointmentTime: clickInfo.event.extendedProps.appointmentTime,
        };
        setSelectedEvent(eventData);
        setNewEventInfo(eventData);
        setIsEditMode(false);
        setIsDialogOpen(true);
      };
    
      const handleCloseDialog = () => {
        setIsDialogOpen(false);
        setSelectedEvent(null);
        setNewEventInfo(null);
        setIsEditMode(false);
      };
    
      const handleSaveEvent = async () => {
        if (!user || !newEventInfo || !newEventInfo.title) {
            toast({ title: 'Error', description: 'El título es obligatorio.', variant: 'destructive' });
            return;
        }
    
        const eventToSave = {
            user_id: user.id,
            title: newEventInfo.title,
            description: newEventInfo.description,
            start_time: newEventInfo.start_time.toISOString(),
            end_time: newEventInfo.end_time ? newEventInfo.end_time.toISOString() : null,
            event_type: newEventInfo.event_type
        };
    
        let error;
        if (selectedEvent?.id && !selectedEvent.isTask) {
            const { error: updateError } = await supabase
                .from('calendar_events')
                .update(eventToSave)
                .eq('id', selectedEvent.id);
            error = updateError;
        } else {
            const { error: insertError } = await supabase
                .from('calendar_events')
                .insert(eventToSave);
            error = insertError;
        }
        
        if (error) {
            console.error('Error saving event:', error);
            toast({ title: 'Error', description: 'No se pudo guardar el evento.', variant: 'destructive' });
        } else {
            toast({ title: 'Éxito', description: `Evento ${selectedEvent?.id && !selectedEvent.isTask ? 'actualizado' : 'creado'} correctamente.` });
            fetchEvents();
            handleCloseDialog();
        }
      };
      
      const handleDeleteEvent = async () => {
        if (!selectedEvent?.id || selectedEvent.isTask) return;
        
        const { error } = await supabase
          .from('calendar_events')
          .delete()
          .eq('id', selectedEvent.id);
    
        if (error) {
          console.error('Error deleting event:', error);
          toast({ title: 'Error', description: 'No se pudo eliminar el evento.', variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: 'Evento eliminado correctamente.' });
          fetchEvents();
          handleCloseDialog();
        }
      };
    
      const handleHideTaskEvent = async () => {
        if (!selectedEvent?.isTask || !selectedEvent.taskId) return;
    
        const { error } = await supabase
          .from('tasks')
          .update({ show_in_calendar: false })
          .eq('id', selectedEvent.taskId);
    
        if (error) {
          console.error('Error hiding task event:', error);
          toast({ title: 'Error', description: 'No se pudo ocultar la tarea del calendario.', variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: 'La tarea ha sido ocultada del calendario.' });
          fetchEvents();
          handleCloseDialog();
        }
      };
    
      const handleGoogleConnect = () => {
        toast({
          title: "🚧 ¡Función en desarrollo!",
          description: "La integración con Google Calendar estará disponible pronto.",
        });
      };
    
      const dialogContent = useMemo(() => {
        if (!isDialogOpen || !selectedEvent) {
          return null;
        }
    
        if (selectedEvent.isTask) {
            const isAppointment = selectedEvent.event_type === 'appointment';
            return (
              <>
                <DialogHeader>
                  <DialogTitle>{isAppointment ? 'Cita de Trabajo' : 'Vencimiento de Tarea'}</DialogTitle>
                </DialogHeader>
                <div className="py-4 space-y-2">
                  <p><strong>Empresa:</strong> {selectedEvent.companyName || 'N/A'}</p>
                  <p><strong>Tarea:</strong> {selectedEvent.serviceName}</p>
                  <p>
                    <strong>{isAppointment ? 'Fecha y Hora:' : 'Fecha Límite:'}</strong>{' '}
                    {isAppointment
                      ? new Date(selectedEvent.appointmentTime).toLocaleString()
                      : new Date(selectedEvent.start_time).toLocaleDateString()}
                  </p>
                </div>
                <DialogFooter className="justify-between">
                  <Button variant="outline" onClick={handleHideTaskEvent}>Ocultar del Calendario</Button>
                  <Button variant="outline" onClick={handleCloseDialog}>Cerrar</Button>
                </DialogFooter>
              </>
            );
        }
        
        if (isEditMode) {
          return (
            <>
              <DialogHeader>
                <DialogTitle>{selectedEvent.id ? 'Editar Evento' : 'Crear Nuevo Evento'}</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <Input
                  placeholder="Título del evento"
                  value={newEventInfo?.title || ''}
                  onChange={(e) => setNewEventInfo({ ...newEventInfo, title: e.target.value })}
                />
                <Textarea
                  placeholder="Descripción"
                  value={newEventInfo?.description || ''}
                  onChange={(e) => setNewEventInfo({ ...newEventInfo, description: e.target.value })}
                />
                <div>
                  <Label>Tipo de evento</Label>
                  <Select
                      value={newEventInfo?.event_type || 'reminder'}
                      onValueChange={(value) => setNewEventInfo({ ...newEventInfo, event_type: value })}
                  >
                      <SelectTrigger>
                          <SelectValue placeholder="Selecciona un tipo" />
                      </SelectTrigger>
                      <SelectContent>
                          <SelectItem value="reminder">Recordatorio</SelectItem>
                          <SelectItem value="meeting">Reunión</SelectItem>
                          <SelectItem value="appointment">Cita</SelectItem>
                      </SelectContent>
                  </Select>
                </div>
                <div>
                    <Label>Inicio</Label>
                    <Input
                        type="datetime-local"
                        value={newEventInfo?.start_time ? new Date(newEventInfo.start_time.getTime() - newEventInfo.start_time.getTimezoneOffset() * 60000).toISOString().slice(0, 16) : ''}
                        onChange={(e) => setNewEventInfo({ ...newEventInfo, start_time: new Date(e.target.value) })}
                    />
                </div>
                <div>
                    <Label>Fin</Label>
                    <Input
                        type="datetime-local"
                        value={newEventInfo?.end_time ? new Date(newEventInfo.end_time.getTime() - newEventInfo.end_time.getTimezoneOffset() * 60000).toISOString().slice(0, 16) : ''}
                        onChange={(e) => setNewEventInfo({ ...newEventInfo, end_time: new Date(e.target.value) })}
                    />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={handleCloseDialog}>Cancelar</Button>
                <Button onClick={handleSaveEvent}>Guardar Cambios</Button>
              </DialogFooter>
            </>
          );
        }
    
        const typeLabels = {
          meeting: 'Reunión',
          reminder: 'Recordatorio',
          appointment: 'Cita'
        };
    
        return (
          <>
            <DialogHeader>
              <DialogTitle>{selectedEvent?.title}</DialogTitle>
            </DialogHeader>
            <div className="py-4 space-y-2">
                <p><strong>Tipo:</strong> <span className="capitalize">{typeLabels[selectedEvent?.event_type] || 'Evento'}</span></p>
                <p><strong>Descripción:</strong> {selectedEvent?.description || 'Sin descripción'}</p>
                <p><strong>Inicio:</strong> {selectedEvent?.start_time ? new Date(selectedEvent.start_time).toLocaleString() : 'N/A'}</p>
                <p><strong>Fin:</strong> {selectedEvent?.end_time ? new Date(selectedEvent.end_time).toLocaleString() : 'N/A'}</p>
            </div>
            <DialogFooter>
              <Button variant="destructive" onClick={handleDeleteEvent}>Eliminar</Button>
              <Button onClick={() => setIsEditMode(true)}>Editar</Button>
            </DialogFooter>
          </>
        );
      }, [isDialogOpen, isEditMode, newEventInfo, selectedEvent, handleSaveEvent, handleDeleteEvent, handleCloseDialog, handleHideTaskEvent]);
      
      const creationDialogContent = useMemo(() => {
        if (!isDialogOpen || !isEditMode || selectedEvent) return null;
        return (
            <>
                <DialogHeader>
                    <DialogTitle>Crear Nuevo Evento</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                    <Input
                        placeholder="Título del evento"
                        value={newEventInfo?.title || ''}
                        onChange={(e) => setNewEventInfo({ ...newEventInfo, title: e.target.value })}
                    />
                    <Textarea
                        placeholder="Descripción"
                        value={newEventInfo?.description || ''}
                        onChange={(e) => setNewEventInfo({ ...newEventInfo, description: e.target.value })}
                    />
                    <div>
                        <Label>Tipo de evento</Label>
                        <Select
                            value={newEventInfo?.event_type || 'reminder'}
                            onValueChange={(value) => setNewEventInfo({ ...newEventInfo, event_type: value })}
                        >
                            <SelectTrigger>
                                <SelectValue placeholder="Selecciona un tipo" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="reminder">Recordatorio</SelectItem>
                                <SelectItem value="meeting">Reunión</SelectItem>
                                <SelectItem value="appointment">Cita</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div>
                        <Label>Inicio</Label>
                        <Input
                            type="datetime-local"
                            value={newEventInfo?.start_time ? new Date(newEventInfo.start_time.getTime() - newEventInfo.start_time.getTimezoneOffset() * 60000).toISOString().slice(0, 16) : ''}
                            onChange={(e) => setNewEventInfo({ ...newEventInfo, start_time: new Date(e.target.value) })}
                        />
                    </div>
                    <div>
                        <Label>Fin</Label>
                        <Input
                            type="datetime-local"
                            value={newEventInfo?.end_time ? new Date(newEventInfo.end_time.getTime() - newEventInfo.end_time.getTimezoneOffset() * 60000).toISOString().slice(0, 16) : ''}
                            onChange={(e) => setNewEventInfo({ ...newEventInfo, end_time: new Date(e.target.value) })}
                        />
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={handleCloseDialog}>Cancelar</Button>
                    <Button onClick={handleSaveEvent}>Crear Evento</Button>
                </DialogFooter>
            </>
        );
    }, [isDialogOpen, isEditMode, selectedEvent, newEventInfo, handleSaveEvent, handleCloseDialog]);
    
    
      return (
        <Card className="h-full flex flex-col">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Calendario</CardTitle>
              <Button onClick={handleGoogleConnect} variant="outline">
                <CalendarIcon className="mr-2 h-4 w-4" />
                Conectar con Google Calendar
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-4 flex-grow">
            <FullCalendar
              plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
              headerToolbar={{
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
              }}
              initialView={isAppointmentModuleActive ? 'timeGridWeek' : 'dayGridMonth'}
              events={events}
              locale={esLocale}
              editable={false}
              selectable={true}
              selectMirror={true}
              dayMaxEvents={true}
              dateClick={handleDateClick}
              eventClick={handleEventClick}
              height="100%"
              contentHeight="auto"
              slotMinTime="05:00:00"
              slotMaxTime="20:00:00"
              hiddenDays={[0]}
              eventOrder="start"
            />
            <Dialog open={isDialogOpen} onOpenChange={handleCloseDialog}>
              <DialogContent>
                {selectedEvent ? dialogContent : creationDialogContent}
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>
      );
    }
  