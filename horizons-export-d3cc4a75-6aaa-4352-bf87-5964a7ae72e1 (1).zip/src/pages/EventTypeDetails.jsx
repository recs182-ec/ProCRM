
import React, { useState, useEffect, useMemo, useCallback } from 'react';
    import { useParams, useNavigate, useLocation } from 'react-router-dom';
    import { supabase } from '@/lib/customSupabaseClient';
    import { Calendar } from '@/components/ui/calendar';
    import { Button } from '@/components/ui/button';
    import { Card } from '@/components/ui/card';
    import { Clock, DollarSign, ArrowLeft, Calendar as CalendarIcon } from 'lucide-react';
    import { format, getDay, addMinutes, isBefore, startOfDay, parse, set } from 'date-fns';
    import { useToast } from '@/components/ui/use-toast';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import ClientAuthDialog from '@/components/auth/ClientAuthDialog';
    
    const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    
    const EventTypeDetails = () => {
        const { userId, eventTypeId } = useParams();
        const navigate = useNavigate();
        const location = useLocation();
        const { toast } = useToast();
        const { session, profile, loading: authLoading } = useAuth();
        const [loading, setLoading] = useState(true);
        const [settings, setSettings] = useState(null);
        const [eventType, setEventType] = useState(null);
        const [selectedDate, setSelectedDate] = useState(new Date());
        const [selectedTime, setSelectedTime] = useState(null);
        const [isAuthDialogOpen, setAuthDialogOpen] = useState(false);
        const [isConfirming, setIsConfirming] = useState(false);
        
        const handleAuthSuccess = useCallback(() => {
            const bookingState = JSON.parse(localStorage.getItem('pendingBooking'));
            if (bookingState && bookingState.eventTypeId === eventTypeId) {
                setSelectedDate(new Date(bookingState.selectedDate));
                setSelectedTime(bookingState.selectedTime);
            }
        }, [eventTypeId]);

        useEffect(() => {
            if (!authLoading && session && location.search.includes('from_auth=true')) {
                handleAuthSuccess();
                // Clean up URL
                navigate(location.pathname, { replace: true });
            }
        }, [authLoading, session, location, handleAuthSuccess, navigate]);

        useEffect(() => {
            const fetchDetails = async () => {
                setLoading(true);
                const { data, error } = await supabase
                    .from('profiles')
                    .select('booking_settings')
                    .eq('id', userId)
                    .single();
    
                if (error || !data || !data.booking_settings) {
                    console.error("Error fetching booking settings", error);
                    toast({ title: 'Error', description: 'Could not load booking information.', variant: 'destructive' });
                    navigate('/');
                    return;
                }
                
                setSettings(data.booking_settings);
                const currentEventType = data.booking_settings.event_types?.find(et => et.id === eventTypeId);
                
                if (!currentEventType) {
                    toast({ title: 'Error', description: 'Event type not found.', variant: 'destructive' });
                    navigate(`/book/${userId}`);
                    return;
                }
    
                setEventType(currentEventType);
                setLoading(false);
            };
    
            fetchDetails();
        }, [userId, eventTypeId, navigate, toast]);
    
        const availableTimeSlots = useMemo(() => {
            if (!settings?.business_hours || !eventType?.duration || !selectedDate) {
                return [];
            }
    
            const dayName = daysOfWeek[getDay(selectedDate)].toLowerCase();
            const businessHours = settings.business_hours[dayName];
    
            if (!businessHours || !businessHours.enabled) {
                return [];
            }
    
            const slots = [];
            const dayStart = parse(businessHours.start, 'HH:mm', selectedDate);
            const dayEnd = parse(businessHours.end, 'HH:mm', selectedDate);
            const eventDuration = eventType.duration;
            
            let currentTime = dayStart;
    
            while (addMinutes(currentTime, eventDuration) <= dayEnd) {
                if (isBefore(new Date(), currentTime)) {
                    slots.push(format(currentTime, 'HH:mm'));
                }
                currentTime = addMinutes(currentTime, eventDuration);
            }
    
            return slots;
        }, [settings, eventType, selectedDate]);
        
        const handleDateSelect = (date) => {
          if (date && isBefore(date, startOfDay(new Date()))) {
            return;
          }
          setSelectedDate(date);
          setSelectedTime(null);
        }
    
        const handleConfirmAppointment = async () => {
            if (!session || profile?.role !== 'client') {
                localStorage.setItem('pendingBooking', JSON.stringify({
                    userId,
                    eventTypeId,
                    selectedDate: selectedDate.toISOString(),
                    selectedTime,
                }));
                setAuthDialogOpen(true);
                return;
            }
    
            if (!selectedTime || !selectedDate || !eventType) return;
    
            setIsConfirming(true);
    
            const [hours, minutes] = selectedTime.split(':');
            const startTime = set(selectedDate, { hours: parseInt(hours), minutes: parseInt(minutes) });
            const endTime = addMinutes(startTime, eventType.duration);
    
            const { data: newEvent, error } = await supabase.from('calendar_events').insert({
                user_id: userId, // The professional's ID
                client_id: session.user.id, // The client's ID
                title: `${eventType.name} con ${profile.raw_user_meta_data?.name || 'Cliente'}`,
                description: `Cliente: ${profile.raw_user_meta_data?.name || 'N/A'} (${session.user.email})\nTeléfono: ${profile.raw_user_meta_data?.phone || 'No provisto'}`,
                start_time: startTime.toISOString(),
                end_time: endTime.toISOString(),
                event_type: 'appointment',
                price: eventType.price,
                paid: false,
            }).select().single();
    
            setIsConfirming(false);
    
            if (error) {
                toast({
                    title: 'Error al confirmar la cita',
                    description: 'Hubo un problema al guardar tu cita. Por favor, inténtalo de nuevo.',
                    variant: 'destructive',
                });
                console.error('Error creating appointment:', error);
            } else {
                localStorage.removeItem('pendingBooking');
                navigate(`/booking-confirmation/${newEvent.id}`);
            }
        };
    
        if (loading || authLoading) {
            return (
                <div className="flex items-center justify-center min-h-screen bg-background">
                    <div className="loader"></div>
                </div>
            );
        }
    
        if (!eventType) {
            return null;
        }
    
        return (
            <div className="min-h-screen bg-background text-foreground">
                <main className="max-w-5xl mx-auto p-4 sm:p-6 md:p-8">
                    <Button variant="ghost" onClick={() => navigate(`/book/${userId}`)} className="mb-4">
                        <ArrowLeft className="mr-2 h-4 w-4" /> Volver a los tipos de evento
                    </Button>
                    <Card className="overflow-hidden">
                        <div className="grid md:grid-cols-3">
                            <div className="p-6 border-b md:border-b-0 md:border-r md:col-span-1">
                                <p className="text-sm text-muted-foreground">{settings.business_name}</p>
                                <h1 className="text-2xl font-bold mt-1">{eventType.name}</h1>
                                <div className="space-y-2 text-muted-foreground mt-4">
                                    <p className="flex items-center">
                                        <Clock className="mr-2 h-4 w-4" />
                                        <span>{eventType.duration} minutos</span>
                                    </p>
                                    <p className="flex items-center">
                                        <DollarSign className="mr-2 h-4 w-4" />
                                        <span>{eventType.price > 0 ? `$${eventType.price}` : 'Gratis'}</span>
                                    </p>
                                    {selectedDate && <p className="flex items-center">
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        <span>{format(selectedDate, 'EEEE, d \'de\' MMMM, yyyy')}</span>
                                    </p>}
                                </div>
                            </div>
                            <div className="p-6 md:col-span-2">
                                <h2 className="text-lg font-semibold mb-4">Selecciona una Fecha y Hora</h2>
                                <div className="grid sm:grid-cols-2 gap-8">
                                    <Calendar
                                        mode="single"
                                        selected={selectedDate}
                                        onSelect={handleDateSelect}
                                        disabled={(date) => isBefore(date, startOfDay(new Date()))}
                                        className="rounded-md border"
                                    />
                                    <div className="flex-grow max-h-72 overflow-y-auto pr-2">
                                        {availableTimeSlots.length > 0 ? (
                                            <div className="grid grid-cols-3 gap-3">
                                                {availableTimeSlots.map(time => (
                                                    <Button 
                                                        key={time} 
                                                        variant={selectedTime === time ? "default" : "outline"}
                                                        onClick={() => setSelectedTime(time)}
                                                    >
                                                        {time}
                                                    </Button>
                                                ))}
                                            </div>
                                        ) : (
                                            <div className="flex items-center justify-center h-full text-sm text-muted-foreground">
                                                No hay horarios disponibles para este día.
                                            </div>
                                        )}
                                    </div>
                                </div>
                                 {selectedTime && (
                                    <div className="mt-6 text-center">
                                        <Button size="lg" className="w-full" onClick={handleConfirmAppointment} disabled={isConfirming}>
                                            {isConfirming ? 'Confirmando...' : `Confirmar Cita para las ${selectedTime}`}
                                        </Button>
                                    </div>
                                )}
                            </div>
                        </div>
                    </Card>
                </main>
                <ClientAuthDialog isOpen={isAuthDialogOpen} onOpenChange={setAuthDialogOpen} onAuthSuccess={handleAuthSuccess} />
            </div>
        );
    };
    
    export default EventTypeDetails;
