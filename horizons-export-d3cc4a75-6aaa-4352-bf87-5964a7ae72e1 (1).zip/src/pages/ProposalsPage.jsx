import React, { useState, useEffect, useCallback, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { FileText, Plus, Search, Edit, Trash2, Eye } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent } from '@/components/ui/card';
    import { Input } from '@/components/ui/input';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Badge } from '@/components/ui/badge';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { Link, useNavigate } from 'react-router-dom';
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
      AlertDialogTrigger,
    } from '@/components/ui/alert-dialog';

    const ProposalsPage = () => {
      const { toast } = useToast();
      const { user } = useAuth();
      const navigate = useNavigate();
      const [proposals, setProposals] = useState([]);
      const [loading, setLoading] = useState(true);
      const [searchTerm, setSearchTerm] = useState('');

      const fetchProposals = useCallback(async () => {
        if (!user) return;
        setLoading(true);
        const { data, error } = await supabase
          .from('proposals')
          .select('*, companies(commercial_name), contacts(name)')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });
        
        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar las propuestas.', variant: 'destructive' });
        } else {
          setProposals(data);
        }
        setLoading(false);
      }, [user, toast]);

      useEffect(() => {
        fetchProposals();
      }, [fetchProposals]);

      const handleDelete = async (id) => {
        const { error } = await supabase.from('proposals').delete().eq('id', id);
        if (error) {
          toast({ title: 'Error', description: `No se pudo eliminar la propuesta. ${error.message}`, variant: 'destructive' });
        } else {
          toast({ title: 'Propuesta eliminada', description: 'La propuesta ha sido eliminada.' });
          fetchProposals();
        }
      };

      const getStatusVariant = (status) => {
        switch (status) {
          case 'sent': return 'secondary';
          case 'approved': return 'success';
          case 'rejected': return 'destructive';
          case 'draft': return 'outline';
          default: return 'outline';
        }
      };
      
      const getStatusLabel = (status) => {
        const labels = {
          draft: 'Borrador',
          sent: 'Enviada',
          approved: 'Aprobada',
          rejected: 'Rechazada',
        };
        return labels[status] || status;
      };

      const filteredProposals = useMemo(() => {
        return proposals.filter(p =>
          p.client_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (p.companies?.commercial_name || '').toLowerCase().includes(searchTerm.toLowerCase())
        );
      }, [proposals, searchTerm]);

      return (
        <div className="w-full">
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-4xl font-bold text-gray-800">Propuestas</h1>
              <p className="text-muted-foreground text-lg">Crea y gestiona tus propuestas comerciales.</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por cliente o empresa..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              <Button onClick={() => navigate('/create')}>
                <Plus className="mr-2 h-4 w-4" /> Crear Propuesta
              </Button>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Card>
              <CardContent className="p-0">
                {loading ? (
                  <div className="text-center py-20"><div className="loader"></div></div>
                ) : filteredProposals.length === 0 ? (
                  <div className="text-center py-20">
                    <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No hay propuestas</h3>
                    <p className="text-muted-foreground mb-6">{searchTerm ? 'No se encontraron propuestas.' : 'Crea tu primera propuesta para empezar.'}</p>
                    <Button onClick={() => navigate('/create')}>Crear Propuesta</Button>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Cliente</TableHead>
                        <TableHead>Empresa</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead>Fecha</TableHead>
                        <TableHead>Estado</TableHead>
                        <TableHead className="text-right">Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProposals.map((proposal) => (
                        <TableRow key={proposal.id}>
                          <TableCell className="font-medium">{proposal.client_name}</TableCell>
                          <TableCell>{proposal.companies?.commercial_name || proposal.client_company}</TableCell>
                          <TableCell>${parseFloat(proposal.total).toLocaleString('es-PE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</TableCell>
                          <TableCell>{new Date(proposal.created_at).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <Badge variant={getStatusVariant(proposal.status)}>{getStatusLabel(proposal.status)}</Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button asChild variant="ghost" size="icon">
                              <Link to={`/proposal/${proposal.id}`} target="_blank" rel="noopener noreferrer"><Eye className="h-4 w-4" /></Link>
                            </Button>
                            <Button asChild variant="ghost" size="icon">
                              <Link to={`/create?edit=${proposal.id}`}><Edit className="h-4 w-4" /></Link>
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10"><Trash2 className="h-4 w-4" /></Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Esta acción eliminará permanentemente la propuesta. Las tareas asociadas no se eliminarán. Esta acción no se puede deshacer.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDelete(proposal.id)}>Eliminar</AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      );
    };

    export default ProposalsPage;