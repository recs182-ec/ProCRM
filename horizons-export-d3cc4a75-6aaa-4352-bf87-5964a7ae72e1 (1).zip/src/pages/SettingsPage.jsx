import React from 'react';
import { Helmet } from 'react-helmet';
import { NavLink, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Briefcase, Mail, FileText, Users as UsersIcon, Bell, Grid3X3, Settings as SettingsIcon, Palette, Shield, CreditCard } from 'lucide-react';
import { cn } from '@/lib/utils';
import BrandSettings from './settings/BrandSettings';
import EmailSettings from './settings/EmailSettings';
import DocumentSettings from './settings/DocumentSettings';
import LeadSettings from './settings/LeadSettings';
import UserSettings from './settings/UserSettings';
import NotificationSettings from './settings/NotificationSettings';
import ModulesSettings from './settings/ModulesSettings';
import SecuritySettings from './settings/SecuritySettings';
import GeneralSettings from './settings/GeneralSettings';
import PaymentSettings from './settings/PaymentSettings';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const SettingsPage = () => {
  const { profile } = useAuth();
  const location = useLocation();

  const settingsTabs = [
    { name: 'Tu Marca', path: 'brand', icon: Palette, component: BrandSettings },
    { name: 'Módulos', path: 'modules', icon: Grid3X3, component: ModulesSettings },
    { name: 'Notificaciones', path: 'notifications', icon: Bell, component: NotificationSettings },
    { name: 'Correo', path: 'email', icon: Mail, component: EmailSettings },
    { name: 'Documentos', path: 'documents', icon: FileText, component: DocumentSettings },
    { name: 'Cobros', path: 'payments', icon: CreditCard, component: PaymentSettings },
    { name: 'Seguridad', path: 'security', icon: Shield, component: SecuritySettings },
    { name: 'Leads', path: 'leads', icon: Briefcase, component: LeadSettings, condition: profile?.module_settings?.lead_capture },
    { name: 'Usuarios', path: 'users', icon: UsersIcon, component: UserSettings, condition: profile?.role === 'admin' },
    { name: 'General', path: 'general', icon: SettingsIcon, component: GeneralSettings },
  ].filter(Boolean);

  return (
    <>
      <Helmet>
        <title>Configuración | CRM & Propuestas</title>
        <meta name="description" content="Gestiona la configuración general, de email, documentos, notificaciones y usuarios de tu cuenta." />
      </Helmet>
      <div className="w-full max-w-6xl mx-auto">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="text-4xl font-bold">Configuración</h1>
          <p className="text-muted-foreground text-lg">Gestiona las preferencias y ajustes de tu cuenta.</p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          <aside className="md:col-span-3 lg:col-span-2">
            <nav className="flex flex-col space-y-1 sticky top-24">
              {settingsTabs.map((tab) => {
                if (tab.condition === false) return null;
                return (
                  <NavLink
                    key={tab.path}
                    to={tab.path}
                    className={({ isActive }) =>
                      cn(
                        'group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors',
                        isActive
                          ? 'bg-primary text-primary-foreground'
                          : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                      )
                    }
                  >
                    <tab.icon className="mr-3 h-5 w-5" />
                    <span>{tab.name}</span>
                  </NavLink>
                );
              })}
            </nav>
          </aside>

          <main className="md:col-span-9 lg:col-span-10">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
            >
              <Routes>
                {settingsTabs.map((tab) => {
                  const Elem = tab.component;
                  if (tab.condition === false) return null;
                  return <Route key={tab.path} path={tab.path} element={<Elem />} />;
                })}
                <Route index element={<Navigate to="brand" replace />} />
              </Routes>
            </motion.div>
          </main>
        </div>
      </div>
    </>
  );
};

export default SettingsPage;