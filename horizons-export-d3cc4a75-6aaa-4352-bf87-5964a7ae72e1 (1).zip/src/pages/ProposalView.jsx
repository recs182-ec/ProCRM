import React, { useState, useEffect, useCallback } from 'react';
    import { useParams, Link } from 'react-router-dom';
    import { useToast } from '@/components/ui/use-toast';
    import ProposalHeader from '@/components/proposal/ProposalHeader';
    import ProposalStatusBanner from '@/components/proposal/ProposalStatusBanner';
    import ProposalServices from '@/components/proposal/ProposalServices';
    import ProposalActions from '@/components/proposal/ProposalActions';
    import ProposalSummary from '@/components/proposal/ProposalSummary';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { motion } from 'framer-motion';
    import { supabase } from '@/lib/customSupabaseClient';
    import { pdf } from '@react-pdf/renderer';
    import ProposalPDF from '@/components/proposal/ProposalPDF';
    import { Info, CheckSquare, Edit, Send, FileWarning, Calendar, MapPin, CreditCard } from 'lucide-react';

    const ProposalView = () => {
      const { id } = useParams();
      const { toast } = useToast();
      const [proposal, setProposal] = useState(null);
      const [selectedServices, setSelectedServices] = useState([]);
      const [ownerProfile, setOwnerProfile] = useState(null);
      const [loading, setLoading] = useState(true);

      const fetchProposalAndProfile = useCallback(async () => {
        setLoading(true);
        const { data: proposalData, error: proposalError } = await supabase.from('proposals').select('*').eq('id', id).single();
        if (proposalError) {
          toast({ title: "Error", description: "Propuesta no encontrada.", variant: "destructive" });
          setLoading(false);
          return;
        } 
        
        if (proposalData.status === 'sent' && !proposalData.viewed_at) {
            await supabase.from('proposals').update({ viewed_at: new Date().toISOString() }).eq('id', id);
        }

        setProposal(proposalData);
        if (proposalData.status === 'sent') {
          setSelectedServices(proposalData.services.map(s => s.id));
        } else {
          setSelectedServices(proposalData.approved_services || []);
        }

        if (proposalData.user_id) {
          const { data: profileData, error: profileError } = await supabase
            .from('profiles')
            .select('company_info, terms_and_conditions_url, privacy_policy_url, module_settings, payment_settings')
            .eq('id', proposalData.user_id)
            .single();
          
          const { data: settingsData, error: settingsError } = await supabase
            .from('settings')
            .select('logo_url')
            .eq('user_id', proposalData.user_id)
            .maybeSingle();

          if (profileError || (settingsError && settingsError.code !== 'PGRST116')) {
            console.error("Error fetching profile/settings:", profileError || settingsError);
          }
          setOwnerProfile({ ...(profileData || {}), ...(settingsData || {}) });
        }
        setLoading(false);
      }, [id, toast]);

      useEffect(() => {
        fetchProposalAndProfile();
      }, [fetchProposalAndProfile]);

      const handleServiceToggle = (serviceId) => {
        if (proposal.status === 'approved' || proposal.status === 'rejected') return;
        setSelectedServices(prev => 
          prev.includes(serviceId)
            ? prev.filter(id => id !== serviceId)
            : [...prev, serviceId]
        );
      };

      const generateAndUploadPdf = async (approvedProposal) => {
        try {
          const blob = await pdf(<ProposalPDF proposal={approvedProposal} logoUrl={ownerProfile?.logo_url} />).toBlob();
          const fileName = `proposals/${approvedProposal.id}/approved-proposal.pdf`;
          
          const { data: uploadData, error: uploadError } = await supabase.storage
            .from('documents')
            .upload(fileName, blob, {
              cacheControl: '3600',
              upsert: true,
              contentType: 'application/pdf'
            });

          if (uploadError) throw uploadError;

          const { data: urlData } = supabase.storage.from('documents').getPublicUrl(uploadData.path);
          
          const { error: updateError } = await supabase
            .from('proposals')
            .update({ pdf_url: urlData.publicUrl })
            .eq('id', approvedProposal.id);

          if (updateError) throw updateError;

          return urlData.publicUrl;
        } catch (error) {
          console.error('Error generating or uploading PDF:', error);
          toast({
            title: 'Error al generar PDF',
            description: `No se pudo generar o guardar el PDF de la propuesta. ${error.message}`,
            variant: 'destructive',
          });
          return null;
        }
      };

      const createRelatedRecords = async (approvedProposal) => {
        const approvedServiceDetails = approvedProposal.services.filter(s =>
          approvedProposal.approved_services.includes(s.id)
        );

        const tasksToCreate = approvedServiceDetails
          .filter(service => service.frequency === 'Una vez' || service.frequency === 'Mensual')
          .map(service => ({
            proposal_id: approvedProposal.id,
            service_id: service.id,
            service_name: service.name,
            status: 'Pendiente',
            user_id: approvedProposal.user_id,
            assigned_user_id: approvedProposal.assigned_user_id,
            due_date: new Date().toISOString().split('T')[0],
            is_paid: false
          }));

        if (tasksToCreate.length > 0) {
          const { error } = await supabase.from('tasks').insert(tasksToCreate);
          if (error) {
            toast({
              title: 'Error al crear tareas',
              description: 'La propuesta fue aprobada, pero no se pudieron crear las tareas automáticamente.',
              variant: 'destructive',
            });
          }
        }
        
        const annualServicesToCreate = approvedServiceDetails
          .filter(service => service.frequency === 'Anual')
          .map(service => ({
              user_id: approvedProposal.user_id,
              company_id: approvedProposal.company_id,
              service_name: service.name,
              renewal_month: new Date().getMonth() + 1,
              value: Number(service.price) || 0
          }));

        if (annualServicesToCreate.length > 0) {
            const { error } = await supabase.from('annual_services').insert(annualServicesToCreate);
            if (error) {
                toast({
                    title: 'Error al crear servicios anuales',
                    description: 'No se pudieron registrar los servicios anuales automáticamente.',
                    variant: 'destructive',
                });
            }
        }
      };

      const updateProposalStatus = async (status, signatureData, signatureName, signatureEmail) => {
        const selectedServiceDetails = proposal.services.filter(s => selectedServices.includes(s.id));
        const subtotal = selectedServiceDetails.reduce((acc, s) => acc + Number(s.price || 0), 0);
        const discountPercentage = proposal.discount || 0;
        const discountAmount = subtotal * (discountPercentage / 100);
        const subtotalAfterDiscount = subtotal - discountAmount;
        const iva = subtotalAfterDiscount * 0.15;
        const total = subtotalAfterDiscount + iva;
        
        const hasNonAnnualService = selectedServiceDetails.some(s => s.frequency === 'Una vez' || s.frequency === 'Mensual');
        const finalStatus = status === 'approved' && !hasNonAnnualService ? 'completed_annual' : status;

        const updateData = {
          status: finalStatus,
          total,
          approved_services: status === 'approved' ? selectedServices : proposal.approved_services,
          pipeline_stage: status === 'approved' ? 'Aprobado' : 'Rechazado',
          [`${status}_at`]: new Date().toISOString(),
          ...(status === 'approved' && { 
            signature: signatureData,
            client_signature_name: signatureName,
            client_signature_email: signatureEmail
          }),
        };

        const { data: updatedProposal, error } = await supabase.from('proposals').update(updateData).eq('id', id).select().single();
        if (error) {
            toast({ title: 'Error', description: 'No se pudo actualizar la propuesta.' });
        } else {
            if (status === 'approved') {
              const fullProposalData = {...proposal, ...updatedProposal};
              await generateAndUploadPdf(fullProposalData);
              await createRelatedRecords(fullProposalData);
              await supabase.functions.invoke('send-proposal-notification', { body: { proposal_id: updatedProposal.id, event_type: 'proposal_accepted' } });
            }
            fetchProposalAndProfile();
        }
      };
      
      const approveProposal = (signatureData, signatureName, signatureEmail) => {
        updateProposalStatus('approved', signatureData, signatureName, signatureEmail);
        toast({ title: "¡Propuesta aprobada!", description: "Tu aprobación ha sido registrada exitosamente." });
      };

      const handlePayNow = () => {
        toast({
          title: "🚧 Función en desarrollo",
          description: "La pasarela de pago aún no está conectada. ¡El equipo está trabajando en ello! 🚀",
        });
      };

      if (loading) {
        return (
          <div className="min-h-screen flex items-center justify-center bg-gray-50">
            <div className="text-center">
               <div className="loader"></div>
               <p className="text-muted-foreground mt-4">Cargando propuesta...</p>
            </div>
          </div>
        );
      }

      if (!proposal) {
        return (
          <div className="min-h-screen flex items-center justify-center bg-gray-50">
            <div className="text-center">
               <FileWarning className="h-16 w-16 text-destructive mx-auto mb-4" />
               <h2 className="text-2xl font-bold mb-2">Error al cargar</h2>
               <p className="text-muted-foreground">No se pudo encontrar la propuesta.</p>
            </div>
          </div>
        );
      }

      if (proposal.status === 'draft') {
        return (
          <div className="min-h-screen flex items-center justify-center bg-gray-50">
            <div className="text-center p-8 max-w-md mx-auto bg-white rounded-xl shadow-lg">
               <FileWarning className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
               <h2 className="text-2xl font-bold mb-2">Propuesta en Borrador</h2>
               <p className="text-muted-foreground mb-6">Esta propuesta aún es un borrador y no puede ser visualizada. Por favor, contacta al emisor o edítala si tienes permiso.</p>
               <Button asChild>
                 <Link to={`/create?edit=${id}`}>
                   <Edit className="mr-2 h-4 w-4" /> Editar Propuesta
                 </Link>
               </Button>
            </div>
          </div>
        );
      }

      const isFinalState = proposal.status === 'approved' || proposal.status === 'rejected' || proposal.status === 'completed_annual';
      const paymentSettings = ownerProfile?.payment_settings || {};
      const showPaymentButton = paymentSettings.enable_payment_button === true;
      
      const paymentPercentage = proposal.payment_percentage || 100;
      const downPayment = (proposal.total || 0) * (paymentPercentage / 100);
      const isFullPayment = paymentPercentage === 100;

      return (
        <div className="bg-gray-100 min-h-screen">
          <div className="w-full max-w-5xl mx-auto p-4 sm:p-6 lg:p-8">
              <ProposalHeader clientName={proposal.client_name} clientCompany={proposal.client_company} logoUrl={ownerProfile?.logo_url} />
              <ProposalStatusBanner status={proposal.status} date={proposal.approved_at || proposal.rejected_at} />

              {proposal.status === 'approved' && showPaymentButton && paymentPercentage > 0 && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mb-6 text-center">
                  <Card className="bg-green-50 border-green-200 inline-block">
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold text-green-800 mb-4">¡Gracias por tu confianza!</h3>
                      <p className="text-green-700 mb-6">{isFullPayment ? 'Para confirmar, por favor realiza el pago total.' : `Para iniciar, por favor realiza el pago del ${paymentPercentage}% de anticipo.`}</p>
                      <Button size="lg" onClick={handlePayNow}>
                        <CreditCard className="mr-2 h-5 w-5" />
                        {isFullPayment ? 'Pagar Total' : 'Pagar Anticipo'} ({downPayment.toLocaleString('es-EC', { style: 'currency', currency: 'USD' })})
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              )}

              {!isFinalState && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mb-6">
                  <Card className="bg-blue-50 border-blue-200">
                    <CardHeader>
                      <CardTitle className="text-blue-800 flex items-center gap-2"><Info className="h-5 w-5" /> Pasos a seguir</CardTitle>
                    </CardHeader>
                    <CardContent className="text-blue-700 space-y-2">
                      <p className="flex items-center gap-2"><CheckSquare className="h-4 w-4"/> 1. Selecciona los servicios que deseas contratar.</p>
                      <p className="flex items-center gap-2"><Edit className="h-4 w-4"/> 2. Completa tus datos y firma al final de la página.</p>
                      <p className="flex items-center gap-2"><Send className="h-4 w-4"/> 3. Haz clic en "Aprobar Propuesta" para confirmar.</p>
                    </CardContent>
                  </Card>
                </motion.div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                  {proposal.description && (
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                      <Card className="bg-white border">
                        <CardHeader><CardTitle className="text-gray-800">Descripción del Proyecto</CardTitle></CardHeader>
                        <CardContent><p className="text-gray-600 leading-relaxed whitespace-pre-wrap">{proposal.description}</p></CardContent>
                      </Card>
                    </motion.div>
                  )}
                  {proposal.appointment_datetime && (
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                      <Card className="bg-white border">
                        <CardHeader><CardTitle className="text-gray-800">Detalles de la Cita</CardTitle></CardHeader>
                        <CardContent className="space-y-2">
                           <div className="flex items-center gap-3">
                              <Calendar className="h-5 w-5 text-primary" />
                              <div>
                                <p className="font-semibold">Fecha y Hora</p>
                                <p className="text-gray-600">{new Date(proposal.appointment_datetime).toLocaleString('es-ES', { dateStyle: 'long', timeStyle: 'short' })}</p>
                              </div>
                           </div>
                           {proposal.appointment_location && (
                             <div className="flex items-center gap-3">
                                <MapPin className="h-5 w-5 text-primary" />
                                <div>
                                  <p className="font-semibold">Lugar</p>
                                  <p className="text-gray-600">{proposal.appointment_location}</p>
                                </div>
                             </div>
                           )}
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}

                  <ProposalServices
                    services={proposal.services}
                    selectedServices={selectedServices}
                    onServiceToggle={handleServiceToggle}
                    isApproved={isFinalState}
                    isRejected={isFinalState}
                  />
                  
                  <div className="mt-8 pt-6 border-t">
                    <ProposalActions
                      onApprove={approveProposal}
                      isApproved={isFinalState}
                      isRejected={isFinalState}
                      termsAndConditionsUrl={ownerProfile?.terms_and_conditions_url}
                      privacyPolicyUrl={ownerProfile?.privacy_policy_url}
                    />
                  </div>

                </div>
                <ProposalSummary
                  proposal={proposal}
                  selectedServices={selectedServices}
                  isApproved={isFinalState}
                  isRejected={isFinalState}
                  logoUrl={ownerProfile?.logo_url}
                />
              </div>
          </div>
        </div>
      );
    };

    export default ProposalView;