
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Package } from 'lucide-react';

const ClientPayments = () => {
    // This component is a placeholder for future implementation
    return (
        <div>
            <h1 className="text-3xl font-bold mb-6">Mis Pagos</h1>
            <Card>
                <CardContent className="pt-6">
                    <div className="flex flex-col items-center justify-center h-64 text-center">
                        <Package className="h-12 w-12 text-muted-foreground mb-4" />
                        <h3 className="text-xl font-semibold">Próximamente</h3>
                        <p className="text-muted-foreground">Tu historial de pagos y facturas aparecerá aquí.</p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

export default ClientPayments;
