
import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, CreditCard, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const ClientDashboard = () => {
    const { profile } = useAuth();

    return (
        <div>
            <motion.div 
                initial={{ opacity: 0, y: -20 }} 
                animate={{ opacity: 1, y: 0 }} 
                className="mb-8"
            >
                <h1 className="text-4xl font-bold">Bienvenido, {profile?.name || 'Cliente'}!</h1>
                <p className="text-lg text-muted-foreground">Aquí puedes gestionar tus citas y pagos.</p>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-6">
                <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }}>
                    <Card className="hover:shadow-lg transition-shadow">
                        <CardHeader className="flex flex-row items-center justify-between pb-2">
                            <CardTitle className="text-lg font-medium">Mis Citas</CardTitle>
                            <Calendar className="h-6 w-6 text-primary" />
                        </CardHeader>
                        <CardContent>
                            <p className="text-muted-foreground mb-4">Revisa tus próximas citas y tu historial.</p>
                            <Button asChild>
                                <Link to="/client/appointments">Ver mis Citas <ArrowRight className="ml-2 h-4 w-4" /></Link>
                            </Button>
                        </CardContent>
                    </Card>
                </motion.div>

                <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2 }}>
                    <Card className="hover:shadow-lg transition-shadow">
                        <CardHeader className="flex flex-row items-center justify-between pb-2">
                            <CardTitle className="text-lg font-medium">Mis Pagos</CardTitle>
                            <CreditCard className="h-6 w-6 text-primary" />
                        </CardHeader>
                        <CardContent>
                            <p className="text-muted-foreground mb-4">Consulta tu historial de pagos y facturas.</p>
                             <Button asChild>
                                <Link to="/client/payments">Ver mis Pagos <ArrowRight className="ml-2 h-4 w-4" /></Link>
                            </Button>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        </div>
    );
};

export default ClientDashboard;
