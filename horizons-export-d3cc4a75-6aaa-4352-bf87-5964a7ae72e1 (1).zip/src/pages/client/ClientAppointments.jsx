
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Calendar, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const ClientAppointments = () => {
    const { user } = useAuth();
    const { toast } = useToast();
    const [appointments, setAppointments] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchAppointments = async () => {
            if (!user) return;
            setLoading(true);

            const { data, error } = await supabase
                .from('calendar_events')
                .select('*')
                .eq('client_id', user.id)
                .order('start_time', { ascending: false });

            if (error) {
                toast({ title: 'Error', description: 'No se pudieron cargar tus citas.', variant: 'destructive' });
            } else {
                setAppointments(data);
            }
            setLoading(false);
        };

        fetchAppointments();
    }, [user, toast]);
    
    if (loading) {
        return (
            <div className="flex items-center justify-center">
                <div className="loader"></div>
            </div>
        );
    }

    return (
        <div>
            <h1 className="text-3xl font-bold mb-6">Mis Citas</h1>
            {appointments.length === 0 ? (
                <Card>
                    <CardContent className="pt-6">
                        <p className="text-center text-muted-foreground">No tienes ninguna cita programada.</p>
                    </CardContent>
                </Card>
            ) : (
                <div className="space-y-4">
                    {appointments.map(event => (
                        <Card key={event.id}>
                            <CardHeader>
                                <CardTitle>{event.title}</CardTitle>
                                <CardDescription>
                                    {event.description}
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="flex items-center gap-4 text-sm text-muted-foreground">
                                <div className="flex items-center gap-2">
                                    <Calendar className="h-4 w-4" />
                                    <span>{format(new Date(event.start_time), "EEEE, d 'de' MMMM, yyyy", { locale: es })}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Clock className="h-4 w-4" />
                                    <span>{format(new Date(event.start_time), 'p', { locale: es })}</span>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
};

export default ClientAppointments;
