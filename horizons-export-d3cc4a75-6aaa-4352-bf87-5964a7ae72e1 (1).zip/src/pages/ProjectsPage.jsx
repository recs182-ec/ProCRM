import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { FolderKanban } from 'lucide-react';

const ProjectsPage = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full"
    >
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold text-gray-800">Proyectos</h1>
          <p className="text-muted-foreground text-lg">Gestiona y supervisa todos tus proyectos activos.</p>
        </div>
      </div>

      <Card className="w-full">
        <CardHeader>
          <CardTitle>Módulo de Proyectos</CardTitle>
          <CardDescription>Esta sección está en desarrollo.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center text-center py-16">
            <FolderKanban className="h-24 w-24 text-muted-foreground/50 mb-4" />
            <h2 className="text-2xl font-semibold text-gray-700">Próximamente</h2>
            <p className="text-muted-foreground mt-2 max-w-md">
              Estamos construyendo un potente módulo de gestión de proyectos. Pronto podrás organizar tareas, establecer plazos y colaborar con tu equipo aquí mismo.
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProjectsPage;