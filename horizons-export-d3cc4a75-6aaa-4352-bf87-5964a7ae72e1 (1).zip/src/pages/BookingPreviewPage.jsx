import React, { useState, useEffect, useRef } from 'react';
import PublicBookingPage from '@/pages/PublicBookingPage';

const BookingPreviewPage = () => {
    const [previewSettings, setPreviewSettings] = useState(null);
    const channel = useRef(null);

    useEffect(() => {
        channel.current = new BroadcastChannel('booking_preview_channel');

        const handleMessage = (event) => {
            if (event.data && event.data.settings) {
                setPreviewSettings(event.data.settings);
            }
        };

        channel.current.addEventListener('message', handleMessage);

        return () => {
            channel.current.removeEventListener('message', handleMessage);
            channel.current.close();
        };
    }, []);

    if (!previewSettings) {
        return <div className="flex items-center justify-center min-h-screen bg-transparent"><p className="text-muted-foreground">Waiting for preview data...</p></div>;
    }

    return <PublicBookingPage previewSettings={previewSettings} />;
};

export default BookingPreviewPage;