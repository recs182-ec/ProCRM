
        import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { KeyRound, ShieldCheck, QrCode, AlertTriangle } from 'lucide-react';
import { PasswordInput } from '@/components/ui/password-input';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useNavigate } from 'react-router-dom';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";


const SecuritySettings = () => {
    const { toast } = useToast();
    const { user, signOut } = useAuth();
    const navigate = useNavigate();
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);
    const [is2FAEnabled, setIs2FAEnabled] = useState(false);
    const [deleteConfirmation, setDeleteConfirmation] = useState('');
    const [isDeleting, setIsDeleting] = useState(false);
    const CONFIRMATION_TEXT = 'ELIMINAR';

    const handleUpdatePassword = async (e) => {
        e.preventDefault();
        if (password.length < 6) {
            toast({ title: 'Error', description: 'La contraseña debe tener al menos 6 caracteres.', variant: 'destructive' });
            return;
        }
        if (password !== confirmPassword) {
            toast({ title: 'Error', description: 'Las contraseñas no coinciden.', variant: 'destructive' });
            return;
        }
        
        setIsUpdatingPassword(true);
        const { error } = await supabase.auth.updateUser({ password: password });
        setIsUpdatingPassword(false);
        
        if (error) {
            toast({ title: 'Error', description: `No se pudo actualizar la contraseña. ${error.message}`, variant: 'destructive' });
        } else {
            toast({ title: 'Éxito', description: 'Contraseña actualizada correctamente.' });
            setPassword('');
            setConfirmPassword('');
        }
    };
    
    const handle2FAToggle = (checked) => {
      setIs2FAEnabled(checked);
      toast({
        title: "🚧 Función en desarrollo",
        description: "La autenticación de dos factores aún no está implementada. ¡Puedes solicitarla en tu próximo prompt! 🚀",
        variant: 'default',
        duration: 5000,
      });
      setTimeout(() => setIs2FAEnabled(false), 500); 
    };

    const handleDeleteAccount = async () => {
        setIsDeleting(true);
        try {
            const { error } = await supabase.functions.invoke('delete-user-account', {
                body: { user_id: user.id },
            });

            if (error) {
                throw error;
            }

            toast({
                title: 'Cuenta eliminada',
                description: 'Tu cuenta ha sido eliminada exitosamente. Serás redirigido.',
            });
            await signOut();
            navigate('/login');

        } catch (error) {
            toast({
                title: 'Error al eliminar la cuenta',
                description: error.message || 'No se pudo completar la solicitud.',
                variant: 'destructive',
            });
        } finally {
            setIsDeleting(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <KeyRound className="h-5 w-5 text-primary" />
                        Cambiar Contraseña
                    </CardTitle>
                    <CardDescription>
                        Para mayor seguridad, te recomendamos usar una contraseña larga y única.
                    </CardDescription>
                </CardHeader>
                <form onSubmit={handleUpdatePassword}>
                    <CardContent className="space-y-4">
                        <div>
                            <Label htmlFor="new-password">Nueva Contraseña</Label>
                            <PasswordInput id="new-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
                        </div>
                        <div>
                            <Label htmlFor="confirm-password">Confirmar Nueva Contraseña</Label>
                            <PasswordInput id="confirm-password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="••••••••" />
                        </div>
                    </CardContent>
                    <CardFooter>
                        <Button type="submit" disabled={isUpdatingPassword}>
                            {isUpdatingPassword ? 'Actualizando...' : 'Actualizar Contraseña'}
                        </Button>
                    </CardFooter>
                </form>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <ShieldCheck className="h-5 w-5 text-primary" />
                        Autenticación de Dos Factores (2FA)
                    </CardTitle>
                    <CardDescription>
                        Añade una capa extra de seguridad a tu cuenta.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center justify-between rounded-lg border p-4">
                        <div>
                            <Label htmlFor="2fa-switch">Activar 2FA</Label>
                            <p className="text-sm text-muted-foreground">Requiere una app de autenticación (ej. Google Authenticator).</p>
                        </div>
                        <Switch id="2fa-switch" checked={is2FAEnabled} onCheckedChange={handle2FAToggle} />
                    </div>
                     {is2FAEnabled && (
                        <div className="flex flex-col items-center justify-center space-y-4 pt-4 border-t">
                            <p className="text-sm text-center">Escanea este código QR con tu app de autenticación.</p>
                            <div className="bg-muted p-4 rounded-lg flex items-center justify-center w-48 h-48">
                                <QrCode className="h-32 w-32 text-muted-foreground" />
                            </div>
                            <p className="text-sm text-muted-foreground">Funcionalidad en desarrollo.</p>
                        </div>
                    )}
                </CardContent>
            </Card>

            <Card className="border-destructive">
                 <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-destructive">
                        <AlertTriangle className="h-5 w-5" />
                        Zona de Peligro
                    </CardTitle>
                    <CardDescription>
                        Esta acción es irreversible y eliminará tu acceso y datos personales de la plataforma.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <p className="text-sm text-muted-foreground mb-4">
                        Al eliminar tu cuenta, tu usuario será desvinculado de la cuenta de empresa actual, liberando tu correo electrónico para que pueda ser asociado a otra. Los datos compartidos con tu equipo no se verán afectados.
                    </p>
                </CardContent>
                <CardFooter>
                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button variant="destructive">Eliminar mi cuenta</Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                                <AlertDialogTitle>¿Estás absolutamente seguro?</AlertDialogTitle>
                                <AlertDialogDescription>
                                    Esta acción no se puede deshacer. Esto eliminará permanentemente tu cuenta y tus datos personales. Para confirmar, escribe <strong className="text-foreground">{CONFIRMATION_TEXT}</strong> a continuación.
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <div className="my-4">
                                <Label htmlFor="delete-confirm">Confirmación</Label>
                                <Input
                                    id="delete-confirm"
                                    value={deleteConfirmation}
                                    onChange={(e) => setDeleteConfirmation(e.target.value)}
                                    placeholder={CONFIRMATION_TEXT}
                                    className="border-destructive focus-visible:ring-destructive"
                                />
                            </div>
                            <AlertDialogFooter>
                                <AlertDialogCancel onClick={() => setDeleteConfirmation('')}>Cancelar</AlertDialogCancel>
                                <AlertDialogAction
                                    onClick={handleDeleteAccount}
                                    disabled={deleteConfirmation !== CONFIRMATION_TEXT || isDeleting}
                                    className="bg-destructive hover:bg-destructive/90"
                                >
                                    {isDeleting ? "Eliminando..." : "Sí, eliminar mi cuenta"}
                                </AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                </CardFooter>
            </Card>
        </div>
    );
};

export default SecuritySettings;
      