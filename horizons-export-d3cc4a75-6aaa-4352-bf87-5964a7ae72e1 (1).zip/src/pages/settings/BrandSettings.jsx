import React, { useState, useEffect, useCallback } from 'react';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Button } from '@/components/ui/button';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { Building, Upload, Image as ImageIcon, PlusCircle, XCircle, Palette } from 'lucide-react';
    import { Textarea } from '@/components/ui/textarea';
    import { motion } from 'framer-motion';

    const BrandSettings = () => {
        const { user, profile } = useAuth();
        const { toast } = useToast();
        const [companyInfo, setCompanyInfo] = useState({ name: '', addresses: [], phone: '', website: '', ruc: '', bank_details: '' });
        const [logoUrl, setLogoUrl] = useState(null);
        const [logoFile, setLogoFile] = useState(null);
        const [isUploading, setIsUploading] = useState(false);
        const [isSaving, setIsSaving] = useState(false);

        const isAppointmentModuleActive = profile?.module_settings?.appointment_scheduling === true;

        const loadSettings = useCallback(async () => {
            if (!user) return;
            // Eagerly fetch profile data if it's not available yet
            const { data: profileData, error: profileError } = await supabase
                .from('profiles')
                .select('company_info, module_settings')
                .eq('id', user.id)
                .single();
    
            if (profileError && profileError.code !== 'PGRST116') {
                toast({ title: 'Error', description: 'No se pudo cargar la configuración del perfil.', variant: 'destructive' });
                return;
            }
            
            if (profileData?.company_info) {
                 setCompanyInfo(prev => ({
                    ...prev,
                    ...profileData.company_info,
                    addresses: profileData.company_info.addresses || [],
                }));
            }
    
            const { data: settingsData, error: settingsError } = await supabase
                .from('settings')
                .select('logo_url')
                .eq('user_id', user.id)
                .single();
    
            if (settingsError && settingsError.code !== 'PGRST116') {
                 toast({ title: 'Error', description: 'No se pudo cargar la configuración de la empresa.', variant: 'destructive' });
            }
            
            if (settingsData) {
                setLogoUrl(settingsData.logo_url || null);
            }
        }, [user, toast]);
        
    useEffect(() => {
        if(user) {
            loadSettings();
        }
    }, [user, loadSettings]);

    useEffect(() => {
        // When profile is available from context, ensure company info is up-to-date
        if (profile?.company_info) {
            setCompanyInfo(prev => ({
                ...prev,
                ...profile.company_info,
                addresses: profile.company_info.addresses || [],
            }));
        }
    }, [profile]);

    const handleInfoChange = (e) => {
        const { id, value } = e.target;
        setCompanyInfo(prev => ({ ...prev, [id]: value }));
    };

    const handleAddressChange = (index, value) => {
        const newAddresses = [...companyInfo.addresses];
        newAddresses[index] = value;
        setCompanyInfo(prev => ({ ...prev, addresses: newAddresses }));
    };

    const addAddress = () => {
        setCompanyInfo(prev => ({ ...prev, addresses: [...(prev.addresses || []), ''] }));
    };

    const removeAddress = (index) => {
        const newAddresses = companyInfo.addresses.filter((_, i) => i !== index);
        setCompanyInfo(prev => ({ ...prev, addresses: newAddresses }));
    };

    const handleSaveInfo = async () => {
        if (!user) return;
        setIsSaving(true);
        const { data, error } = await supabase
            .from('profiles')
            .update({ company_info: { ...profile.company_info, ...companyInfo }})
            .eq('id', user.id)
            .select()
            .single();
        setIsSaving(false);
        if (error) {
            toast({ title: 'Error', description: `No se pudo guardar la información. ${error.message}`, variant: 'destructive' });
        } else {
            toast({ title: 'Éxito', description: 'Información de la empresa guardada.' });
        }
    };


        const handleLogoUpload = async () => {
        if (!logoFile) {
            toast({ title: 'Atención', description: 'Por favor, selecciona un archivo de logo.', variant: 'destructive' });
            return;
        }
        if (!user) return;
        
        setIsUploading(true);
        const fileName = `${user.id}/${Date.now()}-${logoFile.name}`;

        const { error: uploadError } = await supabase.storage
            .from('logos')
            .upload(fileName, logoFile);

        if (uploadError) {
            toast({ title: 'Error de subida', description: uploadError.message, variant: 'destructive' });
            setIsUploading(false);
            return;
        }

        const { data: { publicUrl } } = supabase.storage
            .from('logos')
            .getPublicUrl(fileName);

        const { error: dbError } = await supabase
            .from('settings')
            .upsert({ user_id: user.id, logo_url: publicUrl }, { onConflict: 'user_id' });
        
        if (dbError) {
            toast({ title: 'Error en base de datos', description: dbError.message, variant: 'destructive' });
        } else {
            setLogoUrl(publicUrl);
            toast({ title: '¡Logo subido!', description: 'Tu logo se ha actualizado.' });
        }
        setIsUploading(false);
    };

        return (
            <motion.div className="space-y-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><ImageIcon className="h-5 w-5 text-primary"/>Logo de la Empresa</CardTitle>
                        <CardDescription>Sube el logo de tu empresa que aparecerá en propuestas y correos.</CardDescription>
                    </CardHeader>
                    <CardContent className="flex flex-col items-center space-y-4">
                        <div className="w-48 h-24 border-2 border-dashed rounded-lg flex items-center justify-center bg-muted">
                            {logoUrl ? <img src={logoUrl} alt="Logo" className="max-w-full max-h-full object-contain"/> : <span className="text-muted-foreground text-sm">Sin logo</span>}
                        </div>
                        <Input id="logo" type="file" accept="image/*" onChange={(e) => setLogoFile(e.target.files[0])} className="max-w-xs" />
                        <Button onClick={handleLogoUpload} disabled={isUploading}>
                            <Upload className="h-4 w-4 mr-2"/> {isUploading ? 'Subiendo...' : 'Subir Logo'}
                        </Button>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Building className="h-5 w-5 text-primary"/>Información de la Empresa</CardTitle>
                        <CardDescription>Esta información se usará en tus documentos y correos.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div><Label htmlFor="name">Nombre de la Empresa</Label><Input id="name" value={companyInfo.name || ''} onChange={handleInfoChange} /></div>
                            <div><Label htmlFor="ruc">RUC / ID Fiscal</Label><Input id="ruc" value={companyInfo.ruc || ''} onChange={handleInfoChange} /></div>
                            
                            {!isAppointmentModuleActive && (
                                <div><Label htmlFor="address">Dirección</Label><Input id="address" value={companyInfo.address || ''} onChange={handleInfoChange} /></div>
                            )}

                            <div><Label htmlFor="phone">Teléfono</Label><Input id="phone" value={companyInfo.phone || ''} onChange={handleInfoChange} /></div>
                            <div><Label htmlFor="website">Sitio Web</Label><Input id="website" value={companyInfo.website || ''} onChange={handleInfoChange} /></div>
                            
                            <div className="md:col-span-2">
                                <Label htmlFor="bank_details">Detalles de Cuenta Bancaria</Label>
                                <Textarea id="bank_details" value={companyInfo.bank_details || ''} onChange={handleInfoChange} rows={5} placeholder="Ej:&#10;Banco: Mi Banco&#10;Razón Social: Mi Empresa S.A.&#10;Cuenta Corriente&#10;RUC: 0123456789001&#10;# de Cuenta: 1234567890" />
                                <p className="text-xs text-muted-foreground mt-1">Esta información se mostrará en los correos de aprobación de propuestas.</p>
                            </div>
                        </div>

                        {isAppointmentModuleActive && (
                            <div className="space-y-4 pt-4 border-t">
                                <h3 className="text-md font-semibold">Gestionar Direcciones de Citas</h3>
                                <div className="space-y-2">
                                    {(companyInfo.addresses || []).map((address, index) => (
                                        <div key={index} className="flex items-center gap-2">
                                            <Input 
                                                value={address} 
                                                onChange={(e) => handleAddressChange(index, e.target.value)}
                                                placeholder={`Dirección ${index + 1}`}
                                            />
                                            <Button variant="ghost" size="icon" onClick={() => removeAddress(index)}>
                                                <XCircle className="h-4 w-4 text-destructive" />
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                                <Button variant="outline" size="sm" onClick={addAddress}>
                                    <PlusCircle className="h-4 w-4 mr-2" />
                                    Añadir Dirección
                                </Button>
                            </div>
                        )}

                        <Button onClick={handleSaveInfo} disabled={isSaving} className="mt-4">
                            {isSaving ? 'Guardando...' : 'Guardar Información'}
                        </Button>
                    </CardContent>
                </Card>
            </motion.div>
        );
    };

    export default BrandSettings;