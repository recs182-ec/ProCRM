import React, { useState, useEffect, useCallback } from 'react';
    import { motion } from 'framer-motion';
    import { KeyRound, RefreshCw, Copy, ClipboardCheck, Server, Zap, ZapOff, Settings } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { Link } from 'react-router-dom';

    const LeadSettings = () => {
      const { user, profile } = useAuth();
      const { toast } = useToast();
      const [apiKey, setApiKey] = useState('');
      const [loading, setLoading] = useState(true);
      const [testing, setTesting] = useState(false);
      const [isCopiedKey, setIsCopiedKey] = useState(false);
      const [isCopiedUrl, setIsCopiedUrl] = useState(false);

      const isLeadModuleActive = profile?.module_settings?.lead_capture === true;
      const webhookUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/lead-webhook`;

      const generateApiKey = () => {
        return `crm_sk_${[...Array(32)].map(() => Math.random().toString(36)[2]).join('')}`;
      };

      const fetchApiKey = useCallback(async () => {
        if (!user || !isLeadModuleActive) {
          setLoading(false);
          return;
        }
        setLoading(true);
        try {
          const { data, error } = await supabase
            .from('profiles')
            .select('webhook_api_key')
            .eq('id', user.id)
            .single();

          if (error && error.code !== 'PGRST116') throw error;
          
          if (data && data.webhook_api_key) {
            setApiKey(data.webhook_api_key);
          } else {
            const newKey = generateApiKey();
            await handleGenerateKey(newKey, false);
          }
        } catch (error) {
           toast({ title: 'Error', description: 'No se pudo cargar la API Key.', variant: 'destructive' });
        } finally {
          setLoading(false);
        }
      }, [user, toast, isLeadModuleActive]);

      useEffect(() => {
        fetchApiKey();
      }, [fetchApiKey]);

      const handleGenerateKey = async (key, showToast = true) => {
        const newKey = key || generateApiKey();
        const { error } = await supabase
          .from('profiles')
          .update({ webhook_api_key: newKey })
          .eq('id', user.id);

        if (error) {
          toast({ title: 'Error', description: 'No se pudo generar una nueva API Key.', variant: 'destructive' });
        } else {
          setApiKey(newKey);
          if (showToast) {
            toast({ title: 'Éxito', description: 'Nueva API Key generada y guardada.' });
          }
        }
      };

      const copyToClipboard = (text, type) => {
        navigator.clipboard.writeText(text).then(() => {
          const setCopied = type === 'key' ? setIsCopiedKey : setIsCopiedUrl;
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
          toast({ title: 'Copiado', description: 'El texto se ha copiado al portapapeles.' });
        });
      };

      const handleTestWebhook = async () => {
        if (!apiKey) {
          toast({ title: 'Error', description: 'No se ha generado una API Key.', variant: 'destructive' });
          return;
        }
        setTesting(true);
        try {
          const testLead = {
            name: 'Lead de Prueba Universal',
            email: `test.${Date.now()}@ejemplo.com`,
            source: 'Prueba de Webhook CRM',
            mensaje_de_prueba: 'Este es un mensaje de prueba para verificar la nueva conexión universal.'
          };

          const { data, error } = await supabase.functions.invoke('lead-webhook', {
            body: JSON.stringify(testLead),
            headers: {
              'x-api-key': apiKey
            }
          });

          if (error) throw error;
          if (data.error) throw new Error(data.error);

          toast({
            title: '¡Prueba Exitosa!',
            description: 'El lead de prueba ha sido creado. Revisa tu pestaña de Leads.',
          });

        } catch (error) {
          console.error("Test webhook error:", error);
          toast({
            title: 'Error en la Prueba',
            description: `No se pudo crear el lead de prueba: ${error.message}`,
            variant: 'destructive',
          });
        } finally {
          setTesting(false);
        }
      };
      
      if (!isLeadModuleActive) {
        return (
          <motion.div 
              initial={{ opacity: 0, y: 20 }} 
              animate={{ opacity: 1, y: 0 }} 
              className="text-center p-8 bg-background rounded-lg shadow-sm max-w-md mx-auto"
            >
              <ZapOff className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h2 className="text-2xl font-bold mb-2">Módulo de Leads Desactivado</h2>
              <p className="text-muted-foreground mb-6">
                Para configurar el webhook de leads, primero necesitas activar este módulo.
              </p>
              <Button asChild>
                <Link to="/settings/modules">
                  <Settings className="mr-2 h-4 w-4" />
                  Activar en Módulos
                </Link>
              </Button>
            </motion.div>
        );
      }

      return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card>
            <CardHeader>
              <CardTitle>Webhook Universal de Leads</CardTitle>
              <CardDescription>
                Usa esta URL única para capturar leads desde cualquier formulario o sistema externo.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="webhook-url">URL del Webhook (POST)</Label>
                <div className="flex items-center gap-2">
                  <Input id="webhook-url" value={webhookUrl} readOnly className="bg-muted"/>
                  <Button variant="outline" size="icon" onClick={() => copyToClipboard(webhookUrl, 'url')}>
                    {isCopiedUrl ? <ClipboardCheck className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="api-key">Tu API Key</Label>
                <div className="flex items-center gap-2">
                  <Input id="api-key" type="password" value={loading ? 'Cargando...' : apiKey} readOnly className="bg-muted" />
                  <Button variant="outline" size="icon" onClick={() => copyToClipboard(apiKey, 'key')}>
                    {isCopiedKey ? <ClipboardCheck className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                  </Button>
                  <Button variant="outline" size="icon" onClick={() => handleGenerateKey()}>
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground">
                  Usa esta clave en la cabecera `x-api-key` o `Authorization: Bearer TU_CLAVE` para autenticar.
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleTestWebhook} disabled={testing || loading}>
                <Zap className="mr-2 h-4 w-4" />
                {testing ? 'Probando...' : 'Probar Webhook'}
              </Button>
            </CardFooter>
          </Card>

          <Card className="mt-6 border-blue-200 bg-blue-50/30 dark:border-blue-900 dark:bg-blue-900/10">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Server className="h-6 w-6 text-blue-600" />
                <div>
                  <CardTitle>Instrucciones de Implementación</CardTitle>
                  <CardDescription>
                    Sigue estos pasos para enviar datos a tu nuevo webhook universal.
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 text-sm">
                <p>Realiza una petición HTTP <strong>POST</strong> a tu URL del webhook con un cuerpo (body) en formato <strong>JSON</strong>. El sistema es inteligente y encontrará los datos más importantes.</p>
                <ul className="list-disc list-inside space-y-2 pl-4">
                  <li>
                    <strong>Nombres de Campo Flexibles:</strong> El sistema buscará automáticamente `name`, `full_name`, `nombre`, `email`, `correo`, etc.
                  </li>
                  <li>
                    <strong>Datos Adicionales:</strong> ¡Cualquier otro campo que envíes (`telefono`, `asunto`, `mensaje`, `idWidget`...) se guardará automáticamente en las notas del lead!
                  </li>
                </ul>
                <div>
                  <p className="font-semibold mb-2 mt-4">Ejemplo de código (JavaScript Fetch):</p>
                  <pre className="bg-background/70 dark:bg-background/40 p-4 rounded-md overflow-x-auto text-xs">
                    <code>
    {`const datosDelFormulario = {
      // El sistema encontrará estos campos:
      nombre_completo: 'Cliente Potencial de Elementor',
      correo_electronico: 'cliente@ejemplo.com',
      
      // Y también guardará todos estos datos extra:
      telefono: '+1234567890',
      asunto_del_mensaje: 'Interesado en Servicio X',
      utm_campaign: 'google_ads_verano'
    };

    fetch('${webhookUrl}', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': '${apiKey || 'TU_API_KEY_SECRETA'}'
        // También funciona con: 'Authorization': 'Bearer ${apiKey || 'TU_API_KEY_SECRETA'}'
      },
      body: JSON.stringify(datosDelFormulario)
    })
    .then(response => response.json())
    .then(data => console.log('Éxito:', data))
    .catch(error => console.error('Error:', error));`}
                    </code>
                  </pre>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      );
    };

    export default LeadSettings;