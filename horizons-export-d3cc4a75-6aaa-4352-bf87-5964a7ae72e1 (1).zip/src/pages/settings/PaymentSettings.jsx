import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Terminal, CreditCard, ExternalLink, CheckCircle, Percent, Power } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { PasswordInput } from '@/components/ui/password-input';
import { Switch } from '@/components/ui/switch';

const IntegrationCard = ({ title, description, logo, children }) => (
    <Card className="hover:shadow-lg transition-shadow duration-300">
        <CardHeader>
            <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-3">
                    {logo}
                    {title}
                </CardTitle>
            </div>
            <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardContent>
            {children}
        </CardContent>
    </Card>
);

const PaymentSettings = () => {
    const { profile, user, fetchProfile } = useAuth();
    const { toast } = useToast();

    const [paymentSettings, setPaymentSettings] = useState({
        enable_payment_button: false,
        allow_percentage_selection: false,
        stripe: { publishable_key: '', connected: false },
        payphone: { store_id: '', connected: false },
    });
    
    const [stripeSecretKey, setStripeSecretKey] = useState('');
    const [isLoadingStripe, setIsLoadingStripe] = useState(false);
    
    const [payphoneToken, setPayphoneToken] = useState('');
    const [isLoadingPayphone, setIsLoadingPayphone] = useState(false);
    
    const [isLoadingSettings, setIsLoadingSettings] = useState(false);

    const isPaymentModuleActive = profile?.module_settings?.payment_collection;

    useEffect(() => {
        if (profile?.payment_settings) {
            setPaymentSettings(prev => ({
                ...prev,
                ...profile.payment_settings,
                stripe: { ...prev.stripe, ...profile.payment_settings.stripe },
                payphone: { ...prev.payphone, ...profile.payment_settings.payphone },
            }));
        }
    }, [profile]);

    const handleSettingsChange = (key, value) => {
        setPaymentSettings(prev => ({ ...prev, [key]: value }));
    };

    const handleSaveSettings = async () => {
        setIsLoadingSettings(true);
        const { error } = await supabase
            .from('profiles')
            .update({ payment_settings: paymentSettings })
            .eq('id', user.id);

        if (error) {
            toast({ title: 'Error', description: 'No se pudo guardar la configuración de cobros.', variant: 'destructive' });
        } else {
            toast({ title: 'Éxito', description: 'Configuración de cobros guardada.' });
            await fetchProfile();
        }
        setIsLoadingSettings(false);
    };

    const handleStripeConnect = async () => {
        if (!paymentSettings.stripe.publishable_key || !stripeSecretKey) {
            toast({ title: 'Error', description: 'Por favor, introduce ambas claves de Stripe.', variant: 'destructive' });
            return;
        }
        setIsLoadingStripe(true);

        try {
            const { error: secretError } = await supabase.functions.invoke('save-stripe-secret', {
                body: { secret: stripeSecretKey },
            });

            if (secretError) throw new Error(`Error al guardar la clave secreta: ${secretError.message}`);

            const updatedSettings = {
                ...paymentSettings,
                stripe: { ...paymentSettings.stripe, connected: true },
            };

            const { error: profileError } = await supabase
                .from('profiles')
                .update({ payment_settings: updatedSettings })
                .eq('id', user.id);

            if (profileError) throw new Error(`Error al actualizar el perfil: ${profileError.message}`);

            await fetchProfile();
            toast({ title: '¡Éxito!', description: 'Stripe conectado correctamente.' });
            setStripeSecretKey('');
        } catch (error) {
            toast({ title: 'Error de conexión', description: error.message, variant: 'destructive' });
        } finally {
            setIsLoadingStripe(false);
        }
    };

    const handlePayphoneConnect = async () => {
        if (!payphoneToken || !paymentSettings.payphone.store_id) {
            toast({ title: 'Error', description: 'Por favor, introduce el Token y el Store ID de PayPhone.', variant: 'destructive' });
            return;
        }
        setIsLoadingPayphone(true);

        try {
            const { error: secretError } = await supabase.functions.invoke('save-payphone-secret', {
                body: { secret: payphoneToken },
            });

            if (secretError) throw new Error(`Error al guardar el token secreto: ${secretError.message}`);

            const updatedSettings = {
                ...paymentSettings,
                payphone: { ...paymentSettings.payphone, connected: true },
            };

            const { error: profileError } = await supabase
                .from('profiles')
                .update({ payment_settings: updatedSettings })
                .eq('id', user.id);

            if (profileError) throw new Error(`Error al actualizar el perfil: ${profileError.message}`);
            
            await fetchProfile();
            toast({ title: '¡Éxito!', description: 'PayPhone conectado correctamente.' });
            setPayphoneToken('');
        } catch (error) {
            toast({ title: 'Error de conexión', description: error.message, variant: 'destructive' });
        } finally {
            setIsLoadingPayphone(false);
        }
    };

    if (!isPaymentModuleActive) {
        return (
            <Alert variant="default" className="bg-yellow-50 border-yellow-200 text-yellow-800">
                <Terminal className="h-4 w-4" />
                <AlertTitle>Módulo de Cobro Desactivado</AlertTitle>
                <AlertDescription>
                    Para configurar las pasarelas de pago, primero debes activar el "Módulo de Cobro".
                    <Button variant="link" asChild className="p-0 h-auto ml-1">
                        <Link to="/settings/modules">Ir a Módulos para activarlo.</Link>
                    </Button>
                </AlertDescription>
            </Alert>
        );
    }

    return (
        <motion.div 
            className="space-y-6"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
        >
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><CreditCard className="h-5 w-5 text-primary" />Configuración de Cobros</CardTitle>
                    <CardDescription>Gestiona cómo y cuándo recibes pagos por tus propuestas.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="flex items-center justify-between p-4 rounded-lg border">
                        <div className="flex items-center gap-3">
                            <Power className="h-5 w-5 text-primary" />
                            <div>
                                <Label htmlFor="enable_payment_button" className="font-semibold">Habilitar Botón de Pago</Label>
                                <p className="text-sm text-muted-foreground">Muestra el botón de pago en las propuestas aprobadas.</p>
                            </div>
                        </div>
                        <Switch id="enable_payment_button" checked={paymentSettings.enable_payment_button} onCheckedChange={(checked) => handleSettingsChange('enable_payment_button', checked)} />
                    </div>
                    <div className={`flex items-center justify-between p-4 rounded-lg border transition-opacity ${!paymentSettings.enable_payment_button && 'opacity-50'}`}>
                        <div className="flex items-center gap-3">
                            <Percent className="h-5 w-5 text-primary" />
                            <div>
                                <Label htmlFor="allow_percentage_selection" className="font-semibold">Permitir Selección de Anticipo</Label>
                                <p className="text-sm text-muted-foreground">Permite elegir un porcentaje de anticipo al crear propuestas.</p>
                            </div>
                        </div>
                        <Switch id="allow_percentage_selection" checked={paymentSettings.allow_percentage_selection} onCheckedChange={(checked) => handleSettingsChange('allow_percentage_selection', checked)} disabled={!paymentSettings.enable_payment_button} />
                    </div>
                    <div className="flex justify-end">
                        <Button onClick={handleSaveSettings} disabled={isLoadingSettings}>
                            {isLoadingSettings ? 'Guardando...' : 'Guardar Configuración de Cobros'}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }}>
                    <IntegrationCard 
                        title="Stripe" 
                        description="Acepta pagos con tarjeta de crédito de forma segura."
                        logo={<img alt="Stripe logo" className="h-8 w-auto" src="https://images.unsplash.com/photo-1586880244543-0528a802be97" />}
                    >
                        <div className="space-y-4">
                            {paymentSettings.stripe?.connected && (
                                <Alert variant="default" className="bg-green-50 border-green-200 text-green-800">
                                    <CheckCircle className="h-4 w-4" />
                                    <AlertTitle>Stripe Conectado</AlertTitle>
                                    <AlertDescription>Tu cuenta de Stripe está conectada.</AlertDescription>
                                </Alert>
                            )}
                             <div className="space-y-2">
                                <Label htmlFor="stripe-pk">Clave Publicable</Label>
                                <Input id="stripe-pk" placeholder="pk_test_..." value={paymentSettings.stripe?.publishable_key || ''} onChange={(e) => setPaymentSettings(p => ({...p, stripe: {...p.stripe, publishable_key: e.target.value}}))} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="stripe-sk">Clave Secreta</Label>
                                <PasswordInput id="stripe-sk" placeholder="sk_test_... o ••••••••••••" value={stripeSecretKey} onChange={(e) => setStripeSecretKey(e.target.value)} />
                                <p className="text-xs text-muted-foreground">Tu clave secreta se guarda de forma segura y no se volverá a mostrar.</p>
                            </div>
                            <Button onClick={handleStripeConnect} disabled={isLoadingStripe}>
                                {isLoadingStripe ? 'Conectando...' : 'Conectar Stripe'}
                            </Button>
                        </div>
                    </IntegrationCard>
                </motion.div>
                
                 <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2 }}>
                    <IntegrationCard 
                        title="PayPhone" 
                        description="Ideal para pagos en Ecuador y Latinoamérica."
                        logo={<img alt="PayPhone logo" className="h-8 w-auto" src="https://images.unsplash.com/photo-1674090556639-fd6f108d1bde" />}
                    >
                         <div className="space-y-4">
                            {paymentSettings.payphone?.connected && (
                                <Alert variant="default" className="bg-green-50 border-green-200 text-green-800">
                                    <CheckCircle className="h-4 w-4" />
                                    <AlertTitle>PayPhone Conectado</AlertTitle>
                                    <AlertDescription>Tu cuenta de PayPhone está conectada.</AlertDescription>
                                </Alert>
                            )}
                            <div className="space-y-2">
                                <Label htmlFor="payphone-storeid">Store ID</Label>
                                <Input id="payphone-storeid" placeholder="Tu Store ID" value={paymentSettings.payphone?.store_id || ''} onChange={(e) => setPaymentSettings(p => ({...p, payphone: {...p.payphone, store_id: e.target.value}}))} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="payphone-token">Token</Label>
                                <PasswordInput id="payphone-token" placeholder="Tu Token de autenticación" value={payphoneToken} onChange={(e) => setPayphoneToken(e.target.value)} />
                                <p className="text-xs text-muted-foreground">Tu token se guarda de forma segura y no se volverá a mostrar.</p>
                            </div>
                            <Button onClick={handlePayphoneConnect} disabled={isLoadingPayphone}>
                                {isLoadingPayphone ? 'Conectando...' : 'Conectar PayPhone'}
                            </Button>
                        </div>
                    </IntegrationCard>
                </motion.div>
                
                <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.3 }}>
                    <IntegrationCard 
                        title="PayPal" 
                        description="Permite pagos a través de cuentas de PayPal."
                        logo={<img alt="PayPal logo" className="h-8 w-auto" src="https://images.unsplash.com/photo-1586880244543-0528a802be97" />}
                    >
                         <Alert>
                            <Terminal className="h-4 w-4" />
                            <AlertTitle>Integración en desarrollo</AlertTitle>
                            <AlertDescription>
                                La conexión con PayPal estará disponible próximamente. <a href="https://paypal.com" target="_blank" rel="noreferrer" className="underline font-bold">Visitar PayPal <ExternalLink className="inline h-3 w-3"/></a>
                            </AlertDescription>
                        </Alert>
                    </IntegrationCard>
                </motion.div>
            </div>
        </motion.div>
    );
};

export default PaymentSettings;