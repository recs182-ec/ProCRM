import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Trash2, Shield, UserCog, User, Edit, Send, RefreshCw, Clock } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';

const UserSettings = () => {
    const { user, profile } = useAuth();
    const { toast } = useToast();
    const [invitedEmail, setInvitedEmail] = useState('');
    const [teamMembers, setTeamMembers] = useState([]);
    const [editingUser, setEditingUser] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isFetching, setIsFetching] = useState(true);
    const roleDisplay = { admin: 'Admin', supervisor: 'Supervisor', coordinador: 'Coordinador', client: 'Cliente', invitado: 'Invitado' };

    const fetchTeamMembers = useCallback(async () => {
        setIsFetching(true);
        if (!user || !profile?.account_id) {
            setIsFetching(false);
            return;
        }
        
        const { data, error } = await supabase.rpc('get_users_for_account', { acc_id: profile.account_id });

        if (error) {
            toast({ title: 'Error', description: 'No se pudieron cargar los miembros del equipo.', variant: 'destructive' });
        } else {
            setTeamMembers(data?.filter(u => u.role !== 'client' && u.id) || []);
        }
        setIsFetching(false);
    }, [user, profile, toast]);

    useEffect(() => {
        fetchTeamMembers();
    }, [fetchTeamMembers]);

    const handleInviteUser = async () => {
        if (!invitedEmail.trim()) {
            toast({ title: 'Campo requerido', description: 'Por favor, introduce un correo electrónico.', variant: 'destructive' });
            return;
        }
        setIsLoading(true);

        try {
            const { data: { session } } = await supabase.auth.getSession();
            if (!session) throw new Error('No autenticado. Por favor, inicia sesión de nuevo.');

            const { data, error } = await supabase.functions.invoke('invite-user', {
                body: { invited_email: invitedEmail },
            });

            if (error) throw error;
            
            toast({ title: '¡Invitación Enviada!', description: data.message });
            setInvitedEmail('');
            fetchTeamMembers();
        } catch (error) {
            const errorMessage = error.message || 'Ocurrió un error desconocido.';
            toast({ title: 'Error al Invitar', description: `No se pudo enviar la invitación: ${errorMessage}`, variant: 'destructive' });
        } finally {
            setIsLoading(false);
        }
    };

    const handleUpdateUserRole = async (userId, newRole) => {
        const { error } = await supabase.from('profiles').update({ role: newRole }).eq('id', userId);
        if(error) {
            toast({title: 'Error', description: 'No se pudo actualizar el rol del usuario.', variant: 'destructive'});
        } else {
            toast({title: 'Éxito', description: 'Rol de usuario actualizado.'});
            fetchTeamMembers();
            setEditingUser(null);
        }
    };

    const handleDelete = async (member) => {
        if (member.status === 'pendiente') {
            await handleDeleteInvitation(member.id);
        } else {
            await handleDeleteUser(member.id);
        }
    };

    const handleDeleteInvitation = async (invitationId) => {
        const { error } = await supabase.from('user_invites').delete().eq('id', invitationId);

        if (error) {
            toast({ title: 'Error', description: `No se pudo eliminar la invitación: ${error.message}`, variant: 'destructive' });
        } else {
            toast({ title: 'Éxito', description: 'Invitación eliminada correctamente.' });
            fetchTeamMembers();
        }
    };

    const handleDeleteUser = async (userIdToDelete) => {
        if(userIdToDelete === user.id) {
            toast({title: 'Acción no permitida', description: 'No puedes eliminar tu propia cuenta desde esta sección.', variant: 'destructive'});
            return;
        }
        
        const { error } = await supabase.functions.invoke('delete-user', { body: { user_id: userIdToDelete } });

        if(error) {
            toast({title: 'Error', description: `No se pudo eliminar el usuario: ${error.message}`, variant: 'destructive'});
        } else {
            toast({title: 'Éxito', description: 'Usuario eliminado correctamente.'});
            fetchTeamMembers();
        }
    };
    
    return (
        <Card>
            <CardHeader>
                <CardTitle>Gestionar Usuarios del Equipo</CardTitle>
                <CardDescription>Invita nuevos miembros y administra los roles de tu equipo.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="flex items-end gap-4 p-4 border rounded-lg bg-muted/20">
                    <div className="flex-1">
                        <Label htmlFor="invite">Invitar nuevo miembro al equipo</Label>
                        <Input 
                          id="invite" 
                          type="email" 
                          value={invitedEmail} 
                          onChange={(e) => setInvitedEmail(e.target.value)} 
                          placeholder="nombre@ejemplo.com"
                          disabled={isLoading}
                        />
                    </div>
                    <Button onClick={handleInviteUser} disabled={isLoading}>
                        {isLoading ? 'Enviando...' : <><Send className="h-4 w-4 mr-2" /> Enviar Invitación</>}
                    </Button>
                </div>
                <div className="border-t pt-4">
                    <div className="flex justify-between items-center mb-2">
                        <h4 className="font-semibold text-lg">Miembros del Equipo</h4>
                        <Button variant="outline" size="sm" onClick={fetchTeamMembers} disabled={isFetching}>
                            <RefreshCw className={`h-4 w-4 mr-2 ${isFetching ? 'animate-spin' : ''}`} />
                            Actualizar Lista
                        </Button>
                    </div>
                    {isFetching ? (
                        <div className="text-center py-8 text-muted-foreground">Cargando miembros del equipo...</div>
                    ) : teamMembers.length > 0 ? (
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Email</TableHead>
                                    <TableHead>Rol</TableHead>
                                    <TableHead>Estado</TableHead>
                                    <TableHead className="text-right">Acciones</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {teamMembers.map(member => (
                                    <TableRow key={member.id}>
                                        <TableCell className="font-medium">{member.email}</TableCell>
                                        <TableCell>
                                            {editingUser === member.id && profile?.role === 'admin' && member.status === 'activo' ? (
                                                <Select defaultValue={member.role} onValueChange={(newRole) => handleUpdateUserRole(member.id, newRole)}>
                                                    <SelectTrigger className="w-[180px]"><SelectValue placeholder="Seleccionar rol" /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="admin"><Shield className="h-4 w-4 mr-2 inline-block"/>Admin</SelectItem>
                                                        <SelectItem value="supervisor"><UserCog className="h-4 w-4 mr-2 inline-block"/>Supervisor</SelectItem>
                                                        <SelectItem value="coordinador"><User className="h-4 w-4 mr-2 inline-block"/>Coordinador</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            ) : (
                                                <div className="flex items-center gap-2">
                                                    {member.role === 'admin' && <Shield className="h-4 w-4 text-primary" />}
                                                    {member.role === 'supervisor' && <UserCog className="h-4 w-4 text-yellow-600" />}
                                                    {member.role === 'coordinador' && <User className="h-4 w-4 text-gray-500" />}
                                                    {member.role === 'invitado' && <Clock className="h-4 w-4 text-gray-400" />}
                                                    {roleDisplay[member.role] || member.role}
                                                </div>
                                            )}
                                        </TableCell>
                                        <TableCell>
                                            {member.status === 'pendiente' ? (
                                                <Badge variant="secondary" className="flex items-center gap-1.5">
                                                    <Clock className="h-3 w-3" />
                                                    Pendiente
                                                </Badge>
                                            ) : (
                                                <Badge variant="default" className="bg-green-600 hover:bg-green-700">Activo</Badge>
                                            )}
                                        </TableCell>
                                        <TableCell className="text-right">
                                            {user.id !== member.id && profile?.role === 'admin' && (
                                                <>
                                                    {member.status === 'activo' && (
                                                        <>
                                                            {editingUser === member.id ? (
                                                                <Button variant="ghost" size="sm" onClick={() => setEditingUser(null)}>Cancelar</Button>
                                                            ) : (
                                                                <Button variant="outline" size="sm" onClick={() => setEditingUser(member.id)}><Edit className="h-4 w-4 mr-2"/>Editar Rol</Button>
                                                            )}
                                                        </>
                                                    )}
                                                    
                                                    <AlertDialog>
                                                        <AlertDialogTrigger asChild>
                                                            <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive-foreground hover:bg-destructive ml-2">
                                                              <Trash2 className="h-4 w-4" />
                                                            </Button>
                                                        </AlertDialogTrigger>
                                                        <AlertDialogContent>
                                                            <AlertDialogHeader>
                                                                <AlertDialogTitle>
                                                                    {member.status === 'pendiente' ? `¿Eliminar la invitación para ${member.email}?` : `¿Estás seguro de eliminar a ${member.email}?`}
                                                                </AlertDialogTitle>
                                                                <AlertDialogDescription>
                                                                    {member.status === 'pendiente' ? "Esta acción cancelará la invitación y no podrá ser aceptada." : "Esta acción es irreversible. El usuario será eliminado de tu cuenta permanentemente."}
                                                                </AlertDialogDescription>
                                                            </AlertDialogHeader>
                                                            <AlertDialogFooter>
                                                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                                                <AlertDialogAction onClick={() => handleDelete(member)} className="bg-destructive hover:bg-destructive/90">
                                                                    {member.status === 'pendiente' ? 'Eliminar Invitación' : 'Eliminar Usuario'}
                                                                </AlertDialogAction>
                                                            </AlertDialogFooter>
                                                        </AlertDialogContent>
                                                    </AlertDialog>
                                                </>
                                            )}
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    ) : (
                      <div className="text-center py-8 text-muted-foreground bg-muted/30 rounded-lg">
                        <p>No hay otros miembros en tu equipo.</p>
                        <p className="text-sm">¡Invita a alguien para empezar a colaborar!</p>
                      </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
};

export default UserSettings;