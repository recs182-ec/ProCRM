import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Save, Bell, Users, User } from 'lucide-react';
import { motion } from 'framer-motion';

const defaultSettings = {
  client_notifications: {
    new_proposal: true,
    proposal_accepted: true,
  },
  internal_notifications: {
    new_proposal: true,
    proposal_accepted: true,
    new_job: true,
    new_task: true,
    new_lead: true,
  },
};

const NotificationSettings = () => {
    const { user, profile, fetchProfile } = useAuth();
    const { toast } = useToast();
    const [settings, setSettings] = useState(defaultSettings);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        if (profile?.notification_settings) {
            // Deep merge to ensure all keys from defaultSettings are present
            const mergedSettings = {
                client_notifications: {
                    ...defaultSettings.client_notifications,
                    ...(profile.notification_settings.client_notifications || {}),
                },
                internal_notifications: {
                    ...defaultSettings.internal_notifications,
                    ...(profile.notification_settings.internal_notifications || {}),
                },
            };
            setSettings(mergedSettings);
        }
        setLoading(false);
    }, [profile]);
    
    const handleSwitchChange = (category, key) => {
        setSettings(prevSettings => ({
            ...prevSettings,
            [category]: {
                ...prevSettings[category],
                [key]: !prevSettings[category][key],
            },
        }));
    };

    const handleSave = async () => {
        if (!user) return;
        setSaving(true);
        
        const { error } = await supabase
            .from('profiles')
            .update({ notification_settings: settings })
            .eq('id', user.id);

        if (error) {
            toast({ title: 'Error', description: 'No se pudo guardar la configuración de notificaciones.', variant: 'destructive' });
        } else {
            toast({ title: 'Éxito', description: 'Configuración de notificaciones guardada.' });
            fetchProfile(); // Re-fetch profile to update context
        }
        setSaving(false);
    };

    if (loading) {
        return (
          <Card>
            <CardContent className="pt-6 flex justify-center items-center h-64">
              <div className="loader"></div>
            </CardContent>
          </Card>
        );
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2"><Bell className="h-5 w-5 text-primary" />Configuración de Notificaciones</CardTitle>
                <CardDescription>Elige qué notificaciones por correo electrónico se deben enviar.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                    <h3 className="text-lg font-semibold flex items-center gap-2 mb-4"><User className="h-5 w-5" />Notificaciones al Cliente</h3>
                    <div className="space-y-4 rounded-lg border p-4">
                        <div className="flex items-center justify-between">
                            <Label htmlFor="client_new_proposal" className="flex-grow">Crear una propuesta nueva.</Label>
                            <Switch id="client_new_proposal" checked={settings.client_notifications.new_proposal} onCheckedChange={() => handleSwitchChange('client_notifications', 'new_proposal')} />
                        </div>
                        <div className="flex items-center justify-between">
                            <Label htmlFor="client_proposal_accepted" className="flex-grow">Al aceptar la propuesta (enviar PDF de aprobación).</Label>
                            <Switch id="client_proposal_accepted" checked={settings.client_notifications.proposal_accepted} onCheckedChange={() => handleSwitchChange('client_notifications', 'proposal_accepted')} />
                        </div>
                    </div>
                </motion.div>

                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
                    <div className="border-t pt-8">
                        <h3 className="text-lg font-semibold flex items-center gap-2 mb-4"><Users className="h-5 w-5" />Notificaciones Internas (a usuarios asignados)</h3>
                        <div className="space-y-4 rounded-lg border p-4">
                            <div className="flex items-center justify-between">
                                <Label htmlFor="internal_new_proposal" className="flex-grow">Crear una nueva propuesta.</Label>
                                <Switch id="internal_new_proposal" checked={settings.internal_notifications.new_proposal} onCheckedChange={() => handleSwitchChange('internal_notifications', 'new_proposal')} />
                            </div>
                            <div className="flex items-center justify-between">
                                <Label htmlFor="internal_proposal_accepted" className="flex-grow">Cuando el cliente acepta la propuesta.</Label>
                                <Switch id="internal_proposal_accepted" checked={settings.internal_notifications.proposal_accepted} onCheckedChange={() => handleSwitchChange('internal_notifications', 'proposal_accepted')} />
                            </div>
                            <div className="flex items-center justify-between">
                                <Label htmlFor="internal_new_job" className="flex-grow">Cuando se crea un trabajo nuevo.</Label>
                                <Switch id="internal_new_job" checked={settings.internal_notifications.new_job} onCheckedChange={() => handleSwitchChange('internal_notifications', 'new_job')} />
                            </div>
                            <div className="flex items-center justify-between">
                                <Label htmlFor="internal_new_task" className="flex-grow">Cuando se crea una tarea nueva.</Label>
                                <Switch id="internal_new_task" checked={settings.internal_notifications.new_task} onCheckedChange={() => handleSwitchChange('internal_notifications', 'new_task')} />
                            </div>
                            <div className="flex items-center justify-between">
                                <Label htmlFor="internal_new_lead" className="flex-grow">Cuando llegan leads nuevos.</Label>
                                <Switch id="internal_new_lead" checked={settings.internal_notifications.new_lead} onCheckedChange={() => handleSwitchChange('internal_notifications', 'new_lead')} />
                            </div>
                        </div>
                    </div>
                </motion.div>
            </CardContent>
            <CardFooter>
                 <Button onClick={handleSave} disabled={saving}>
                    <Save className="h-4 w-4 mr-2" />
                    {saving ? 'Guardando...' : 'Guardar Cambios'}
                </Button>
            </CardFooter>
        </Card>
    );
};

export default NotificationSettings;