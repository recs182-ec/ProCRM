
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Mail, Send, Key, Info, Copy, Check, Save } from 'lucide-react';
import { PasswordInput } from '@/components/ui/password-input';

const IP_ADDRESSES = {
    ipv4: "3.211.47.163",
    ipv6: "2600:1f18:2479:b000:a1a9:794c:d51c:a1b3"
};

const EmailSettings = () => {
    const { user } = useAuth();
    const { toast } = useToast();
    const [brevoApiKey, setBrevoApiKey] = useState('');
    const [senderEmail, setSenderEmail] = useState('');
    const [copiedIp, setCopiedIp] = useState(null);
    const [isSaving, setIsSaving] = useState(false);
    const [isTesting, setIsTesting] = useState(false);

    const loadSettings = useCallback(async () => {
        if (!user) return;
        const { data } = await supabase.from('settings').select('brevo_api_key, brevo_smtp_user').eq('user_id', user.id).single();
        if (data) {
            setBrevoApiKey(data.brevo_api_key || '');
            setSenderEmail(data.brevo_smtp_user || '');
        }
    }, [user]);

    useEffect(() => {
        loadSettings();
    }, [loadSettings]);

    const handleSave = async () => {
        if (!user) return;
        if (!brevoApiKey || !senderEmail) {
            toast({ title: 'Campos requeridos', description: 'Por favor, completa el email remitente y la clave API.', variant: 'destructive' });
            return;
        }
        setIsSaving(true);

        // 1. Save settings to our 'settings' table
        const { error: settingsError } = await supabase.from('settings').upsert({
            user_id: user.id,
            brevo_api_key: brevoApiKey,
            brevo_smtp_user: senderEmail
        }, { onConflict: 'user_id' });

        if (settingsError) {
            setIsSaving(false);
            toast({ title: 'Error', description: `No se pudo guardar la configuración: ${settingsError.message}`, variant: 'destructive' });
            return;
        }

        // 2. Invoke edge function to set Brevo as custom SMTP in Supabase Auth
        const { error: functionError } = await supabase.functions.invoke('save-brevo-secret', {
            body: { brevoApiKey }
        });

        setIsSaving(false);
        if (functionError) {
            toast({ title: 'Error Crítico', description: `Configuración guardada, pero no se pudo activar el SMTP personalizado: ${functionError.message}. Contacta a soporte.`, variant: 'destructive' });
        } else {
            toast({ title: '¡Éxito Total!', description: 'Configuración de correo guardada y activada para toda la plataforma.' });
        }
    };

    const sendTestEmail = async () => {
        if (!user || !user.email) return;
        setIsTesting(true);
        toast({ title: 'Enviando...', description: 'Se está enviando el correo de prueba.' });
        const { error } = await supabase.functions.invoke('send-test-email', { body: { userId: user.id, userEmail: user.email } });
        setIsTesting(false);
        if (error) {
            toast({ title: 'Error', description: `No se pudo enviar el correo de prueba: ${error.message}`, variant: 'destructive' });
        } else {
            toast({ title: '¡Correo Enviado!', description: `Se ha enviado un correo de prueba a ${user.email}.` });
        }
    };

    const copyToClipboard = (text, type) => {
        navigator.clipboard.writeText(text);
        setCopiedIp(type);
        setTimeout(() => setCopiedIp(null), 2000);
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2"><Mail className="h-5 w-5 text-primary" />Conexión de Correo</CardTitle>
                <CardDescription>Conecta Brevo (Sendinblue) para enviar todos los correos de la plataforma (confirmaciones, propuestas, etc.).</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div>
                    <Label htmlFor="sender_email" className="flex items-center gap-2">Email Remitente</Label>
                    <Input id="sender_email" value={senderEmail} onChange={e => setSenderEmail(e.target.value)} placeholder="tu@email.com" />
                    <p className="text-xs text-muted-foreground mt-1">Debe ser el mismo email de tu cuenta de Brevo.</p>
                </div>
                <div>
                    <Label htmlFor="api_key" className="flex items-center gap-2"><Key className="h-4 w-4"/>Clave API v3 de Brevo</Label>
                    <PasswordInput id="api_key" value={brevoApiKey} onChange={e => setBrevoApiKey(e.target.value)} placeholder="xkeysib-..." />
                </div>
                <div className="bg-blue-50 border-l-4 border-blue-500 text-blue-700 p-4 rounded-md" role="alert">
                    <div className="flex">
                        <div className="py-1"><Info className="h-5 w-5 text-blue-500 mr-3" /></div>
                        <div>
                            <p className="font-bold">IPs para Lista de Confianza de Brevo</p>
                            <p className="text-sm mt-1">Para que los correos se envíen correctamente, debes añadir las siguientes IPs a tu lista de confianza en Brevo. <a href="https://app.brevo.com/security/authorised_ips" target="_blank" rel="noopener noreferrer" className="font-semibold underline">Haz clic aquí para ir a la página.</a></p>
                            <div className="mt-3 space-y-2">
                                <div className="flex items-center justify-between bg-blue-100 px-2 py-1 rounded">
                                    <p className="font-mono text-sm">IPv4: {IP_ADDRESSES.ipv4}</p>
                                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => copyToClipboard(IP_ADDRESSES.ipv4, 'ipv4')}>
                                        {copiedIp === 'ipv4' ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
                                    </Button>
                                </div>
                                <div className="flex items-center justify-between bg-blue-100 px-2 py-1 rounded">
                                    <p className="font-mono text-sm">IPv6: {IP_ADDRESSES.ipv6}</p>
                                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => copyToClipboard(IP_ADDRESSES.ipv6, 'ipv6')}>
                                        {copiedIp === 'ipv6' ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </CardContent>
            <CardFooter className="flex flex-col sm:flex-row items-center gap-4 pt-6 border-t">
                <Button onClick={handleSave} disabled={isSaving} className="w-full sm:w-auto flex-1">
                    <Save className="mr-2 h-4 w-4" />
                    {isSaving ? 'Guardando y Activando...' : 'Guardar y Activar'}
                </Button>
                <Button onClick={sendTestEmail} variant="outline" disabled={isTesting} className="w-full sm:w-auto flex-1">
                    <Send className="mr-2 h-4 w-4" />
                    {isTesting ? 'Enviando...' : 'Enviar Correo de Prueba'}
                </Button>
            </CardFooter>
        </Card>
    );
};

export default EmailSettings;
