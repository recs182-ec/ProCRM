import React, { useState, useEffect } from 'react';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { Save, Link as LinkIcon } from 'lucide-react';

    const DocumentSettings = () => {
        const { user, profile, fetchProfile } = useAuth();
        const { toast } = useToast();
        const [termsUrl, setTermsUrl] = useState('');
        const [privacyUrl, setPrivacyUrl] = useState('');
        const [saving, setSaving] = useState(false);

        useEffect(() => {
            if (profile) {
                setTermsUrl(profile.terms_and_conditions_url || '');
                setPrivacyUrl(profile.privacy_policy_url || '');
            }
        }, [profile]);

        const handleSave = async () => {
            try {
                setSaving(true);
                if (!user) throw new Error('Usuario no autenticado.');

                const { error } = await supabase
                    .from('profiles')
                    .update({
                        terms_and_conditions_url: termsUrl,
                        privacy_policy_url: privacyUrl
                    })
                    .eq('id', user.id);

                if (error) throw error;
                
                await fetchProfile();
                toast({ title: 'Éxito', description: 'Enlaces guardados correctamente.' });
            } catch (error) {
                toast({ title: 'Error', description: error.message, variant: 'destructive' });
            } finally {
                setSaving(false);
            }
        };

        return (
            <Card>
                <CardHeader>
                    <CardTitle>Documentos Legales</CardTitle>
                    <CardDescription>Añade los enlaces a tus términos y condiciones y política de privacidad. Estos se mostrarán en tus propuestas.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-2">
                        <Label htmlFor="terms-url">URL de Términos y Condiciones</Label>
                        <Input
                            id="terms-url"
                            type="url"
                            placeholder="https://tu-empresa.com/terminos"
                            value={termsUrl}
                            onChange={(e) => setTermsUrl(e.target.value)}
                        />
                        {termsUrl && <a href={termsUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-primary hover:underline flex items-center gap-2 pt-1"><LinkIcon className="h-4 w-4" />Ver enlace actual</a>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="privacy-url">URL de Política de Privacidad</Label>
                        <Input
                            id="privacy-url"
                            type="url"
                            placeholder="https://tu-empresa.com/privacidad"
                            value={privacyUrl}
                            onChange={(e) => setPrivacyUrl(e.target.value)}
                        />
                         {privacyUrl && <a href={privacyUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-primary hover:underline flex items-center gap-2 pt-1"><LinkIcon className="h-4 w-4" />Ver enlace actual</a>}
                    </div>
                    <div>
                        <Button onClick={handleSave} disabled={saving}>
                            <Save className="mr-2 h-4 w-4" />
                            {saving ? 'Guardando...' : 'Guardar Enlaces'}
                        </Button>
                    </div>
                </CardContent>
            </Card>
        );
    };

    export default DocumentSettings;