import React from 'react';
import { Helmet } from 'react-helmet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import GeneralSettings from '@/pages/settings/GeneralSettings';
import EmailSettings from '@/pages/settings/EmailSettings';
import DocumentSettings from '@/pages/settings/DocumentSettings';
import NotificationSettings from '@/pages/settings/NotificationSettings';
import UserSettings from '@/pages/settings/UserSettings';
import LeadSettings from '@/pages/settings/LeadSettings';
import ModulesSettings from '@/pages/settings/ModulesSettings';

const SettingsPage = () => {
  return (
    <>
      <Helmet>
        <title>Configuración | CRM & Propuestas</title>
        <meta name="description" content="Gestiona la configuración general, de email, documentos, notificaciones y usuarios de tu cuenta." />
      </Helmet>
      <div className="w-full">
        <div className="mb-8">
            <h1 className="text-4xl font-bold text-gray-800">Configuración</h1>
            <p className="text-muted-foreground text-lg">Administra las preferencias y ajustes de tu cuenta.</p>
        </div>
        
        <Tabs defaultValue="general" className="w-full">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="modules">Módulos</TabsTrigger>
            <TabsTrigger value="email">Email</TabsTrigger>
            <TabsTrigger value="documents">Documentos</TabsTrigger>
            <TabsTrigger value="notifications">Notificaciones</TabsTrigger>
            <TabsTrigger value="users">Usuarios</TabsTrigger>
            <TabsTrigger value="leads">Lead Webhook</TabsTrigger>
          </TabsList>
          <TabsContent value="general">
            <GeneralSettings />
          </TabsContent>
          <TabsContent value="modules">
            <ModulesSettings />
          </TabsContent>
          <TabsContent value="email">
            <EmailSettings />
          </TabsContent>
          <TabsContent value="documents">
            <DocumentSettings />
          </TabsContent>
          <TabsContent value="notifications">
            <NotificationSettings />
          </TabsContent>
           <TabsContent value="users">
            <UserSettings />
          </TabsContent>
          <TabsContent value="leads">
            <LeadSettings />
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default SettingsPage;