import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Briefcase, CalendarClock, Bot, CreditCard, FolderKanban } from 'lucide-react';
import { motion } from 'framer-motion';

const modules = [
  { id: 'lead_capture', name: 'Captación de Leads', description: 'Activa la página de leads para capturar nuevos clientes.', icon: Briefcase },
  { id: 'appointment_scheduling', name: 'Agendamiento de Citas', description: 'Permite agendar citas en las propuestas y calendario.', icon: CalendarClock },
  { id: 'payment_collection', name: 'Módulo de Cobro', description: 'Permite a los clientes pagar propuestas aprobadas directamente.', icon: CreditCard },
  { id: 'projects_module', name: 'Módulo de Proyectos', description: 'Gestiona proyectos y tareas complejas.', icon: FolderKanban },
  { id: 'seo_reports', name: 'Reportes SEO', description: 'Genera reportes SEO básicos para URLs.', icon: Bot, status: 'Beta' },
];

const ModulesSettings = () => {
    const { user, profile, fetchProfile } = useAuth();
    const { toast } = useToast();
    const [moduleSettings, setModuleSettings] = useState({});
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        if (profile?.module_settings) {
            setModuleSettings(profile.module_settings);
        }
    }, [profile]);

    const handleToggle = (moduleId) => {
        setModuleSettings(prev => ({ ...prev, [moduleId]: !prev[moduleId] }));
    };

    const handleSave = async () => {
        if (!user) return;
        setIsLoading(true);

        const { error } = await supabase
            .from('profiles')
            .update({ module_settings: moduleSettings })
            .eq('id', user.id);

        if (error) {
            toast({ title: 'Error', description: 'No se pudo guardar la configuración de módulos.', variant: 'destructive' });
        } else {
            toast({ title: 'Éxito', description: 'Configuración de módulos guardada.' });
            await fetchProfile(user.id);
        }
        setIsLoading(false);
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Módulos de la Plataforma</CardTitle>
                <CardDescription>Activa o desactiva funcionalidades para personalizar tu experiencia.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                {modules.map((module, index) => (
                    <motion.div
                        key={module.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                        className="flex items-center justify-between p-4 rounded-lg border bg-background hover:bg-muted/50 transition-colors"
                    >
                        <div className="flex items-start space-x-4">
                            <div className="bg-primary/10 text-primary p-2 rounded-lg">
                                <module.icon className="h-6 w-6" />
                            </div>
                            <div>
                                <div className="flex items-center gap-2">
                                    <Label htmlFor={module.id} className="text-lg font-semibold">{module.name}</Label>
                                    {module.status && (
                                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${module.status === 'Beta' ? 'bg-blue-100 text-blue-800' : 'bg-gray-200 text-gray-700'}`}>
                                            {module.status}
                                        </span>
                                    )}
                                </div>
                                <p className="text-sm text-muted-foreground">{module.description}</p>
                            </div>
                        </div>
                        <Switch
                            id={module.id}
                            checked={!!moduleSettings[module.id]}
                            onCheckedChange={() => handleToggle(module.id)}
                            disabled={isLoading || module.status === 'Próximamente'}
                        />
                    </motion.div>
                ))}
                <div className="flex justify-end pt-4">
                    <Button onClick={handleSave} disabled={isLoading}>
                        {isLoading ? 'Guardando...' : 'Guardar Cambios'}
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
};

export default ModulesSettings;