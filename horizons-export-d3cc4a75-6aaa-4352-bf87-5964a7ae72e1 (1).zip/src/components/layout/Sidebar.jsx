import React, { useState, useEffect } from 'react';
    import { NavLink, useNavigate } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { LayoutDashboard, Trello, Users, Building, ShoppingBag, Settings, LogOut, Briefcase, CalendarClock, FileText, Calendar as CalendarIcon, ChevronLeft, ChevronRight, Contact, BookMarked, FolderKanban } from 'lucide-react';
    import { cn } from '@/lib/utils';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { Button } from '@/components/ui/button';
    import { supabase } from '@/lib/customSupabaseClient';

    const mainNavItems = [
      { href: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
      { href: '/proposals', icon: FileText, label: 'Propuestas' },
      { href: '/pipeline', icon: Trello, label: 'Pipeline' },
    ];

    const operationsNavItems = [
      { href: '/jobs', icon: Briefcase, label: 'Trabajos' },
      { href: '/calendar', icon: CalendarIcon, label: 'Calendario' },
      { href: '/annual-services', icon: CalendarClock, label: 'Servicios Anuales' },
    ];
    
    const bookingNavItem = { href: '/booking', icon: BookMarked, label: 'Booking' };

    const crmNavItems = [
      { href: '/contacts', icon: Users, label: 'Contactos' },
      { href: '/companies', icon: Building, label: 'Compañías' },
      { href: '/services', icon: ShoppingBag, label: 'Servicios' },
    ];

    const projectsNavItem = { href: '/projects', icon: FolderKanban, label: 'Proyectos' };
    const leadsNavItem = { href: '/leads', icon: Contact, label: 'Leads' };

    const NavItem = ({ item, isCollapsed, newLeadsCount }) => (
      <NavLink
        to={item.href}
        className={({ isActive }) =>
          cn(
            'flex items-center gap-3 py-3 rounded-lg text-muted-foreground hover:text-primary transition-colors relative',
            isCollapsed ? 'justify-center px-3' : 'px-4',
            isActive && 'bg-primary/10 text-primary font-semibold'
          )
        }
      >
        <item.icon className="h-5 w-5 flex-shrink-0" />
        <motion.span 
          animate={{ opacity: isCollapsed ? 0 : 1, width: isCollapsed ? 0 : 'auto' }}
          transition={{ duration: 0.2 }}
          className={cn("font-medium", isCollapsed && "hidden")}>
          {item.label}
        </motion.span>
        {item.label === 'Leads' && newLeadsCount > 0 && (
           <motion.span 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className={cn(
              "absolute bg-destructive text-destructive-foreground rounded-full h-5 w-5 text-xs flex items-center justify-center",
              isCollapsed ? 'top-1 right-1' : 'right-4'
            )}
          >
            {newLeadsCount}
          </motion.span>
        )}
      </NavLink>
    );

    const Sidebar = ({ isCollapsed, setIsCollapsed }) => {
      const { user, profile, signOut } = useAuth();
      const navigate = useNavigate();
      const [logoUrl, setLogoUrl] = useState(null);
      const [newLeadsCount, setNewLeadsCount] = useState(0);

      const isLeadModuleActive = profile?.module_settings?.lead_capture === true;
      const isAppointmentModuleActive = profile?.module_settings?.appointment_scheduling === true;
      const isProjectsModuleActive = profile?.module_settings?.projects_module === true;

      useEffect(() => {
        if (!user || !profile) return;

        const fetchInitialData = async () => {
          const { data: settingsData } = await supabase
            .from('settings')
            .select('logo_url')
            .eq('user_id', user.id)
            .single();
          if (settingsData && settingsData.logo_url) {
            setLogoUrl(settingsData.logo_url);
          }
          
          if (isLeadModuleActive) {
            const { count, error } = await supabase
              .from('leads')
              .select('*', { count: 'exact', head: true })
              .eq('account_id', profile.account_id)
              .eq('is_viewed', false);
            
            if (error) {
              console.error('Error fetching new leads count:', error);
            } else {
              setNewLeadsCount(count);
            }
          } else {
            setNewLeadsCount(0);
          }
        };

        fetchInitialData();

        const settingsListener = supabase.channel('public:settings')
          .on('postgres_changes', { event: '*', schema: 'public', table: 'settings', filter: `user_id=eq.${user.id}` }, payload => {
            if (payload.new) {
              setLogoUrl(payload.new.logo_url);
            }
          })
          .subscribe();

        let leadsListener;
        if (isLeadModuleActive) {
          leadsListener = supabase.channel('public:leads')
            .on('postgres_changes', { event: '*', schema: 'public', table: 'leads', filter: `account_id=eq.${profile.account_id}` }, async (payload) => {
              const { count, error } = await supabase
                .from('leads')
                .select('*', { count: 'exact', head: true })
                .eq('account_id', profile.account_id)
                .eq('is_viewed', false);

              if (!error) {
                setNewLeadsCount(count);
              }
            })
            .subscribe();
        }

        return () => {
          supabase.removeChannel(settingsListener);
          if (leadsListener) {
            supabase.removeChannel(leadsListener);
          }
        };

      }, [user, profile, isLeadModuleActive]);

      const handleSignOut = async () => {
        await signOut();
        navigate('/login');
      };

      const toggleSidebar = () => setIsCollapsed(!isCollapsed);

      return (
        <motion.aside
          initial={false}
          animate={{ width: isCollapsed ? '5rem' : '16rem' }}
          transition={{ duration: 0.3, ease: 'easeInOut' }}
          className="bg-background border-r flex flex-col h-screen sticky top-0"
        >
          <div className={cn("flex items-center gap-2 mb-10 h-16 p-4", isCollapsed ? 'justify-center' : 'justify-between')}>
            <motion.div animate={{ opacity: isCollapsed ? 0 : 1 }} className={cn(isCollapsed ? 'hidden' : 'flex items-center gap-2')}>
              {logoUrl ? (
                <img src={logoUrl} alt="Company Logo" className="h-full w-auto max-h-8 object-contain" />
              ) : (
                <>
                  <Trello className="h-8 w-8 text-primary" />
                  <h1 className="text-xl font-bold">CRM</h1>
                </>
              )}
            </motion.div>
            <Button variant="ghost" size="icon" onClick={toggleSidebar} className="flex-shrink-0">
              {isCollapsed ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
            </Button>
          </div>
          
          <nav className="flex-1 space-y-1 px-4">
            <div className="space-y-1">
              {mainNavItems.map((item) => (
                <NavItem key={item.href} item={item} isCollapsed={isCollapsed} />
              ))}
            </div>

            <hr className="my-4 border-border" />
            
            <div className="space-y-1">
              {operationsNavItems.map((item) => (
                <NavItem key={item.href} item={item} isCollapsed={isCollapsed} />
              ))}
              {isAppointmentModuleActive && (
                <NavItem item={bookingNavItem} isCollapsed={isCollapsed} />
              )}
            </div>
            
            <hr className="my-4 border-border" />

            <div className="space-y-1">
              {crmNavItems.map((item) => (
                <NavItem key={item.href} item={item} isCollapsed={isCollapsed} />
              ))}
            </div>
            
            {(isProjectsModuleActive || isLeadModuleActive) && (
              <>
                <hr className="my-4 border-border" />
                <div className="space-y-1">
                  {isProjectsModuleActive && (
                    <NavItem item={projectsNavItem} isCollapsed={isCollapsed} />
                  )}
                  {isLeadModuleActive && (
                    <NavItem item={leadsNavItem} isCollapsed={isCollapsed} newLeadsCount={newLeadsCount} />
                  )}
                </div>
              </>
            )}
          </nav>

          <div className="mt-auto flex flex-col space-y-2 pt-4 px-4">
             <hr className="my-2 border-border" />
            <NavItem item={{ href: '/settings', icon: Settings, label: 'Configuración' }} isCollapsed={isCollapsed} />
            {user && (
              <div className={cn("flex items-center gap-3 p-2 rounded-lg", isCollapsed ? 'justify-center' : '')}>
                <div className="flex flex-col flex-1 min-w-0">
                  <motion.p 
                    animate={{ opacity: isCollapsed ? 0 : 1, width: isCollapsed ? 0 : 'auto', display: isCollapsed ? 'none' : 'block' }}
                    className="font-semibold text-sm text-foreground truncate">
                    {user.email}
                  </motion.p>
                  <Button variant="ghost" size="sm" onClick={handleSignOut} className={cn("text-muted-foreground hover:text-destructive p-0 h-auto", isCollapsed ? 'justify-center' : 'justify-start')}>
                    <LogOut className="h-4 w-4 flex-shrink-0" />
                     <motion.span 
                      animate={{ opacity: isCollapsed ? 0 : 1, width: isCollapsed ? 0 : 'auto', marginLeft: isCollapsed ? 0 : '0.25rem' }}
                      className={cn(isCollapsed && "hidden")}>
                      Cerrar sesión
                    </motion.span>
                  </Button>
                </div>
              </div>
            )}
          </div>
        </motion.aside>
      );
    };

    export default Sidebar;