
import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import ClientSidebar from '@/components/layout/ClientSidebar';
import { cn } from '@/lib/utils';

const ClientLayout = () => {
    const [isCollapsed, setIsCollapsed] = useState(false);

    return (
        <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900">
            <ClientSidebar isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />
            <main className={cn("flex-1 p-6 transition-all duration-300", isCollapsed ? 'ml-20' : 'ml-64')}>
                <div className="max-w-7xl mx-auto">
                    <Outlet />
                </div>
            </main>
        </div>
    );
};

export default ClientLayout;
