
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LayoutDashboard, Calendar, CreditCard, Settings, LogOut, ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const navItems = [
  { href: '/client/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/client/appointments', icon: Calendar, label: 'Mis Citas' },
  { href: '/client/payments', icon: CreditCard, label: 'Mis Pagos' },
];

const NavItem = ({ item, isCollapsed }) => (
  <NavLink
    to={item.href}
    className={({ isActive }) =>
      cn(
        'flex items-center gap-3 py-3 rounded-lg text-muted-foreground hover:text-primary transition-colors',
        isCollapsed ? 'justify-center px-3' : 'px-4',
        isActive && 'bg-primary/10 text-primary font-semibold'
      )
    }
  >
    <item.icon className="h-5 w-5 flex-shrink-0" />
    <motion.span 
      animate={{ opacity: isCollapsed ? 0 : 1, width: isCollapsed ? 0 : 'auto' }}
      transition={{ duration: 0.2 }}
      className={cn("font-medium", isCollapsed && "hidden")}>
      {item.label}
    </motion.span>
  </NavLink>
);

const ClientSidebar = ({ isCollapsed, setIsCollapsed }) => {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  const toggleSidebar = () => setIsCollapsed(!isCollapsed);

  const getInitials = (name) => {
    if (!name) return '?';
    const names = name.split(' ');
    if (names.length > 1) {
        return `${names[0][0]}${names[1][0]}`.toUpperCase();
    }
    return name[0].toUpperCase();
  }

  return (
    <motion.aside
      initial={false}
      animate={{ width: isCollapsed ? '5rem' : '16rem' }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="bg-background border-r flex flex-col h-screen sticky top-0"
    >
      <div className={cn("flex items-center gap-2 mb-10 h-16 p-4", isCollapsed ? 'justify-center' : 'justify-between')}>
        <motion.div animate={{ opacity: isCollapsed ? 0 : 1 }} className={cn(isCollapsed ? 'hidden' : 'flex items-center gap-2')}>
           <h1 className="text-xl font-bold">Portal Cliente</h1>
        </motion.div>
        <Button variant="ghost" size="icon" onClick={toggleSidebar} className="flex-shrink-0">
          {isCollapsed ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
        </Button>
      </div>
      
      <nav className="flex-1 space-y-1 px-4">
        {navItems.map((item) => (
          <NavItem key={item.href} item={item} isCollapsed={isCollapsed} />
        ))}
      </nav>

      <div className="mt-auto flex flex-col space-y-2 p-4">
        <hr className="my-2 border-border" />
        {user && (
          <div className={cn("flex items-center gap-3 p-2 rounded-lg", isCollapsed ? 'justify-center' : '')}>
             <Avatar>
                <AvatarImage src={profile?.avatar_url} alt={profile?.name} />
                <AvatarFallback>{getInitials(profile?.name)}</AvatarFallback>
            </Avatar>
            <div className={cn("flex-1 min-w-0", isCollapsed && 'hidden')}>
              <p className="font-semibold text-sm text-foreground truncate">{profile?.name || user.email}</p>
              <Button variant="ghost" size="sm" onClick={handleSignOut} className="text-muted-foreground hover:text-destructive p-0 h-auto justify-start">
                <LogOut className="h-4 w-4 mr-1" />
                Cerrar sesión
              </Button>
            </div>
          </div>
        )}
      </div>
    </motion.aside>
  );
};

export default ClientSidebar;
