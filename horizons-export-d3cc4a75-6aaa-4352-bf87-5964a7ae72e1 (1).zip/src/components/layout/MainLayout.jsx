import React, { useState, useEffect } from 'react';
    import { Outlet } from 'react-router-dom';
    import Sidebar from '@/components/layout/Sidebar';

    const MainLayout = () => {
      const [isCollapsed, setIsCollapsed] = useState(() => {
        try {
          const item = window.localStorage.getItem('sidebarCollapsed');
          return item ? JSON.parse(item) : false;
        } catch (error) {
          console.error(error);
          return false;
        }
      });

      useEffect(() => {
        try {
          window.localStorage.setItem('sidebarCollapsed', JSON.stringify(isCollapsed));
        } catch (error) {
          console.error(error);
        }
      }, [isCollapsed]);

      return (
        <div className="flex h-screen bg-secondary/50">
          <Sidebar isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />
          <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
            <Outlet />
          </main>
        </div>
      );
    };

    export default MainLayout;