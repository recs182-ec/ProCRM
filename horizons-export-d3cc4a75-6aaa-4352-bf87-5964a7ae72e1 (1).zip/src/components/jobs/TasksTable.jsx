import React, { useState, useEffect } from 'react';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Button } from '@/components/ui/button';
    import { Badge } from '@/components/ui/badge';
    import { Plus, CheckCircle, Circle, MessageSquare, Trash2, Edit } from 'lucide-react';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useToast } from '@/components/ui/use-toast';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Textarea } from '@/components/ui/textarea';
    
    export const TasksTable = ({ job, tasks, onOpenTaskDialog, onTaskUpdate }) => {
      const { toast } = useToast();
      const [isCommentDialogOpen, setIsCommentDialogOpen] = useState(false);
      const [currentTask, setCurrentTask] = useState(null);
      const [comment, setComment] = useState('');
      
      const [allTasks, setAllTasks] = useState(tasks);
    
      useEffect(() => {
        setAllTasks(tasks);
      }, [tasks]);
    
      const toggleTaskStatus = async (task) => {
        const newStatus = task.status === 'Pendiente' ? 'Terminada' : 'Pendiente';
        const completed_at = newStatus === 'Terminada' ? new Date().toISOString() : null;
        const { error } = await supabase.from('tasks').update({ status: newStatus, completed_at }).eq('id', task.id);
        if (error) {
          toast({ title: 'Error', description: 'No se pudo actualizar el estado de la tarea.', variant: 'destructive' });
        } else {
          onTaskUpdate();
        }
      };
      
      const handleOpenCommentDialog = (task) => {
        setCurrentTask(task);
        setComment(task.comments || '');
        setIsCommentDialogOpen(true);
      };
    
      const handleSaveComment = async () => {
        const { error } = await supabase.from('tasks').update({ comments: comment }).eq('id', currentTask.id);
        if (error) {
          toast({ title: 'Error', description: 'No se pudo guardar el comentario.', variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: 'Comentario guardado.' });
          onTaskUpdate();
          setIsCommentDialogOpen(false);
        }
      };
    
      const handleDeleteTask = async (taskId) => {
        const { error } = await supabase.from('tasks').delete().eq('id', taskId);
        if (error) {
            toast({ title: 'Error', description: 'No se pudo eliminar la tarea.', variant: 'destructive' });
        } else {
            toast({ title: 'Éxito', description: 'La tarea ha sido eliminada.' });
            onTaskUpdate();
        }
      };
    
      return (
        <>
          <div className="border-t pt-4 mt-4">
            <div className="flex justify-between items-center mb-4">
              <h4 className="font-semibold">Tareas del Proyecto</h4>
              <Button size="sm" onClick={() => onOpenTaskDialog(job)}>
                <Plus className="h-4 w-4 mr-2" />Crear Tarea
              </Button>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Servicio</TableHead>
                  <TableHead>Frecuencia</TableHead>
                  <TableHead>Vencimiento</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {allTasks.map(task => (
                  <TableRow key={task.id} className={task.status === 'Terminada' ? 'bg-green-50' : ''}>
                    <TableCell>{task.service_name}</TableCell>
                    <TableCell>{task.frequency}</TableCell>
                    <TableCell>{new Date(task.due_date + 'T00:00:00').toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Badge variant={task.status === 'Terminada' ? 'success' : 'secondary'} className={task.status === 'Terminada' ? 'bg-green-100 text-green-800' : ''}>
                        {task.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="flex items-center gap-1">
                      <Button variant="ghost" size="icon" onClick={() => toggleTaskStatus(task)} className="h-8 w-8">
                        {task.status === 'Pendiente' ? <Circle className="h-4 w-4" /> : <CheckCircle className="h-4 w-4 text-green-600" />}
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => onOpenTaskDialog(job, task)} className="h-8 w-8">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleOpenCommentDialog(task)} className="h-8 w-8">
                        <MessageSquare className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteTask(task.id)} className="h-8 w-8 text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {allTasks.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground">No hay tareas para este proyecto.</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
           <Dialog open={isCommentDialogOpen} onOpenChange={setIsCommentDialogOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Comentarios para Tarea</DialogTitle>
                <DialogDescription>{currentTask?.service_name}</DialogDescription>
              </DialogHeader>
              <div className="py-4">
                <Textarea value={comment} onChange={(e) => setComment(e.target.value)} rows={5} placeholder="Añade tus comentarios aquí..." />
              </div>
              <DialogFooter><Button onClick={handleSaveComment}>Guardar Comentario</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </>
      );
    };