import React from 'react';
    import {
      Dialog,
      DialogContent,
      DialogHeader,
      DialogTitle,
      DialogDescription,
      DialogFooter,
    } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

    export const TaskDialog = ({
      isOpen,
      onOpenChange,
      onSave,
      taskFormData,
      setTaskFormData,
      isEditing,
      currentJob,
      savedServices
    }) => {
      const handleSaveClick = () => {
        onSave(taskFormData);
      };

      const handleServiceSelect = (serviceId) => {
        if (serviceId === 'manual') {
          setTaskFormData(prev => ({ ...prev, service_id: null, service_name: '' }));
        } else {
          const selectedService = savedServices.find(s => s.id === serviceId);
          if (selectedService) {
            setTaskFormData(prev => ({ ...prev, service_id: selectedService.id, service_name: selectedService.name }));
          }
        }
      };

      return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{isEditing ? 'Editar Tarea' : 'Crear Nueva Tarea'}</DialogTitle>
              <DialogDescription>
                {currentJob ? `Para el proyecto de ${currentJob.companies?.commercial_name || currentJob.client_company}` : ''}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label>Servicio</Label>
                <Select onValueChange={handleServiceSelect} value={taskFormData.service_id || 'manual'}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar servicio..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manual">Escribir servicio manualmente</SelectItem>
                    {savedServices.map(service => (
                      <SelectItem key={service.id} value={service.id}>{service.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {!taskFormData.service_id && (
                <div>
                  <Label htmlFor="manual_service_name">Nombre del Servicio Manual</Label>
                  <Input 
                    id="manual_service_name" 
                    value={taskFormData.service_name} 
                    onChange={(e) => setTaskFormData({ ...taskFormData, service_name: e.target.value })} 
                    placeholder="Ej: Publicación en Redes Sociales"
                  />
                </div>
              )}

              <div>
                <Label htmlFor="due_date">Fecha de Vencimiento</Label>
                <Input id="due_date" type="date" value={taskFormData.due_date} onChange={(e) => setTaskFormData({ ...taskFormData, due_date: e.target.value })} />
              </div>
              
              <div>
                <Label>Frecuencia</Label>
                <Select value={taskFormData.frequency} onValueChange={(value) => setTaskFormData({ ...taskFormData, frequency: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar frecuencia" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Única">Única</SelectItem>
                    <SelectItem value="Mensual">Mensual</SelectItem>
                    <SelectItem value="Anual">Anual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleSaveClick}>Guardar Tarea</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      );
    };