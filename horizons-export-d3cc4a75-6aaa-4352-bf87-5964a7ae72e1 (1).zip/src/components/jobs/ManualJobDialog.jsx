import React, { useState, useEffect } from 'react';
    import {
      Dialog,
      DialogContent,
      DialogHeader,
      DialogTitle,
      DialogDescription,
      DialogFooter,
    } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
    import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from '@/components/ui/command';
    import { Check } from 'lucide-react';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

    export const ManualJobDialog = ({
      isOpen,
      onOpenChange,
      onSave,
      companies,
      savedServices
    }) => {
      const initialFormState = { service_id: null, company_id: null, value: '', due_date: '', service_name: '', company_name: '', frequency: 'Única' };
      const [taskFormData, setTaskFormData] = useState(initialFormState);
      const [openCompanyPopover, setOpenCompanyPopover] = useState(false);

      useEffect(() => {
        if (!isOpen) {
          setTaskFormData(initialFormState);
        }
      }, [isOpen]);

      const handleCompanySelect = (company) => {
        setTaskFormData(prev => ({ ...prev, company_id: company.id, company_name: company.commercial_name }));
        setOpenCompanyPopover(false);
      };
      
      const handleServiceSelect = (serviceId) => {
          const selectedService = savedServices.find(s => s.id === serviceId);
          if (selectedService) {
            setTaskFormData(prev => ({ ...prev, service_id: selectedService.id, service_name: selectedService.name, value: selectedService.price }));
          } else {
            setTaskFormData(prev => ({ ...prev, service_id: null, service_name: '', value: '' }));
          }
      };

      const handleSaveClick = () => {
        onSave(taskFormData, true);
      };
      
      const selectedCompanyName = companies.find(c => c.id === taskFormData.company_id)?.commercial_name;

      return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Crear Trabajo Manual</DialogTitle>
              <DialogDescription>Añade una tarea que no está vinculada a una propuesta.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label>Compañía</Label>
                <Popover open={openCompanyPopover} onOpenChange={setOpenCompanyPopover}>
                  <PopoverTrigger asChild>
                    <Button variant="outline" role="combobox" aria-expanded={openCompanyPopover} className="w-full justify-between">
                      {selectedCompanyName || "Seleccionar compañía"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                    <Command>
                      <CommandInput placeholder="Buscar compañía..." />
                      <CommandEmpty>No se encontró la compañía.</CommandEmpty>
                      <CommandGroup>
                        {companies.map((company) => (
                          <CommandItem key={company.id} onSelect={() => handleCompanySelect(company)}>
                            <Check className={`mr-2 h-4 w-4 ${taskFormData.company_id === company.id ? "opacity-100" : "opacity-0"}`} />
                            {company.commercial_name}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>
              <div>
                <Label>Servicio</Label>
                <Select onValueChange={handleServiceSelect}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar servicio guardado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manual">Escribir servicio manualmente</SelectItem>
                    {savedServices.map(service => (
                      <SelectItem key={service.id} value={service.id}>{service.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {!taskFormData.service_id && (
                <div>
                  <Label htmlFor="manual_service_name">Nombre del Servicio Manual</Label>
                  <Input id="manual_service_name" value={taskFormData.service_name} onChange={(e) => setTaskFormData({ ...taskFormData, service_name: e.target.value })} />
                </div>
              )}
              <div>
                <Label htmlFor="value">Valor del Servicio</Label>
                <Input id="value" type="number" value={taskFormData.value} onChange={(e) => setTaskFormData({ ...taskFormData, value: parseFloat(e.target.value) || 0 })} />
              </div>
              <div>
                <Label htmlFor="due_date">Fecha de Vencimiento</Label>
                <Input id="due_date" type="date" value={taskFormData.due_date} onChange={(e) => setTaskFormData({ ...taskFormData, due_date: e.target.value })} />
              </div>
              <div>
                <Label>Frecuencia</Label>
                <Select value={taskFormData.frequency} onValueChange={(value) => setTaskFormData({ ...taskFormData, frequency: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar frecuencia" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Única">Única</SelectItem>
                    <SelectItem value="Mensual">Mensual</SelectItem>
                    <SelectItem value="Anual">Anual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleSaveClick}>Guardar Trabajo</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      );
    };