import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronUp, Trash2 } from 'lucide-react';
import { TasksTable } from '@/components/jobs/TasksTable';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

export const JobsList = ({ jobs, tasks, expandedJob, toggleJobExpansion, onOpenTaskDialog, onDeleteJob, onTaskUpdate }) => {
  const countPendingTasksForJob = (jobId) => {
    return tasks[jobId]?.filter(t => t.status === 'Pendiente').length || 0;
  };

  return (
    <div className="space-y-4">
      {jobs.map(job => (
        <Card key={job.id}>
          <CardHeader className="cursor-pointer" onClick={() => toggleJobExpansion(job.id)}>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>{job.companies?.commercial_name || job.client_company}</CardTitle>
                <CardDescription>{job.client_name !== 'Manual' ? job.client_name : 'Trabajo Manual'}</CardDescription>
              </div>
              <div className="flex items-center gap-4">
                {countPendingTasksForJob(job.id) > 0 && <Badge variant="destructive">{countPendingTasksForJob(job.id)} pendiente(s)</Badge>}
                 <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10" onClick={(e) => e.stopPropagation()}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Esto eliminará permanentemente el trabajo y todas sus tareas asociadas. Esta acción no se puede deshacer.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={() => onDeleteJob(job.id)}>Eliminar</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                {expandedJob === job.id ? <ChevronUp /> : <ChevronDown />}
              </div>
            </div>
          </CardHeader>
          {expandedJob === job.id && (
            <CardContent>
              <TasksTable
                job={job}
                tasks={tasks[job.id] || []}
                onOpenTaskDialog={onOpenTaskDialog}
                onTaskUpdate={onTaskUpdate}
              />
            </CardContent>
          )}
        </Card>
      ))}
    </div>
  );
};