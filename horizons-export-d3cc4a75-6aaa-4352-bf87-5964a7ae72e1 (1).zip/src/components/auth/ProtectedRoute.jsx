
import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const ProtectedRoute = ({ allowedRoles }) => {
  const { session, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="loader"></div>
      </div>
    );
  }

  if (!session) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(profile?.role)) {
    // If user is logged in but doesn't have the right role, send them to their respective dashboard
    const homePath = profile?.role === 'client' ? '/client/dashboard' : '/dashboard';
    return <Navigate to={homePath} replace />;
  }

  return <Outlet />;
};

export default ProtectedRoute;
