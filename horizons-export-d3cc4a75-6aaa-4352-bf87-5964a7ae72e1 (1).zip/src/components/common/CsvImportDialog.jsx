import React, { useState } from 'react';
    import Papa from 'papaparse';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { UploadCloud, FileSpreadsheet } from 'lucide-react';

    const CsvImportDialog = ({ open, onOpenChange, tableName, columnMapping, templateFile, onSuccess }) => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [file, setFile] = useState(null);
      const [isUploading, setIsUploading] = useState(false);

      const handleFileChange = (e) => {
        setFile(e.target.files[0]);
      };

      const handleImport = async () => {
        if (!file) {
          toast({ title: 'Error', description: 'Por favor, selecciona un archivo.', variant: 'destructive' });
          return;
        }

        setIsUploading(true);
        Papa.parse(file, {
          header: true,
          skipEmptyLines: true,
          complete: async (results) => {
            const { data, errors } = results;

            if (errors.length > 0) {
              toast({ title: 'Error en el archivo CSV', description: `Se encontraron errores: ${errors.map(e => e.message).join(', ')}`, variant: 'destructive' });
              setIsUploading(false);
              return;
            }

            const validData = data.filter(row => Object.values(row).some(val => val !== null && val !== ''));

            if (validData.length === 0) {
              toast({ title: 'Archivo vacío', description: 'El archivo CSV no contiene datos válidos para importar.', variant: 'destructive' });
              setIsUploading(false);
              return;
            }
            
            let recordsToInsert = validData.map(row => {
              const record = { user_id: user.id };
              for (const key in columnMapping) {
                if (row[key] !== undefined) {
                  const dbColumn = columnMapping[key];
                  if (dbColumn.type === 'number') {
                    record[dbColumn.name] = parseFloat(row[key]) || 0;
                  } else {
                    record[dbColumn.name] = row[key];
                  }
                }
              }
              return record;
            });
            
            if (tableName === 'contacts') {
              const companyNames = [...new Set(validData.map(row => row.company_commercial_name).filter(Boolean))];
              if (companyNames.length > 0) {
                const { data: companiesData, error: companiesError } = await supabase
                  .from('companies')
                  .select('id, commercial_name')
                  .in('commercial_name', companyNames)
                  .eq('user_id', user.id);
                
                if (companiesError) {
                   toast({ title: 'Error', description: 'No se pudieron verificar las compañías existentes.', variant: 'destructive' });
                   setIsUploading(false);
                   return;
                }
                
                const companyMap = new Map(companiesData.map(c => [c.commercial_name, c.id]));
                
                recordsToInsert = recordsToInsert.map((record, index) => {
                  const companyName = validData[index].company_commercial_name;
                  if (companyName && companyMap.has(companyName)) {
                    record.company_id = companyMap.get(companyName);
                  }
                  delete record.company_commercial_name; 
                  return record;
                });
              }
            }
            
            if (tableName === 'services') {
                const categoryNames = [...new Set(validData.map(row => row.category).filter(Boolean))];
                if (categoryNames.length > 0) {
                    const { data: categoriesData, error: categoriesError } = await supabase
                        .from('service_categories')
                        .select('id, name')
                        .in('name', categoryNames)
                        .eq('user_id', user.id);

                    if (categoriesError) {
                        toast({ title: 'Error', description: 'No se pudieron verificar las categorías existentes.', variant: 'destructive' });
                        setIsUploading(false);
                        return;
                    }

                    const categoryMap = new Map(categoriesData.map(c => [c.name, c.id]));
                    
                    const newCategoriesToCreate = categoryNames
                      .filter(name => !categoryMap.has(name))
                      .map(name => ({ name, user_id: user.id }));

                    if (newCategoriesToCreate.length > 0) {
                      const { data: newCategories, error: newCatError } = await supabase
                        .from('service_categories')
                        .insert(newCategoriesToCreate)
                        .select('id, name');

                      if (newCatError) {
                        toast({ title: 'Error', description: 'No se pudieron crear nuevas categorías.', variant: 'destructive' });
                        setIsUploading(false);
                        return;
                      }

                      newCategories.forEach(cat => categoryMap.set(cat.name, cat.id));
                    }


                    recordsToInsert = recordsToInsert.map((record, index) => {
                        const categoryName = validData[index].category;
                        if (categoryName && categoryMap.has(categoryName)) {
                            record.category_id = categoryMap.get(categoryName);
                        }
                        delete record.category;
                        return record;
                    });
                }
            }


            const { error } = await supabase.from(tableName).insert(recordsToInsert);

            if (error) {
              toast({ title: 'Error de importación', description: `No se pudieron guardar los datos. ${error.message}`, variant: 'destructive' });
            } else {
              toast({ title: '¡Éxito!', description: `${recordsToInsert.length} registros importados correctamente.` });
              onSuccess();
              onOpenChange(false);
            }

            setIsUploading(false);
            setFile(null);
          },
        });
      };

      return (
        <Dialog open={open} onOpenChange={onOpenChange}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2"><UploadCloud className="h-5 w-5" /> Importar desde CSV</DialogTitle>
              <DialogDescription>
                Sube un archivo CSV para importar tus datos masivamente. Asegúrate de que las columnas coincidan con la plantilla.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <a href={templateFile} download className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline">
                <FileSpreadsheet className="h-4 w-4" />
                Descargar plantilla de ejemplo
              </a>
              <div>
                <Label htmlFor="csv-file">Archivo CSV</Label>
                <Input id="csv-file" type="file" accept=".csv" onChange={handleFileChange} className="file:text-primary"/>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isUploading}>Cancelar</Button>
              <Button onClick={handleImport} disabled={isUploading || !file}>
                {isUploading ? 'Importando...' : 'Importar'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      );
    };

    export default CsvImportDialog;