import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const ProposalServices = ({ services, selectedServices, onServiceToggle, isApproved, isRejected }) => {
  const isFinalState = isApproved || isRejected;

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
      <Card className="bg-white border">
        <CardHeader>
          <CardTitle>Servicios Propuestos</CardTitle>
          {!isFinalState && (
            <CardDescription>Selecciona o deselecciona los servicios que necesites. Expande cada uno para ver más detalles.</CardDescription>
          )}
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full space-y-4">
            {services.map((service, index) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`service-item rounded-lg border ${selectedServices.includes(service.id) ? 'border-primary ring-2 ring-primary/20' : ''}`}
              >
                <div className="flex items-start gap-4 p-4">
                  <Checkbox
                    checked={selectedServices.includes(service.id)}
                    onCheckedChange={() => onServiceToggle(service.id)}
                    disabled={isFinalState}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <AccordionItem value={`item-${index}`} className="border-b-0">
                      <AccordionTrigger className="p-0 hover:no-underline">
                        <div className="flex-1 text-left">
                          <h4 className="font-semibold text-lg">{service.name}</h4>
                          <p className="text-xl font-bold text-gray-700">${(service.price || 0).toLocaleString('es-ES', { minimumFractionDigits: 2 })} <span className="text-sm font-normal text-muted-foreground">/ {service.frequency}</span></p>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="pt-2">
                        <p className="text-muted-foreground whitespace-pre-wrap">{service.description || 'Sin descripción detallada.'}</p>
                      </AccordionContent>
                    </AccordionItem>
                  </div>
                </div>
              </motion.div>
            ))}
          </Accordion>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProposalServices;